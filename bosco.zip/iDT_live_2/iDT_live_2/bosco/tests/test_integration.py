"""Integration tests for the Bosco launcher, build helper, and in-memory app.

These are integration-style example tests (not property-based) covering the
design's "Testing Strategy -> Integration tests" bullet:

* ``main()`` starts (mocked) Waitress and opens (mocked) browser (Req 1.2).
* Interrupt (``KeyboardInterrupt``) releases the bound port (Req 1.6).
* The build helper copies ``dist`` into the static dir and leaves the frontend
  source unmodified, verified via before/after hashing (Req 3.1, 3.2).
* No application-STATE files (parquet / df_store / redis) are written to disk
  after a run (Req 4.3).
* Waitress serves without Gunicorn (Req 7.1, 7.2).

All server / browser / npm side effects are mocked:

* ``waitress.serve`` is patched to a recording ``Mock`` (or made to raise
  ``KeyboardInterrupt`` for the interrupt scenario). No real server starts. A
  fake ``waitress`` module is injected into ``sys.modules`` only if the real
  package is not importable, so the lazy ``from waitress import serve`` inside
  ``main`` resolves either way.
* ``webbrowser.open`` is patched (via ``bosco.cli.webbrowser.open``) to a
  ``Mock`` so no real browser launches.
* No npm/Node is invoked: the build helper is driven with an injected no-op
  ``build_runner`` against a FAKE pre-populated ``dist/`` directory.
"""

from __future__ import annotations

import hashlib
import importlib.util
import socket
import sys
import types
from pathlib import Path
from unittest.mock import Mock

import pytest

from bosco import cli
from bosco.app import create_app
from bosco.state import session_manager


def _load_build_frontend():
    """Load ``build_frontend`` from ``bosco/scripts/build_frontend.py``.

    The build helper lives under ``bosco/scripts/`` (a packaging script dir),
    not under the importable ``src/bosco`` package, so it is loaded directly
    from its file path to avoid depending on any particular sys.path layout.
    """
    # This test file is at <ws>/bosco/tests/test_integration.py.
    script_path = Path(__file__).resolve().parent.parent / "scripts" / "build_frontend.py"
    spec = importlib.util.spec_from_file_location("bosco_build_frontend", script_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.build_frontend


build_frontend = _load_build_frontend()


# --------------------------------------------------------------------------- #
# Fixtures / helpers
# --------------------------------------------------------------------------- #
@pytest.fixture
def fake_waitress(monkeypatch):
    """Ensure ``waitress.serve`` is a recording ``Mock``.

    If the real ``waitress`` package is installed its ``serve`` is patched in
    place; otherwise a fake module is injected so the lazy
    ``from waitress import serve`` inside ``cli.main`` resolves. Yields the
    ``serve`` mock so tests can assert how it was called.
    """
    serve_mock = Mock(name="waitress.serve")
    module = sys.modules.get("waitress")
    if module is None:
        module = types.ModuleType("waitress")
        monkeypatch.setitem(sys.modules, "waitress", module)
    monkeypatch.setattr(module, "serve", serve_mock, raising=False)
    yield serve_mock


@pytest.fixture(autouse=True)
def reset_state():
    """Reset the single-user in-memory state before and after each test."""
    session_manager.purge("local")
    yield
    session_manager.purge("local")


def _hash_file(path: Path) -> str:
    """Return a stable SHA-256 hex digest of a file's bytes."""
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _hash_tree(root: Path) -> dict[str, str]:
    """Return {relative_posix_path: sha256} for every file under ``root``."""
    hashes: dict[str, str] = {}
    for p in sorted(root.rglob("*")):
        if p.is_file():
            hashes[p.relative_to(root).as_posix()] = _hash_file(p)
    return hashes


# --------------------------------------------------------------------------- #
# 1. main() starts (mocked) Waitress and opens (mocked) browser (Req 1.2)
# --------------------------------------------------------------------------- #
def test_main_starts_waitress_and_opens_browser(monkeypatch, fake_waitress):
    """main() serves via waitress (app, host/port, threads=1) and opens the
    browser once the server is ready (Req 1.2).

    The TCP-readiness poll is replaced with an immediate ``webbrowser.open``
    call so the assertion is race-free, and the browser-open thread is joined
    before asserting. ``find_available_port`` is pinned for determinism.
    """
    monkeypatch.setattr(cli, "find_available_port", lambda host, port: 8765)

    open_mock = Mock(name="webbrowser.open")
    monkeypatch.setattr(cli.webbrowser, "open", open_mock)

    # Capture started threads so we can join the browser-open thread.
    started_threads = []
    real_thread_cls = cli.threading.Thread

    def capture_thread(*args, **kwargs):
        t = real_thread_cls(*args, **kwargs)
        started_threads.append(t)
        return t

    monkeypatch.setattr(cli.threading, "Thread", capture_thread)

    # Make readiness resolve immediately (no TCP polling) and open the browser.
    def immediate(host, port, url, timeout=5.0):
        cli.webbrowser.open(url)

    monkeypatch.setattr(cli, "_open_browser_when_ready", immediate)

    rc = cli.main([])  # no --no-browser -> browser path runs

    assert rc == 0

    # Join the browser thread so the open-assertion is deterministic.
    for t in started_threads:
        t.join(timeout=5.0)

    # waitress.serve called with the app, host/port, and single thread.
    assert fake_waitress.call_count == 1
    args, kwargs = fake_waitress.call_args
    served_app = args[0] if args else kwargs.get("app")
    assert served_app is not None
    assert kwargs.get("host") == "127.0.0.1"
    assert kwargs.get("port") == 8765
    assert kwargs.get("threads") == 1

    # Browser opened at the printed URL.
    open_mock.assert_called_once_with("http://127.0.0.1:8765")


# --------------------------------------------------------------------------- #
# 2. Interrupt releases the bound port (Req 1.6)
# --------------------------------------------------------------------------- #
def test_interrupt_releases_port(monkeypatch, fake_waitress):
    """A KeyboardInterrupt out of waitress.serve yields a clean exit (rc 0) and
    leaves nothing holding the port, so it can be re-bound afterward (Req 1.6).

    A real free port is chosen via find_available_port; waitress.serve is
    patched to raise KeyboardInterrupt (simulating Ctrl-C). After main() returns
    we assert the host/port can be bound again.
    """
    host = "127.0.0.1"
    port = cli.find_available_port(host, 0)  # a real, currently-free port

    monkeypatch.setattr(cli, "find_available_port", lambda h, p: port)
    monkeypatch.setattr(cli.webbrowser, "open", Mock())

    fake_waitress.side_effect = KeyboardInterrupt()

    rc = cli.main(["--no-browser"])

    assert rc == 0  # clean shutdown
    fake_waitress.assert_called_once()

    # Nothing left holding the port -> we can re-bind it.
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        s.bind((host, port))  # must not raise
    finally:
        s.close()


# --------------------------------------------------------------------------- #
# 3. Build helper copies dist and leaves FE source unmodified (Req 3.1, 3.2)
# --------------------------------------------------------------------------- #
def _make_fake_frontend(root: Path) -> dict[str, str]:
    """Create a fake FE source tree with tracked source + a pre-built dist/.

    Returns {relative_path: sha256} for the TRACKED SOURCE files only (dist is
    excluded, as it is build output that the helper consumes/copies).
    """
    # Tracked source files (must remain unmodified by the build helper).
    (root / "package.json").write_text(
        '{"name": "fake-fe", "version": "0.0.0"}\n', encoding="utf-8"
    )
    src = root / "src"
    src.mkdir(parents=True, exist_ok=True)
    (src / "App.tsx").write_text(
        "export default function App() { return null; }\n", encoding="utf-8"
    )

    tracked_hashes = {
        "package.json": _hash_file(root / "package.json"),
        "src/App.tsx": _hash_file(src / "App.tsx"),
    }

    # Pre-built dist/ (what a real `npm run build` would have produced).
    dist = root / "dist"
    (dist / "assets").mkdir(parents=True, exist_ok=True)
    (dist / "index.html").write_text(
        "<!doctype html><html><body>FAKE DIST INDEX</body></html>", encoding="utf-8"
    )
    (dist / "assets" / "app.js").write_text(
        "console.log('fake app bundle');\n", encoding="utf-8"
    )

    return tracked_hashes


def test_build_helper_copies_dist_and_leaves_source_unmodified(tmp_path):
    """build_frontend copies dist/* into the static dir and does not touch the
    tracked FE source files (verified via before/after hashing) (Req 3.1, 3.2).

    A no-op ``build_runner`` is injected so no npm/Node is needed; the fake
    ``dist/`` already exists and is consumed as-is.
    """
    fe_dir = tmp_path / "fake_fe"
    fe_dir.mkdir()
    static_dir = tmp_path / "static_target"

    before_hashes = _make_fake_frontend(fe_dir)

    build_calls = []

    def noop_build(frontend_dir):
        # Record the call; perform no build (dist already present).
        build_calls.append(Path(frontend_dir))

    result = build_frontend(
        frontend_dir=fe_dir,
        static_dir=static_dir,
        build_runner=noop_build,
    )

    # The no-op build runner was invoked (build step delegated, no npm run).
    assert build_calls, "injected build_runner was not called"

    # dist/* copied into the static target with matching contents.
    assert result == static_dir.resolve()
    copied_index = static_dir / "index.html"
    copied_asset = static_dir / "assets" / "app.js"
    assert copied_index.is_file()
    assert copied_asset.is_file()
    assert copied_index.read_text(encoding="utf-8") == (
        fe_dir / "dist" / "index.html"
    ).read_text(encoding="utf-8")
    assert copied_asset.read_text(encoding="utf-8") == (
        fe_dir / "dist" / "assets" / "app.js"
    ).read_text(encoding="utf-8")

    # Tracked FE source files are UNCHANGED after the build+copy.
    after_hashes = {
        "package.json": _hash_file(fe_dir / "package.json"),
        "src/App.tsx": _hash_file(fe_dir / "src" / "App.tsx"),
    }
    assert after_hashes == before_hashes


def test_build_helper_raises_when_dist_missing_index(tmp_path):
    """build_frontend raises SystemExit if the dist lacks index.html (Req 3.5).

    The fake dist has an asset but no index.html, so after the copy the entry
    document is absent and the helper must fail loudly.
    """
    fe_dir = tmp_path / "fake_fe_no_index"
    fe_dir.mkdir()
    static_dir = tmp_path / "static_target_no_index"

    # dist/ WITHOUT index.html.
    dist = fe_dir / "dist"
    (dist / "assets").mkdir(parents=True, exist_ok=True)
    (dist / "assets" / "app.js").write_text("console.log('x');\n", encoding="utf-8")

    with pytest.raises(SystemExit) as excinfo:
        build_frontend(
            frontend_dir=fe_dir,
            static_dir=static_dir,
            build_runner=lambda _fe: None,  # no-op
        )

    assert "index.html" in str(excinfo.value)


# --------------------------------------------------------------------------- #
# 4. No app-STATE files written to disk after a run (Req 4.3)
# --------------------------------------------------------------------------- #
def test_no_app_state_files_written_to_disk(tmp_path, monkeypatch):
    """Exercising in-memory state persists NO application-state artifacts.

    Scoping decision: the property under test (Req 4.3) is that APPLICATION
    STATE is not persisted to disk -- i.e. there is no parquet DataFrame store,
    no ``df_store`` directory, and no redis dump. The one disk write the app can
    make is saving an *uploaded file* into ``./uploads`` while HANDLING a file
    upload; that is uploaded-file handling, not state persistence, so this test
    deliberately avoids triggering a file-save upload and instead:

      * seeds in-memory state directly and hits read endpoints, and
      * also runs a non-file-saving code path (health/getTreeData),

    then asserts that under a temp working directory NO ``*.parquet`` files and
    NO ``df_store`` directory exist anywhere. (redis is never imported.)
    """
    monkeypatch.chdir(tmp_path)

    app = create_app(static_dir=tmp_path)  # static dir irrelevant here
    client = app.test_client()

    # Seed in-memory state directly (no file-save upload path).
    state = session_manager.resolve("local")
    state.original_data_source = "in_memory.csv"
    state.badflag = "target"
    state.df_col = [
        {"column_name": "a", "datatype": "numerical"},
        {"column_name": "target", "datatype": "categorical"},
    ]
    state.node_master = [
        {"node": "Node0", "parent": "", "variable": "a", "depth": 0},
    ]

    # Hit read-only endpoints that touch state but do not save files.
    assert client.get("/api/health").status_code == 200
    assert client.get("/api/getRegressionFlag").status_code == 200
    # Export reads in-memory state and returns JSON (no disk write).
    resp = client.get("/api/exportTree")
    assert resp.status_code == 200, resp.get_data(as_text=True)

    # Assert NO application-STATE artifacts were written anywhere under cwd.
    parquet_files = list(tmp_path.rglob("*.parquet"))
    assert parquet_files == [], f"unexpected parquet state files: {parquet_files}"

    df_store_dirs = [p for p in tmp_path.rglob("df_store") if p.is_dir()]
    assert df_store_dirs == [], f"unexpected df_store dir: {df_store_dirs}"

    # No redis dump file (rdb) either.
    rdb_files = list(tmp_path.rglob("*.rdb"))
    assert rdb_files == [], f"unexpected redis dump files: {rdb_files}"

    # redis is not a dependency / not imported by the app.
    assert "redis" not in sys.modules


# --------------------------------------------------------------------------- #
# 5. Waitress serves without Gunicorn (Req 7.1, 7.2)
# --------------------------------------------------------------------------- #
def test_waitress_used_and_gunicorn_absent(monkeypatch, fake_waitress):
    """main() serves via waitress and gunicorn is neither imported nor required
    (Req 7.1, 7.2).

    Asserts waitress.serve is invoked (the serving path) and that importing /
    running the CLI does not pull in gunicorn.
    """
    monkeypatch.setattr(cli, "find_available_port", lambda host, port: 8765)
    monkeypatch.setattr(cli.webbrowser, "open", Mock())

    # Importing bosco.cli must not import gunicorn.
    assert "gunicorn" not in sys.modules

    cli.main(["--no-browser"])

    fake_waitress.assert_called_once()  # waitress is the server

    # Still no gunicorn after running the launcher path.
    assert "gunicorn" not in sys.modules
