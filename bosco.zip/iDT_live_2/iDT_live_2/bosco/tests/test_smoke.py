"""Smoke tests for the Bosco package: packaging, assets, and isolation.

These are fast, hermetic example tests (not property-based) that encode the
design's Testing Strategy smoke-test checks as regression guards:

* Entry point ``bosco`` declared in ``pyproject.toml`` (Requirement 1.1).
* ``pyproject`` metadata + ``requires-python`` constraint and required runtime
  dependencies present (Requirements 7.3, 8.1, 8.2).
* Intentionally EXCLUDED dependencies absent (Requirements 6.5, 8.4).
* ``resolve_static_dir()`` resolves a directory and serves ``index.html`` when
  present (Requirement 3.4).
* ``create_app()`` works with no auth env vars set (Requirement 5.4).
* ``python -m build`` yields a wheel + sdist and the wheel contains
  ``bosco/static/index.html`` (Requirements 3.3, 8.5).
* ``backend/`` and ``frontend/`` tracked files unchanged and all new code lives
  under ``bosco/`` (Requirements 10.1-10.7).

Tests that create a placeholder ``index.html`` under the real
``src/bosco/static/`` directory always clean it up in a ``finally`` block so the
repo is left as-found (only ``.gitkeep`` in ``static/``).
"""

from __future__ import annotations

import os
import subprocess
import sys
import tomllib
import zipfile
from pathlib import Path

import pytest

from bosco.app import create_app
from bosco.serving import resolve_static_dir


# --------------------------------------------------------------------------- #
# Path helpers
# --------------------------------------------------------------------------- #

# This file is bosco/tests/test_smoke.py, so parents[1] == the bosco/ project dir.
BOSCO_DIR = Path(__file__).resolve().parents[1]
WORKSPACE_ROOT = BOSCO_DIR.parent
PYPROJECT_PATH = BOSCO_DIR / "pyproject.toml"
REAL_STATIC_DIR = BOSCO_DIR / "src" / "bosco" / "static"

PLACEHOLDER_INDEX_HTML = (
    "<!doctype html><html><body>BOSCO_SMOKE_PLACEHOLDER</body></html>"
)

# Dependencies that MUST NOT appear anywhere in project dependencies.
EXCLUDED_DEPS = {
    "redis",
    "boto3",
    "gunicorn",
    "flask-jwt-extended",
    "apscheduler",
    "python-dotenv",
    "pyarrow",
}

# Required runtime dependencies (name -> optional exact version pin).
REQUIRED_DEPS = {
    "flask": None,
    "flask-cors": None,
    "werkzeug": None,
    "waitress": None,
    "pandas": "2.2.3",
    "numpy": "1.26.4",
}


def _load_pyproject() -> dict:
    with open(PYPROJECT_PATH, "rb") as fh:
        return tomllib.load(fh)


def _remove_placeholder_index() -> None:
    """Remove the placeholder ``index.html`` from the real static dir if present.

    Only removes the file when its contents match our sentinel, so a genuine
    bundled ``index.html`` (if ever present) is never deleted. Idempotent and
    safe to call from ``finally`` blocks.
    """
    index_path = REAL_STATIC_DIR / "index.html"
    try:
        if index_path.exists() and index_path.read_text(encoding="utf-8") == PLACEHOLDER_INDEX_HTML:
            index_path.unlink()
    except (OSError, PermissionError):
        pass


def _split_requirement(req: str) -> tuple[str, str]:
    """Split a PEP 508 requirement into (lowercased name, version-spec tail).

    Only handles the simple ``name[extras]<spec>`` forms used in this project;
    that is sufficient for the dependency assertions here.
    """
    req = req.strip()
    # Strip any environment marker (``; python_version < ...``).
    req = req.split(";", 1)[0].strip()
    # Separate the name from the first version-specifier / bracket character.
    name = req
    for idx, ch in enumerate(req):
        if ch in "<>=!~ [(":
            name = req[:idx]
            break
    spec = req[len(name):].strip()
    # Drop extras in brackets from the name, e.g. ``flask[async]``.
    name = name.split("[", 1)[0]
    return name.strip().lower(), spec


# --------------------------------------------------------------------------- #
# Requirement 1.1: Entry point `bosco` declared
# --------------------------------------------------------------------------- #

def test_entry_point_bosco_declared():
    """[project.scripts] declares ``bosco = "bosco.cli:main"`` (Req 1.1)."""
    data = _load_pyproject()
    scripts = data.get("project", {}).get("scripts", {})
    assert scripts.get("bosco") == "bosco.cli:main", scripts


# --------------------------------------------------------------------------- #
# Requirements 7.3, 8.1, 8.2: metadata, requires-python, required deps
# --------------------------------------------------------------------------- #

def test_pyproject_metadata_name_and_version():
    """Package name is ``bosco`` and a version is present (Reqs 8.1, 8.2)."""
    project = _load_pyproject()["project"]
    assert project["name"] == "bosco"
    version = project.get("version")
    assert isinstance(version, str) and version, version


def test_requires_python_constraint():
    """``requires-python`` bounds to ``>=3.10,<3.13`` (Req 7.3)."""
    project = _load_pyproject()["project"]
    assert project.get("requires-python") == ">=3.10,<3.13"


def test_required_runtime_dependencies_present():
    """Runtime deps include Flask/Flask-CORS/Werkzeug/waitress + pinned pandas/numpy."""
    project = _load_pyproject()["project"]
    deps = {}
    for raw in project.get("dependencies", []):
        name, spec = _split_requirement(raw)
        deps[name] = spec

    for name, pin in REQUIRED_DEPS.items():
        assert name in deps, f"missing required dependency: {name} ({deps})"
        if pin is not None:
            assert deps[name] == f"=={pin}", (
                f"{name} expected pin ==%s, got %r" % (pin, deps[name])
            )


# --------------------------------------------------------------------------- #
# Requirements 6.5, 8.4: excluded deps absent everywhere
# --------------------------------------------------------------------------- #

def test_excluded_dependencies_absent():
    """None of the server-only deps appear in main or optional dependencies."""
    project = _load_pyproject()["project"]

    all_reqs = list(project.get("dependencies", []))
    for extra_reqs in project.get("optional-dependencies", {}).values():
        all_reqs.extend(extra_reqs)

    found_names = {_split_requirement(req)[0] for req in all_reqs}
    offenders = found_names & EXCLUDED_DEPS
    assert not offenders, f"excluded dependencies present: {sorted(offenders)}"


# --------------------------------------------------------------------------- #
# Requirement 3.4: resolve_static_dir finds index.html
# --------------------------------------------------------------------------- #

def test_resolve_static_dir_finds_index_html(tmp_path):
    """resolve_static_dir() resolves a ``static`` dir; a placed index.html is found.

    A temporary ``index.html`` is written into the real static dir for the
    duration of the test and removed afterward (``finally``) so the repo is left
    with only ``.gitkeep`` in ``static/``. Note: the file-detection assertions run
    against the real dir, but the ``create_app`` serving check uses a separate
    temp directory so no OS file handle is held open on the real ``index.html``
    (on Windows an open handle would block cleanup).
    """
    static_dir = resolve_static_dir()
    assert static_dir.name == "static"
    assert static_dir.is_dir()

    index_path = static_dir / "index.html"
    had_real_index = index_path.exists() and index_path.read_text(
        encoding="utf-8"
    ) != PLACEHOLDER_INDEX_HTML
    try:
        if not index_path.exists():
            index_path.write_text(PLACEHOLDER_INDEX_HTML, encoding="utf-8")

        resolved = resolve_static_dir()
        assert (resolved / "index.html").exists()
    finally:
        if not had_real_index:
            _remove_placeholder_index()

    # create_app serves index.html from its static dir -- exercised against a
    # throwaway temp dir (not the real one) to avoid holding a file handle open.
    serve_dir = tmp_path / "static"
    serve_dir.mkdir()
    (serve_dir / "index.html").write_text(PLACEHOLDER_INDEX_HTML, encoding="utf-8")
    app = create_app(static_dir=serve_dir)
    client = app.test_client()
    resp = client.get("/")
    try:
        assert resp.status_code == 200
        assert resp.get_data(as_text=True) == PLACEHOLDER_INDEX_HTML
    finally:
        resp.close()


# --------------------------------------------------------------------------- #
# Requirement 5.4: create_app() works with no auth env
# --------------------------------------------------------------------------- #

def test_create_app_without_auth_env(tmp_path, monkeypatch):
    """create_app() builds and serves with AUTH_USERS/JWT_SECRET_KEY unset."""
    monkeypatch.delenv("AUTH_USERS", raising=False)
    monkeypatch.delenv("JWT_SECRET_KEY", raising=False)

    static_dir = tmp_path / "static"
    static_dir.mkdir()
    (static_dir / "index.html").write_text(PLACEHOLDER_INDEX_HTML, encoding="utf-8")

    app = create_app(static_dir=static_dir)
    assert app is not None

    client = app.test_client()
    resp = client.get("/api/health")
    assert resp.status_code == 200
    assert resp.get_json()["status"] == "healthy"


# --------------------------------------------------------------------------- #
# Requirements 3.3, 8.5: python -m build yields wheel + sdist; wheel has assets
# --------------------------------------------------------------------------- #

def _build_importable() -> bool:
    try:
        import build  # noqa: F401
        import hatchling  # noqa: F401
    except ImportError:
        return False
    return True


@pytest.mark.skipif(not _build_importable(), reason="build/hatchling not installed")
def test_build_produces_wheel_and_sdist_with_static_index(tmp_path):
    """`python -m build` yields a wheel + sdist; wheel contains static/index.html.

    A placeholder ``index.html`` is placed in the real static dir before
    building (so the bundled SPA asset is present) and removed afterward.
    """
    index_path = REAL_STATIC_DIR / "index.html"
    had_real_index = index_path.exists() and index_path.read_text(
        encoding="utf-8"
    ) != PLACEHOLDER_INDEX_HTML
    try:
        if not index_path.exists():
            index_path.write_text(PLACEHOLDER_INDEX_HTML, encoding="utf-8")

        outdir = tmp_path / "dist"
        result = subprocess.run(
            [
                sys.executable,
                "-m",
                "build",
                "--wheel",
                "--sdist",
                "--no-isolation",
                "--outdir",
                str(outdir),
                str(BOSCO_DIR),
            ],
            capture_output=True,
            text=True,
        )
        assert result.returncode == 0, (
            f"build failed:\nSTDOUT:\n{result.stdout}\nSTDERR:\n{result.stderr}"
        )

        wheels = list(outdir.glob("*.whl"))
        sdists = list(outdir.glob("*.tar.gz"))
        assert len(wheels) == 1, f"expected one wheel, got {wheels}"
        assert len(sdists) == 1, f"expected one sdist, got {sdists}"

        with zipfile.ZipFile(wheels[0]) as zf:
            names = zf.namelist()
        assert "bosco/static/index.html" in names, (
            f"wheel missing bundled SPA asset; names={names}"
        )
    finally:
        if not had_real_index:
            _remove_placeholder_index()


# --------------------------------------------------------------------------- #
# Requirements 10.1-10.7: isolation of backend/ and frontend/; code under bosco/
# --------------------------------------------------------------------------- #

def _git_available() -> bool:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--is-inside-work-tree"],
            cwd=str(WORKSPACE_ROOT),
            capture_output=True,
            text=True,
        )
    except (FileNotFoundError, OSError):
        return False
    return result.returncode == 0 and result.stdout.strip() == "true"


def _git_changed_tracked_paths() -> list[str]:
    """Return tracked paths that are MODIFIED/DELETED/RENAMED in tree or index.

    Untracked files ("??") are ignored -- new bundled assets or dist artifacts
    are allowed. Only pre-existing tracked files that were changed count.
    """
    result = subprocess.run(
        ["git", "status", "--porcelain"],
        cwd=str(WORKSPACE_ROOT),
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr

    changed: list[str] = []
    for line in result.stdout.splitlines():
        if not line.strip():
            continue
        status = line[:2]
        rest = line[3:]
        if status == "??":
            # Untracked -- allowed.
            continue
        # Handle renames: "old -> new".
        if " -> " in rest:
            old, new = rest.split(" -> ", 1)
            changed.extend([old.strip().strip('"'), new.strip().strip('"')])
        else:
            changed.append(rest.strip().strip('"'))
    return changed


@pytest.mark.skipif(not _git_available(), reason="not a git repository / git unavailable")
def test_backend_and_frontend_tracked_files_unchanged():
    """No tracked file under backend/ or frontend/ is modified or deleted."""
    changed = _git_changed_tracked_paths()
    offenders = [
        p
        for p in changed
        if p.startswith("backend/") or p.startswith("frontend/")
    ]
    assert not offenders, f"isolation violated; changed tracked paths: {offenders}"


def test_new_code_lives_under_bosco():
    """The bosco/ package exists with its key modules and pyproject (Req 10.7)."""
    assert BOSCO_DIR.is_dir()
    src = BOSCO_DIR / "src" / "bosco"
    for module in ("app.py", "cli.py", "serving.py", "state.py", "util.py"):
        assert (src / module).is_file(), f"missing module: {module}"
    assert (BOSCO_DIR / "pyproject.toml").is_file()
