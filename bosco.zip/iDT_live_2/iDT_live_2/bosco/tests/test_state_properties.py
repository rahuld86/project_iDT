"""Property-based tests for the in-memory state facade (``bosco.state``).

Covers two correctness properties from the design document:

* **Property 7: In-memory write/read round-trip within a run** -- values written
  through the :class:`InMemorySessionManager` facade (DataFrames via
  ``set_dataframe`` plus the scalar / list fields set on the resolved
  :class:`AppState`) are read back equivalently within the same running process.
  Validates Requirements 4.2.

* **Property 8: Fresh empty state on a new run** -- after arbitrary mutations on
  one manager, constructing a *new* manager (simulating a new process launch)
  yields an :class:`AppState` equal to the default empty state.
  Validates Requirements 4.4.

Each correctness property is implemented by exactly ONE property-based test and
runs for a minimum of 100 iterations (``@settings(max_examples=100)``).
"""

from __future__ import annotations

import pandas as pd
from hypothesis import given, settings, strategies as st
from hypothesis.extra.pandas import column, data_frames, range_indexes

from bosco.state import AppState, InMemorySessionManager


# --------------------------------------------------------------------------- #
# Strategies
# --------------------------------------------------------------------------- #

# Small DataFrames (a few rows / cols) keep each example fast. Columns use a
# mix of integer and float dtypes so round-trip equality must survive dtype.
_small_dataframes = data_frames(
    columns=[
        column("a", dtype=int),
        column("b", dtype=float),
        column("c", dtype=int),
    ],
    index=range_indexes(min_size=0, max_size=5),
)

# Strategies for the scalar / list AppState fields that the facade round-trips.
_optional_text = st.one_of(st.none(), st.text(max_size=12))
_small_ints = st.integers(min_value=0, max_value=20)
_criteria = st.sampled_from(["entropy", "gini", "mse"])
_df_col = st.lists(
    st.fixed_dictionaries(
        {
            "column_name": st.text(max_size=8),
            "datatype": st.sampled_from(["int", "float", "str", "category"]),
        }
    ),
    max_size=4,
)
_node_master = st.lists(
    st.fixed_dictionaries(
        {
            "node_id": st.integers(min_value=0, max_value=50),
            "label": st.text(max_size=8),
        }
    ),
    max_size=4,
)
_x_col = st.lists(st.text(max_size=8), max_size=4)


# --------------------------------------------------------------------------- #
# Property 7
# --------------------------------------------------------------------------- #

# Feature: pip-installable-package, Property 7: In-memory write/read round-trip within a run
@settings(max_examples=100)
@given(
    file_name=_optional_text,
    original_data_source=_optional_text,
    badflag=_optional_text,
    regression_flag=st.integers(min_value=0, max_value=1),
    max_depth=_small_ints,
    min_node_split=_small_ints,
    min_leaf_size=_small_ints,
    max_branches=_small_ints,
    criteria=_criteria,
    unique_var=_small_ints,
    monotonic=_small_ints,
    df_col=_df_col,
    node_master=_node_master,
    x_col=_x_col,
    df=_small_dataframes,
    df_for_tree=_small_dataframes,
)
def test_property_7_in_memory_write_read_round_trip(
    file_name,
    original_data_source,
    badflag,
    regression_flag,
    max_depth,
    min_node_split,
    min_leaf_size,
    max_branches,
    criteria,
    unique_var,
    monotonic,
    df_col,
    node_master,
    x_col,
    df,
    df_for_tree,
):
    """Values written through the facade read back equivalently within a run.

    Validates: Requirements 4.2
    """
    manager = InMemorySessionManager()
    sid = "local"
    state = manager.resolve(sid)

    # Write the scalar / list fields directly on the resolved live state.
    state.file_name = file_name
    state.original_data_source = original_data_source
    state.badflag = badflag
    state.regression_flag = regression_flag
    state.max_depth = max_depth
    state.min_node_split = min_node_split
    state.min_leaf_size = min_leaf_size
    state.max_branches = max_branches
    state.criteria = criteria
    state.unique_var = unique_var
    state.monotonic = monotonic
    state.df_col = df_col
    state.node_master = node_master
    state.X_col = x_col

    # Write the heavy frames through the facade's write path.
    manager.set_dataframe(sid, state, "df", df)
    manager.set_dataframe(sid, state, "df_for_tree", df_for_tree)

    # Read back through resolve / active_df / active_df_for_tree.
    read_state = manager.resolve(sid)

    assert read_state.file_name == file_name
    assert read_state.original_data_source == original_data_source
    assert read_state.badflag == badflag
    assert read_state.regression_flag == regression_flag
    assert read_state.max_depth == max_depth
    assert read_state.min_node_split == min_node_split
    assert read_state.min_leaf_size == min_leaf_size
    assert read_state.max_branches == max_branches
    assert read_state.criteria == criteria
    assert read_state.unique_var == unique_var
    assert read_state.monotonic == monotonic
    assert read_state.df_col == df_col
    assert read_state.node_master == node_master
    assert read_state.X_col == x_col

    # The heavy frames round-trip to equivalent DataFrames.
    pd.testing.assert_frame_equal(manager.active_df(read_state), df)
    pd.testing.assert_frame_equal(
        manager.active_df_for_tree(read_state), df_for_tree
    )


# --------------------------------------------------------------------------- #
# Property 8
# --------------------------------------------------------------------------- #

# Feature: pip-installable-package, Property 8: Fresh empty state on a new run
@settings(max_examples=100)
@given(
    file_name=_optional_text,
    original_data_source=_optional_text,
    badflag=_optional_text,
    regression_flag=st.integers(min_value=0, max_value=1),
    max_depth=_small_ints,
    min_node_split=_small_ints,
    min_leaf_size=_small_ints,
    max_branches=_small_ints,
    criteria=_criteria,
    unique_var=_small_ints,
    monotonic=_small_ints,
    df_col=_df_col,
    node_master=_node_master,
    x_col=_x_col,
    df=_small_dataframes,
    df_for_tree=_small_dataframes,
)
def test_property_8_fresh_empty_state_on_new_run(
    file_name,
    original_data_source,
    badflag,
    regression_flag,
    max_depth,
    min_node_split,
    min_leaf_size,
    max_branches,
    criteria,
    unique_var,
    monotonic,
    df_col,
    node_master,
    x_col,
    df,
    df_for_tree,
):
    """A newly constructed manager yields the default empty AppState.

    Mutations applied to one manager must not leak into a freshly constructed
    manager (which simulates a brand-new process launch).

    Validates: Requirements 4.4
    """
    # Apply arbitrary mutations to the first manager's state.
    mutated = InMemorySessionManager()
    sid = "local"
    state = mutated.resolve(sid)
    state.file_name = file_name
    state.original_data_source = original_data_source
    state.badflag = badflag
    state.regression_flag = regression_flag
    state.max_depth = max_depth
    state.min_node_split = min_node_split
    state.min_leaf_size = min_leaf_size
    state.max_branches = max_branches
    state.criteria = criteria
    state.unique_var = unique_var
    state.monotonic = monotonic
    state.df_col = df_col
    state.node_master = node_master
    state.X_col = x_col
    mutated.set_dataframe(sid, state, "df", df)
    mutated.set_dataframe(sid, state, "df_for_tree", df_for_tree)

    # Simulate a new process launch: a brand-new manager instance.
    fresh = InMemorySessionManager()

    # Its resolved state must equal a default empty AppState. A default
    # AppState has df=None / df_for_tree=None, so dataclass equality is
    # well-defined (no DataFrame truthiness ambiguity).
    assert fresh.resolve(sid) == AppState()
