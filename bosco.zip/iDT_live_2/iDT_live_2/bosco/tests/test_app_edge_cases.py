"""Extra example tests for Bosco app edge cases (Requirements 6.1, 6.2).

These are standard pytest example tests (NOT property-based) that exercise
upload/download and content-type edge cases *beyond* the required set already
covered in ``test_app.py``. They assert the app's ACTUAL observed behavior for
unusual inputs so the behavior is pinned down and regressions are caught.

Covered here:

* Upload rejections: a non-CSV (``.txt``) multipart file (6.1); a multipart
  POST with no ``file`` part (6.1).
* Upload of a headers-only CSV (0 data rows) handled gracefully (6.1).
* Upload JSON body pointing at a nonexistent local path -> file-not-found (6.1).
* ``downloadTree`` before any tree is initialized -> 400 error (6.2).
* ``downloadTree`` after seeding ``node_master`` -> the downloaded JSON includes
  the ``hyperparameters``-adjacent fields and the ``mapper`` key (6.2); a
  different angle than ``test_app.py`` which checks the attachment disposition.
* ``exportTree`` before any tree is initialized -> 400 error (6.2).
* Content types: ``GET /`` serves ``index.html`` as ``text/html`` (2.x); a
  bundled ``.js`` asset is served with a JavaScript mimetype (2.3).

The in-memory ``session_manager`` singleton is reset before and after every
test via an autouse fixture so state never bleeds between tests.
"""

from __future__ import annotations

import io
import json
import shutil
import tempfile
from pathlib import Path

import pytest

from bosco.app import create_app
from bosco.state import session_manager


INDEX_SENTINEL = "<!doctype html><html><body>BOSCO_SPA_SHELL_SENTINEL</body></html>"


@pytest.fixture(autouse=True)
def reset_state():
    """Reset the single-user in-memory state before and after each test."""
    session_manager.purge("local")
    yield
    session_manager.purge("local")


@pytest.fixture
def static_dir():
    """A temp static dir containing a sentinel ``index.html`` and a ``.js`` asset."""
    d = Path(tempfile.mkdtemp(prefix="bosco_edge_static_"))
    (d / "index.html").write_text(INDEX_SENTINEL, encoding="utf-8")
    assets = d / "assets"
    assets.mkdir(parents=True, exist_ok=True)
    (assets / "app.js").write_text("console.log('bosco');\n", encoding="utf-8")
    yield d
    shutil.rmtree(d, ignore_errors=True)


@pytest.fixture
def client(static_dir):
    """A Flask test client for an app built over the temp static dir."""
    app = create_app(static_dir=static_dir)
    return app.test_client()


# --------------------------------------------------------------------------- #
# Upload edge cases (Requirement 6.1)
# --------------------------------------------------------------------------- #

def test_upload_rejects_non_csv_extension(client):
    """A multipart upload with a .txt file is rejected (not a 200 success)."""
    data = {"file": (io.BytesIO(b"hello world\n"), "notes.txt")}
    resp = client.post("/api/upload", data=data, content_type="multipart/form-data")

    assert resp.status_code == 400, resp.get_data(as_text=True)
    payload = resp.get_json()
    assert payload is not None and "error" in payload
    assert "csv" in payload["error"].lower()


def test_upload_multipart_missing_file_part(client):
    """A multipart POST with no 'file' part returns a 400 error, not a 200."""
    # Send a multipart body with a different field name so request.files is
    # non-empty but 'file' is absent.
    data = {"notfile": (io.BytesIO(b"a,b\n1,2\n"), "data.csv")}
    resp = client.post("/api/upload", data=data, content_type="multipart/form-data")

    assert resp.status_code == 400, resp.get_data(as_text=True)
    payload = resp.get_json()
    assert payload is not None and "error" in payload
    assert "no file" in payload["error"].lower()


def test_upload_headers_only_csv_zero_rows(client):
    """A CSV with only a header row is accepted and reports rows == 0.

    pandas reads a header-only CSV as a 0-row DataFrame, so the upload succeeds
    with a valid summary rather than erroring. This pins the graceful-handling
    behavior.
    """
    data = {"file": (io.BytesIO(b"a,b,c\n"), "headers_only.csv")}
    resp = client.post("/api/upload", data=data, content_type="multipart/form-data")

    assert resp.status_code == 200, resp.get_data(as_text=True)
    payload = resp.get_json()
    assert payload["rows"] == 0
    assert payload["columns"] == 3
    assert payload["columnsList"] == ["a", "b", "c"]
    assert payload["sample"] == []


def test_upload_json_nonexistent_local_path(client):
    """A JSON upload with a nonexistent local path returns file-not-found (404)."""
    resp = client.post(
        "/api/upload",
        data=json.dumps({"file": "definitely_not_a_real_file_12345.csv"}),
        content_type="application/json",
    )

    assert resp.status_code == 404, resp.get_data(as_text=True)
    payload = resp.get_json()
    assert payload is not None and "error" in payload
    assert "not found" in payload["error"].lower()


# --------------------------------------------------------------------------- #
# Download / export edge cases (Requirement 6.2)
# --------------------------------------------------------------------------- #

def test_download_tree_before_init_errors(client):
    """downloadTree before any tree is initialized returns a 400 with a message.

    The fresh default AppState has ``node_master is None``, which the endpoint
    treats as "no tree yet".
    """
    resp = client.get("/api/downloadTree")

    assert resp.status_code == 400, resp.get_data(as_text=True)
    payload = resp.get_json()
    assert payload is not None and "error" in payload
    assert payload["error"]  # non-empty message


def test_download_tree_payload_includes_hyperparameters_and_mapper(client):
    """After seeding node_master, the downloaded JSON carries mapper + HP fields.

    This checks the *payload contents* (a different angle than test_app.py's
    attachment-disposition check): the download body includes the ``mapper`` key
    and the hyperparameter fields seeded on state.
    """
    state = session_manager.resolve("local")
    state.badflag = "target"
    state.max_depth = 7
    state.min_node_split = 250
    state.min_leaf_size = 50
    state.max_branches = 3
    state.criteria = "gini"
    state.df_col = [
        {"column_name": "a", "datatype": "numerical"},
        {"column_name": "target", "datatype": "categorical"},
    ]
    state.node_master = [
        {"node": "Node0", "parent": "", "variable": "a", "depth": 0},
    ]

    resp = client.get("/api/downloadTree")

    assert resp.status_code == 200, resp.get_data(as_text=True)
    body = json.loads(resp.get_data(as_text=True))

    # mapper key present and reflects the seeded df_col.
    assert "mapper" in body
    assert body["mapper"] == state.df_col

    # Hyperparameter fields present and reflect the seeded values.
    assert body["badflag"] == "target"
    assert body["max_depth"] == 7
    assert body["min_node_split"] == 250
    assert body["min_leaf_size"] == 50
    assert body["max_branches"] == 3
    assert body["criteria"] == "gini"
    assert body["node_master"] == state.node_master


def test_export_tree_before_init_errors(client):
    """exportTree before any tree is initialized returns a 400 error."""
    resp = client.get("/api/exportTree")

    assert resp.status_code == 400, resp.get_data(as_text=True)
    payload = resp.get_json()
    assert payload is not None and "error" in payload
    assert payload["error"]  # non-empty message


# --------------------------------------------------------------------------- #
# Content-type edge cases (Requirements 2.3, 6.x serving)
# --------------------------------------------------------------------------- #

def test_root_index_html_content_type(client):
    """GET / serves index.html with a text/html content type."""
    resp = client.get("/")
    assert resp.status_code == 200
    content_type = resp.headers.get("Content-Type", "")
    assert "text/html" in content_type.lower()


def test_served_js_asset_has_js_mimetype(client):
    """A bundled .js asset is served with a JavaScript mimetype (2.3)."""
    resp = client.get("/assets/app.js")
    assert resp.status_code == 200, resp.get_data(as_text=True)
    content_type = resp.headers.get("Content-Type", "").lower()
    # Different platforms/stdlib versions report either of these for .js.
    assert "javascript" in content_type or "ecmascript" in content_type
