"""Property-based tests for static / SPA serving (``bosco.serving``).

Covers three correctness properties from the design document:

* **Property 1: SPA fallback for non-API, non-asset paths** -- a non-``api/``
  path with no file extension that does not collide with a bundled asset
  returns HTTP 200 with the ``index.html`` SPA shell body.
  Validates Requirements 2.4.

* **Property 2: Missing static asset returns 404** -- an asset-looking path
  (has a file extension, not under ``api/``) that is absent from the static
  directory returns HTTP 404 and does NOT fall back to the SPA shell.
  Validates Requirements 2.6.

* **Property 4: Bundled assets served with matching content type** -- a bundled
  asset present in the static directory is served with HTTP 200 and a
  ``Content-Type`` consistent with its file extension.
  Validates Requirements 2.3.

Each correctness property is implemented by exactly ONE property-based test and
runs for a minimum of 100 iterations (``@settings(max_examples=100)``).

The tests build a Flask app, register the frontend routes against a *temporary*
static directory populated from hypothesis-generated data, and drive Flask's
test client. Temporary directories are created inside the test body (hypothesis
does not compose with function-scoped ``tmp_path`` fixtures) and cleaned up.
"""

from __future__ import annotations

import mimetypes
import os
import shutil
import tempfile
from pathlib import Path

from flask import Flask
from hypothesis import assume, given, settings, strategies as st

from bosco.serving import register_frontend_routes


# --------------------------------------------------------------------------- #
# Shared helpers / strategies
# --------------------------------------------------------------------------- #

# A sentinel body written into index.html so we can positively identify the SPA
# shell in responses.
INDEX_SENTINEL = "<!doctype html><html><body>BOSCO_SPA_SHELL_SENTINEL</body></html>"

# A filesystem-safe alphabet for generated path segments: no separators, no
# dots, no reserved characters. Keeps segments portable across Windows/macOS.
_SAFE_CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-"

# Windows reserved device names (case-insensitive) to avoid as segment stems.
_RESERVED_NAMES = {
    "con", "prn", "aux", "nul",
    *(f"com{i}" for i in range(1, 10)),
    *(f"lpt{i}" for i in range(1, 10)),
}


def _safe_segment():
    """A single filesystem-safe path segment (non-empty, bounded length)."""
    return st.text(alphabet=_SAFE_CHARS, min_size=1, max_size=12)


def _safe_segments(min_size: int = 1, max_size: int = 3):
    """A list of safe segments, each avoiding reserved names."""
    return st.lists(
        _safe_segment().filter(lambda s: s.lower() not in _RESERVED_NAMES),
        min_size=min_size,
        max_size=max_size,
    )


def _build_app(static_dir: Path) -> Flask:
    """Build a minimal Flask app with only the frontend routes registered.

    Flask's default static endpoint (``/static/<path:filename>``) is disabled
    via ``static_folder=None`` so it does not shadow the ``serving.py``
    catch-all for paths beginning with ``static/``. The bundled-asset serving
    under test is driven entirely by ``register_frontend_routes``.
    """
    app = Flask(__name__, static_folder=None)
    register_frontend_routes(app, static_dir)
    return app


def _make_static_dir() -> Path:
    """Create a temp static dir containing an index.html sentinel."""
    static_dir = Path(tempfile.mkdtemp(prefix="bosco_static_"))
    (static_dir / "index.html").write_text(INDEX_SENTINEL, encoding="utf-8")
    return static_dir


# Extensions with a stable, well-known mimetype. We derive the expected type via
# ``mimetypes.guess_type`` and only keep those it can resolve on this platform,
# so the test stays robust across environments.
_CANDIDATE_EXTENSIONS = [
    ".js", ".css", ".html", ".json", ".svg", ".png", ".txt",
]
_STABLE_EXTENSIONS = [
    ext for ext in _CANDIDATE_EXTENSIONS
    if mimetypes.guess_type("x" + ext)[0] is not None
]


# --------------------------------------------------------------------------- #
# Property 1
# --------------------------------------------------------------------------- #

# Feature: pip-installable-package, Property 1: SPA fallback for non-API, non-asset paths
@settings(max_examples=100)
@given(segments=_safe_segments(min_size=1, max_size=3))
def test_property_1_spa_fallback_for_non_api_non_asset_paths(segments):
    """Non-api, extensionless, non-colliding paths return the SPA shell (200).

    Validates: Requirements 2.4
    """
    path = "/".join(segments)

    # Client-route invariants: not an API path, no file extension (so
    # ``os.path.splitext`` yields an empty ext), and not the index itself.
    assume(not path.startswith("api/") and path != "api")
    assume(os.path.splitext(path)[1] == "")
    assume(path != "index.html")

    static_dir = _make_static_dir()
    try:
        # The generated path must not collide with an existing asset. The temp
        # dir only ever contains index.html, which has an extension and is thus
        # excluded above, so no extensionless path can collide here.
        app = _build_app(static_dir)
        client = app.test_client()

        resp = client.get("/" + path)

        assert resp.status_code == 200
        assert resp.get_data(as_text=True) == INDEX_SENTINEL
    finally:
        shutil.rmtree(static_dir, ignore_errors=True)


# --------------------------------------------------------------------------- #
# Property 2
# --------------------------------------------------------------------------- #

# Feature: pip-installable-package, Property 2: Missing static asset returns 404
@settings(max_examples=100)
@given(
    segments=_safe_segments(min_size=1, max_size=3),
    ext=st.sampled_from(_STABLE_EXTENSIONS),
)
def test_property_2_missing_static_asset_returns_404(segments, ext):
    """Absent asset-looking paths return 404 and never the SPA shell.

    Validates: Requirements 2.6
    """
    path = "/".join(segments) + ext

    # Asset-looking invariants: has a file extension, not an API path.
    assume(not path.startswith("api/"))
    assume(os.path.splitext(path)[1] != "")

    static_dir = _make_static_dir()
    try:
        # Guarantee the generated asset is absent: the temp dir only contains
        # index.html. Skip the degenerate case where the path IS index.html.
        assume(not (static_dir / path).exists())

        app = _build_app(static_dir)
        client = app.test_client()

        resp = client.get("/" + path)

        assert resp.status_code == 404
        # It must not have fallen back to the SPA shell.
        assert resp.get_data(as_text=True) != INDEX_SENTINEL
    finally:
        shutil.rmtree(static_dir, ignore_errors=True)


# --------------------------------------------------------------------------- #
# Property 4
# --------------------------------------------------------------------------- #

# Feature: pip-installable-package, Property 4: Bundled assets served with matching content type
@settings(max_examples=100)
@given(
    assets=st.lists(
        st.tuples(
            _safe_segment().filter(lambda s: s.lower() not in _RESERVED_NAMES),
            st.sampled_from(_STABLE_EXTENSIONS),
        ),
        min_size=1,
        max_size=5,
        unique_by=lambda item: (item[0].lower(), item[1].lower()),
    ),
)
def test_property_4_bundled_assets_served_with_matching_content_type(assets):
    """Present bundled assets return 200 with a Content-Type matching the ext.

    Validates: Requirements 2.3
    """
    static_dir = _make_static_dir()
    try:
        # Materialize each generated asset with some bytes. Avoid clobbering the
        # index.html sentinel used to detect SPA fallback.
        asset_paths = []
        for stem, ext in assets:
            rel = stem + ext
            if rel == "index.html":
                continue
            (static_dir / rel).write_bytes(b"generated-asset-bytes\n")
            asset_paths.append(rel)

        assume(asset_paths)

        app = _build_app(static_dir)
        client = app.test_client()

        for rel in asset_paths:
            resp = client.get("/" + rel)
            assert resp.status_code == 200, rel

            expected_type = mimetypes.guess_type(rel)[0]
            assert expected_type is not None, rel

            # Flask may append a charset (e.g. "text/html; charset=utf-8"); the
            # response mimetype strips parameters, so compare the base type.
            assert resp.mimetype == expected_type, (
                rel,
                resp.mimetype,
                expected_type,
                resp.headers.get("Content-Type"),
            )
    finally:
        shutil.rmtree(static_dir, ignore_errors=True)
