"""Property-based tests for the CLI launcher (``bosco.cli``).

Covers one correctness property from the design document:

* **Property 10: Port selection returns a bindable port** --
  :func:`bosco.cli.find_available_port` returns a port that can actually be
  bound on the host, and returns the preferred port whenever that port is free.
  Validates Requirements 1.5.

The property is implemented by exactly ONE property-based test and runs for a
minimum of 100 iterations (``@settings(max_examples=100)``). Real sockets are
used to occupy ports so the test exercises genuine bind behavior; all sockets
are closed in ``finally`` blocks. ``deadline=None`` (also set by the ``bosco``
hypothesis profile) accounts for real-socket latency.
"""

from __future__ import annotations

import socket

from hypothesis import given, settings, strategies as st

from bosco.cli import find_available_port

HOST = "127.0.0.1"


def _bindable(host: str, port: int) -> bool:
    """Return True if a fresh socket can bind ``(host, port)``."""
    probe = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        probe.bind((host, port))
        return True
    except OSError:
        return False
    finally:
        probe.close()


# Feature: pip-installable-package, Property 10: Port selection returns a bindable port
@settings(max_examples=100)
@given(num_occupied=st.integers(min_value=1, max_value=5))
def test_find_available_port_returns_bindable_port(num_occupied):
    """find_available_port always yields a bindable port, and returns the
    preferred port when that port is free.

    Validates: Requirements 1.5
    """
    listeners = []
    try:
        # Occupy a handful of real ports by binding + listening on them.
        occupied_ports = []
        for _ in range(num_occupied):
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.bind((HOST, 0))
            s.listen(1)
            listeners.append(s)
            occupied_ports.append(s.getsockname()[1])

        # (a) For an occupied (in-use) port, the returned port must differ from
        #     the occupied port and must actually be bindable.
        for occupied in occupied_ports:
            chosen = find_available_port(HOST, occupied)
            assert isinstance(chosen, int)
            assert _bindable(HOST, chosen), (
                f"returned port {chosen} is not bindable (occupied={occupied})"
            )

        # (b) For a known-free port, find_available_port returns exactly that
        #     preferred port. Obtain a likely-free port by binding 0 then closing.
        tmp = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        tmp.bind((HOST, 0))
        free_port = tmp.getsockname()[1]
        tmp.close()

        chosen_free = find_available_port(HOST, free_port)
        assert chosen_free == free_port
        assert _bindable(HOST, chosen_free)
    finally:
        for s in listeners:
            s.close()
