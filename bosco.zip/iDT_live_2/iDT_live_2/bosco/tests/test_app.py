"""Unit / example tests for the Bosco Flask app factory (``bosco.app``).

These are standard pytest example tests (not property-based) covering concrete
app behaviors from the design's Testing Strategy:

* Root ``/`` returns ``index.html`` (Requirement 2.2).
* Local CSV upload accepted via multipart (Requirement 6.1).
* Download delivers payload with an attachment disposition (Requirement 6.2).
* No S3 / URL special-casing on upload (Requirements 6.3, 6.4).
* localhost CORS headers present (Requirement 9.3).
* ``create_app()`` succeeds with no auth env vars set (Requirement 5.4).

The in-memory ``session_manager`` singleton is reset before every test (see the
``reset_state`` autouse fixture) so state never bleeds between tests.
"""

from __future__ import annotations

import io
import json
import shutil
import tempfile
from pathlib import Path

import pytest

from bosco.app import create_app
from bosco.state import session_manager


INDEX_SENTINEL = "<!doctype html><html><body>BOSCO_SPA_SHELL_SENTINEL</body></html>"


@pytest.fixture(autouse=True)
def reset_state():
    """Reset the single-user in-memory state before and after each test."""
    session_manager.purge("local")
    yield
    session_manager.purge("local")


@pytest.fixture
def static_dir():
    """A temp static dir containing a sentinel ``index.html``."""
    d = Path(tempfile.mkdtemp(prefix="bosco_unit_static_"))
    (d / "index.html").write_text(INDEX_SENTINEL, encoding="utf-8")
    yield d
    shutil.rmtree(d, ignore_errors=True)


@pytest.fixture
def client(static_dir):
    """A Flask test client for an app built over the temp static dir."""
    app = create_app(static_dir=static_dir)
    return app.test_client()


# --------------------------------------------------------------------------- #
# Requirement 2.2: Root "/" returns index.html
# --------------------------------------------------------------------------- #

def test_root_returns_index_html(client):
    """GET / returns the SPA entry document with HTTP 200."""
    resp = client.get("/")
    assert resp.status_code == 200
    assert resp.get_data(as_text=True) == INDEX_SENTINEL


# --------------------------------------------------------------------------- #
# Requirement 6.1: Local CSV upload accepted (multipart)
# --------------------------------------------------------------------------- #

def test_upload_accepts_local_csv_multipart(client):
    """POST /api/upload with an in-memory multipart CSV returns a data summary."""
    csv_bytes = b"a,b,c\n1,2,3\n4,5,6\n7,8,9\n"
    data = {"file": (io.BytesIO(csv_bytes), "sample.csv")}

    resp = client.post(
        "/api/upload",
        data=data,
        content_type="multipart/form-data",
    )

    assert resp.status_code == 200, resp.get_data(as_text=True)
    payload = resp.get_json()
    # Response contract: rows/columns/sample/columnsList present.
    assert payload["rows"] == 3
    assert payload["columns"] == 3
    assert payload["columnsList"] == ["a", "b", "c"]
    assert isinstance(payload["sample"], list)
    assert payload["sample"][0] == {"a": 1, "b": 2, "c": 3}


# --------------------------------------------------------------------------- #
# Requirement 6.2: Download delivers payload
# --------------------------------------------------------------------------- #

def test_download_delivers_payload_with_attachment(client):
    """GET /api/downloadTree returns an attachment whose JSON holds node_master.

    Seeds minimal in-memory state directly (a small JSON-safe node_master and
    column mapper) rather than running the full pipeline, per the design's
    guidance to keep the download test minimal.
    """
    state = session_manager.resolve("local")
    state.original_data_source = "sample.csv"
    state.badflag = "target"
    state.df_col = [
        {"column_name": "a", "datatype": "numerical"},
        {"column_name": "target", "datatype": "categorical"},
    ]
    state.node_master = [
        {"node": "Node0", "parent": "", "variable": "a", "depth": 0},
    ]

    resp = client.get("/api/downloadTree")

    assert resp.status_code == 200, resp.get_data(as_text=True)
    assert "attachment" in resp.headers.get("Content-Disposition", "")

    body = json.loads(resp.get_data(as_text=True))
    assert body["node_master"] == state.node_master
    assert body["badflag"] == "target"


def test_download_post_also_delivers_payload(client):
    """POST /api/downloadTree behaves the same (endpoint accepts GET and POST)."""
    state = session_manager.resolve("local")
    state.node_master = [{"node": "Node0", "parent": "", "variable": "x", "depth": 0}]

    resp = client.post("/api/downloadTree")

    assert resp.status_code == 200, resp.get_data(as_text=True)
    assert "attachment" in resp.headers.get("Content-Disposition", "")
    body = json.loads(resp.get_data(as_text=True))
    assert body["node_master"] == state.node_master


# --------------------------------------------------------------------------- #
# Requirements 6.3, 6.4: No S3 / URL special-casing
# --------------------------------------------------------------------------- #

@pytest.mark.parametrize(
    "fake_path",
    [
        "s3://my-bucket/data.csv",
        "http://example.com/data.csv",
        "https://example.com/data.csv",
    ],
)
def test_upload_does_not_special_case_s3_or_url(client, fake_path):
    """A JSON upload with an s3:// or http(s):// "file" resolves as a local path.

    The packaged app performs local file I/O only (no boto3, no URL fetch). Such
    a "file" value simply fails local path resolution and returns a file-not-
    found style error (404), never a success and never an S3/URL code path.
    """
    resp = client.post(
        "/api/upload",
        data=json.dumps({"file": fake_path}),
        content_type="application/json",
    )

    # Local resolution fails -> not a success, not a network/S3 path.
    assert resp.status_code != 200, resp.get_data(as_text=True)
    assert resp.status_code in (400, 404), resp.status_code
    payload = resp.get_json()
    assert payload is not None and "error" in payload
    # It attempted LOCAL path resolution (file-not-found), not an S3 fetch.
    assert "not found" in payload["error"].lower()


# --------------------------------------------------------------------------- #
# Requirement 9.3: localhost CORS headers present
# --------------------------------------------------------------------------- #

def test_localhost_cors_headers_present(client):
    """A request with a localhost Origin gets an Access-Control-Allow-Origin."""
    resp = client.get("/api/test", headers={"Origin": "http://localhost:5173"})
    assert resp.status_code == 200
    allow_origin = resp.headers.get("Access-Control-Allow-Origin")
    assert allow_origin is not None
    assert "localhost" in allow_origin or allow_origin == "*"


def test_localhost_cors_headers_present_127(client):
    """Same, for a 127.0.0.1 Origin."""
    resp = client.get("/api/test", headers={"Origin": "http://127.0.0.1:5173"})
    assert resp.status_code == 200
    allow_origin = resp.headers.get("Access-Control-Allow-Origin")
    assert allow_origin is not None
    assert "127.0.0.1" in allow_origin or allow_origin == "*"


# --------------------------------------------------------------------------- #
# Requirement 5.4: create_app() succeeds with no auth env vars
# --------------------------------------------------------------------------- #

def test_create_app_succeeds_without_auth_env(monkeypatch, static_dir):
    """create_app() builds an app even with AUTH_USERS/JWT_SECRET_KEY unset."""
    monkeypatch.delenv("AUTH_USERS", raising=False)
    monkeypatch.delenv("JWT_SECRET_KEY", raising=False)

    app = create_app(static_dir=static_dir)
    assert app is not None

    # And the app actually serves without any auth configured.
    client = app.test_client()
    resp = client.get("/api/health")
    assert resp.status_code == 200
    assert resp.get_json()["status"] == "healthy"
