"""Property-based test for Bosco export/import round-trip equivalence.

Covers one correctness property from the design document:

* **Property 9: Export then import round-trip equivalence** -- for any uploaded
  dataset and built tree, exporting the tree via the real ``/api/exportTree``
  endpoint and then importing that exported payload via the real
  ``/api/importTree`` endpoint reproduces an equivalent tree state (equivalent
  ``node_master`` / ``df_col`` JSON structures).
  Validates Requirements 9.2.

Design approach (robust + deterministic under hypothesis):

Rather than running the heavy, potentially-flaky full tree-build pipeline on
every example, we seed the in-memory state directly through the facade
(``bosco.state.session_manager.resolve("local")``) with a SMALL, structurally
valid dataset and tree, then exercise the REAL HTTP endpoints for export and
import:

  1. Generate a tiny mapper (``df_col``): 1-3 feature columns with datatype in
     {numerical, categorical} plus a binary ``badflag`` column, and a small but
     structurally valid ``node_master`` (a root 'Parent' row plus maybe one
     child) mirroring the shape produced by ``df_to_json_safe`` on a
     node_master. The scalar fields (badflag, hyperparameters) and ``df_col``
     are set on the state.
  2. Call the real ``exportTree`` endpoint -> capture the exported JSON payload.
  3. Write a tiny REAL temp CSV whose columns match the mapper feature columns
     plus the badflag column, and point the payload's ``file_name`` at it. This
     is option (a) from the task: the most faithful round-trip, because
     ``importTree`` genuinely loads that CSV to rebuild ``df_for_tree`` rather
     than falling back to a mock dataset.
  4. ``purge("local")`` to simulate a fresh import target, then deliver the
     exported payload to the real ``importTree`` endpoint as a multipart
     ``.json`` file upload. (This is deliberate: when ``importTree`` receives a
     *JSON body* whose ``file_name`` ends in ``.csv`` it takes a dedicated
     "start a fresh CSV import" early-return branch that reports dataset
     dimensions and never processes the tree. The tree-import path is the
     non-CSV-file branch, reached by uploading the tree payload as a ``.json``
     file whose inner ``file_name`` points at the real CSV. We use that path so
     the node_master / mapper are genuinely round-tripped.)
  5. Assert the ``node_master`` and ``mapper`` (``df_col``) produced by import
     are structurally EQUIVALENT to what was exported, comparing normalized
     JSON (``json.loads(json.dumps(...))``) so NaN/None and float-formatting
     differences do not cause spurious failures.

Scoping note: both ``exportTree`` and ``importTree`` route the small tables
through ``df_to_json_safe(pd.DataFrame(...))``. The true, by-design invariant of
the round-trip is therefore that the ``node_master`` and ``mapper`` (``df_col``)
are preserved structurally across the export -> import cycle. ``importTree``
additionally *derives* ``df_for_tree`` / ``X_col`` from the loaded CSV (that is
by design, per the state model), so this property is scoped to the invariant
node_master / df_col structures exactly as the design specifies ("equivalent
``node_master`` / ``df_col`` JSON structures"). Both the export and the import
go through the REAL endpoints -- nothing is bypassed.

The in-memory ``session_manager`` singleton is reset before every example so
state never bleeds between examples.
"""

from __future__ import annotations

import io
import json
import os
import shutil
import tempfile
from pathlib import Path

from hypothesis import given, settings, strategies as st

from bosco.app import create_app
from bosco.state import session_manager


INDEX_SENTINEL = "<!doctype html><html><body>BOSCO_SPA_SHELL_SENTINEL</body></html>"


def _make_client():
    """Build a Flask test client over a temp static dir with a sentinel shell."""
    d = Path(tempfile.mkdtemp(prefix="bosco_roundtrip_static_"))
    (d / "index.html").write_text(INDEX_SENTINEL, encoding="utf-8")
    app = create_app(static_dir=d)
    return app.test_client(), d


def _normalize(obj):
    """Normalize a JSON-ish structure for tolerant structural comparison.

    Round-trips through ``json.dumps``/``json.loads`` so that NaN/None handling
    and container shapes are compared consistently, avoiding float-formatting
    and dtype pitfalls.
    """
    return json.loads(json.dumps(obj, default=str, sort_keys=True))


# ---------------------------------------------------------------------------
# Hypothesis strategies: a small, structurally valid dataset + tree.
# ---------------------------------------------------------------------------

# Feature column names are drawn from a fixed, filesystem/pandas-safe pool so
# generated CSV headers and mapper rows always agree and stay tiny.
_COLUMN_POOL = ["feat_a", "feat_b", "feat_c"]
_BADFLAG = "badflag"


@st.composite
def _datasets(draw):
    """Generate (mapper rows, node_master rows, csv_rows, feature_cols).

    * mapper: 1-3 feature columns (numerical/categorical) + the badflag column.
    * node_master: a root 'Parent' row, optionally one child row referencing a
      generated feature column, mirroring df_to_json_safe output shape.
    * csv_rows: 3-10 rows of JSON-safe values matching the mapper columns.
    """
    n_features = draw(st.integers(min_value=1, max_value=3))
    feature_cols = _COLUMN_POOL[:n_features]
    # Assign each feature a datatype.
    datatypes = {
        col: draw(st.sampled_from(["numerical", "categorical"]))
        for col in feature_cols
    }

    # mapper rows: features + badflag (badflag datatype mirrors original mapper
    # shape; it is a numerical 0/1 target).
    mapper = [
        {"column_name": col, "datatype": datatypes[col]} for col in feature_cols
    ]
    mapper.append({"column_name": _BADFLAG, "datatype": "numerical"})

    # node_master: root 'Parent' row (shape per util.init_setup / df_to_json_safe).
    root = {
        "node_number": 1,
        "parent_node": 0,
        "variable": "Parent",
        "lower_bound": "Parent",
        "upper_bound": "Parent",
        "list_values": "",
        "missing": 0,
        "leaf_flag": 0,
        "node_label": "Parent",
    }
    node_master = [root]
    # Optionally add one child referencing a real feature column.
    if draw(st.booleans()):
        child_var = draw(st.sampled_from(feature_cols))
        child = {
            "node_number": 2,
            "parent_node": 1,
            "variable": child_var,
            "lower_bound": 0,
            "upper_bound": 1,
            "list_values": [1, 2] if datatypes[child_var] == "categorical" else "",
            "missing": 0,
            "leaf_flag": 1,
            "node_label": "child",
        }
        node_master.append(child)

    # csv rows: small table matching mapper feature columns + badflag.
    n_rows = draw(st.integers(min_value=3, max_value=10))
    csv_rows = []
    for _ in range(n_rows):
        row = {}
        for col in feature_cols:
            if datatypes[col] == "numerical":
                row[col] = draw(st.integers(min_value=0, max_value=100))
            else:
                row[col] = draw(st.sampled_from(["cat1", "cat2", "cat3"]))
        row[_BADFLAG] = draw(st.sampled_from([0, 1]))
        csv_rows.append(row)

    return mapper, node_master, csv_rows, feature_cols


# Feature: pip-installable-package, Property 9: Export then import round-trip equivalence
@settings(max_examples=100, deadline=None)
@given(data=_datasets())
def test_export_import_round_trip_equivalence(data):
    """Export then import reproduces equivalent node_master / df_col (mapper).

    Validates Requirements 9.2.
    """
    session_manager.purge("local")

    mapper, node_master, csv_rows, feature_cols = data

    client, static_dir = _make_client()
    csv_path = None
    try:
        # --- Seed a built-tree state directly through the facade ---
        state = session_manager.resolve("local")
        state.file_name = "seed.csv"
        state.badflag = _BADFLAG
        state.max_depth = 5
        state.min_node_split = 500
        state.min_leaf_size = 100
        state.max_branches = 5
        state.criteria = "entropy"
        state.unique_var = 0
        state.monotonic = 0
        state.df_col = mapper
        state.node_master = node_master
        session_manager.persist("local", state)

        # --- 1. Export via the REAL endpoint ---
        export_resp = client.post("/api/exportTree")
        assert export_resp.status_code == 200, export_resp.get_data(as_text=True)
        exported = export_resp.get_json()
        assert "node_master" in exported and "mapper" in exported

        exported_node_master = _normalize(exported["node_master"])
        exported_mapper = _normalize(exported["mapper"])

        # --- 2. Write a real temp CSV whose columns match the mapper so the
        #        import JSON+CSV branch genuinely loads data (option a). ---
        fd, csv_path = tempfile.mkstemp(suffix=".csv", prefix="bosco_rt_")
        os.close(fd)
        header = feature_cols + [_BADFLAG]
        lines = [",".join(header)]
        for row in csv_rows:
            lines.append(",".join(str(row[col]) for col in header))
        Path(csv_path).write_text("\n".join(lines) + "\n", encoding="utf-8")

        # Point the exported payload's file_name at the real CSV so importTree
        # can load it (for df_for_tree) rather than falling back to a mock
        # dataset.
        import_payload = dict(exported)
        import_payload["file_name"] = csv_path

        # --- 3. Reset state to simulate a fresh import target ---
        session_manager.purge("local")

        # --- 4. Import via the REAL endpoint, delivering the tree payload as a
        #        multipart .json file upload so importTree takes its tree-import
        #        path (not the "fresh CSV import" early return). ---
        payload_bytes = json.dumps(import_payload).encode("utf-8")
        import_resp = client.post(
            "/api/importTree",
            data={"file": (io.BytesIO(payload_bytes), "tree_export.json")},
            content_type="multipart/form-data",
        )
        assert import_resp.status_code == 200, import_resp.get_data(as_text=True)
        import_result = import_resp.get_json()
        assert "node_master" in import_result

        # --- 5. Compare normalized node_master / df_col (mapper) structures ---
        imported_node_master = _normalize(import_result["node_master"])
        assert imported_node_master == exported_node_master, (
            "node_master not preserved across export->import round-trip:\n"
            f"exported={exported_node_master}\nimported={imported_node_master}"
        )

        # df_col (mapper) is read back from the resulting state after import.
        imported_state = session_manager.resolve("local")
        imported_mapper = _normalize(imported_state.df_col)
        assert imported_mapper == exported_mapper, (
            "df_col (mapper) not preserved across export->import round-trip:\n"
            f"exported={exported_mapper}\nimported={imported_mapper}"
        )
    finally:
        if csv_path is not None:
            try:
                os.remove(csv_path)
            except OSError:
                pass
        shutil.rmtree(static_dir, ignore_errors=True)
        session_manager.purge("local")
