"""Property-based tests for the Bosco Flask app factory (``bosco.app``).

Covers three correctness properties from the design document that concern API
routing and authentication behavior of the assembled app (not the pure static
serving layer exercised in ``test_serving_properties.py``):

* **Property 3: API paths never return the SPA shell** -- any request under
  ``/api/`` is produced by API routing (a handler result or an API-level
  404/405) and is never the Frontend_Assets ``index.html`` shell.
  Validates Requirements 2.5.

* **Property 5: Preserved endpoints reachable without authentication** -- each
  of the 24 preserved endpoints is registered/reachable and never rejects a
  credential-free request with a 401 or an auth redirect to ``/login``.
  Validates Requirements 5.1, 5.2, 9.1.

* **Property 6: Dropped endpoints return 404** -- each of the 5 dropped
  endpoints (``/api/login``, ``/api/logout``, ``/api/user``, ``/api/verify``,
  ``/api/uploadFileToS3``) is not registered, so a GET returns 404 and never
  the SPA shell.
  Validates Requirements 5.3, 9.1.

Each correctness property is implemented by exactly ONE property-based test and
runs for a minimum of 100 iterations (``@settings(max_examples=100)``).

The app under test is built via ``create_app(static_dir=...)`` pointed at a
temporary static directory containing a sentinel ``index.html`` so the SPA shell
body is unambiguously identifiable. State is reset between examples via the
``session_manager`` singleton so examples do not bleed into one another.
"""

from __future__ import annotations

import shutil
import tempfile
from pathlib import Path

from hypothesis import assume, given, settings, strategies as st

from bosco.app import create_app
from bosco.state import session_manager


# A sentinel body written into index.html so the SPA shell is positively
# identifiable in any response body.
INDEX_SENTINEL = "<!doctype html><html><body>BOSCO_SPA_SHELL_SENTINEL</body></html>"


# The 24 preserved (non-auth) API endpoints (design: API surface table).
PRESERVED = [
    "/api/test",
    "/api/health",
    "/api/importTree",
    "/api/getImportDiagnostics",
    "/api/upload",
    "/api/setTarget",
    "/api/getRegressionFlag",
    "/api/getTypes",
    "/api/keepVar",
    "/api/defineHP",
    "/api/initTree",
    "/api/autoTree",
    "/api/delSubTree",
    "/api/autoTrainSubTree",
    "/api/findSplit",
    "/api/findVar",
    "/api/bestSplit",
    "/api/evalSplit",
    "/api/addNode",
    "/api/copyNode",
    "/api/labelNode",
    "/api/exportTree",
    "/api/downloadTree",
    "/api/getTreeData",
]

# The 5 dropped endpoints (design: API surface table). These routes are not
# registered on the Bosco app.
DROPPED = [
    "/api/login",
    "/api/logout",
    "/api/user",
    "/api/verify",
    "/api/uploadFileToS3",
]


# A filesystem-safe alphabet for generated path segments.
_SAFE_CHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-"


def _make_static_dir() -> Path:
    """Create a temp static dir containing an index.html sentinel."""
    static_dir = Path(tempfile.mkdtemp(prefix="bosco_app_static_"))
    (static_dir / "index.html").write_text(INDEX_SENTINEL, encoding="utf-8")
    return static_dir


def _build_client(static_dir: Path):
    """Build the full Bosco app over ``static_dir`` and return a test client."""
    # Reset the single-user in-memory state so examples do not bleed state.
    session_manager.purge("local")
    app = create_app(static_dir=static_dir)
    return app.test_client()


# --------------------------------------------------------------------------- #
# Property 3
# --------------------------------------------------------------------------- #

# Feature: pip-installable-package, Property 3: API paths never return the SPA shell
@settings(max_examples=100)
@given(
    segments=st.lists(
        st.text(alphabet=_SAFE_CHARS, min_size=1, max_size=12),
        min_size=0,
        max_size=4,
    ),
    known=st.sampled_from([None] + PRESERVED + DROPPED),
)
def test_property_3_api_paths_never_return_spa_shell(segments, known):
    """Any ``/api/...`` path is API-produced and never the SPA shell body.

    Generates arbitrary subpaths under ``/api/`` (including unknown ones) and,
    some of the time, a known preserved or dropped endpoint. Known endpoints may
    answer with 200/400/405/etc (API-produced); unknown ``/api/...`` paths 404
    via the catch-all (API-shaped). The invariant checked for ALL of them is the
    same: the response body is never the ``index.html`` SPA shell. GET is used;
    POST-only endpoints simply 405, which is still not the SPA shell.

    Validates: Requirements 2.5
    """
    if known is not None:
        path = known
    else:
        path = "/api/" + "/".join(segments) if segments else "/api"

    static_dir = _make_static_dir()
    try:
        client = _build_client(static_dir)
        resp = client.get(path)

        # The key property: an /api path is never answered with the SPA shell.
        assert resp.get_data(as_text=True) != INDEX_SENTINEL, (path, resp.status_code)
    finally:
        shutil.rmtree(static_dir, ignore_errors=True)


# --------------------------------------------------------------------------- #
# Property 5
# --------------------------------------------------------------------------- #

# Feature: pip-installable-package, Property 5: Preserved endpoints reachable without authentication
@settings(max_examples=100)
@given(endpoint=st.sampled_from(PRESERVED))
def test_property_5_preserved_endpoints_reachable_without_auth(endpoint):
    """Preserved endpoints are reachable without credentials (no 401/redirect).

    Issues BOTH a GET and a POST with NO authentication header/credentials.
    Because methods vary per endpoint (GET-only, POST-only, or both), at least
    one of the two methods must be registered for the path (never a 404 from the
    catch-all for ALL methods). For every method attempted, access is never
    blocked by authentication: no 401 and no 3xx redirect to a login page.
    Missing/empty bodies may yield 400/415/500 from business logic, which is
    acceptable -- the property is about auth not blocking access.

    Validates: Requirements 5.1, 5.2, 9.1
    """
    static_dir = _make_static_dir()
    try:
        client = _build_client(static_dir)

        responses = []
        for method in ("get", "post"):
            resp = getattr(client, method)(endpoint)
            responses.append(resp)

            # Auth must never block access.
            assert resp.status_code != 401, (endpoint, method, resp.status_code)
            # No auth redirect to a login page.
            if 300 <= resp.status_code < 400:
                location = resp.headers.get("Location", "")
                assert "/login" not in location, (endpoint, method, location)

        # The route is registered/reachable for at least one standard method
        # (i.e. not a catch-all 404 for both GET and POST).
        assert any(r.status_code != 404 for r in responses), (
            endpoint,
            [r.status_code for r in responses],
        )
    finally:
        shutil.rmtree(static_dir, ignore_errors=True)


# --------------------------------------------------------------------------- #
# Property 6
# --------------------------------------------------------------------------- #

# Feature: pip-installable-package, Property 6: Dropped endpoints return 404
@settings(max_examples=100)
@given(endpoint=st.sampled_from(DROPPED))
def test_property_6_dropped_endpoints_return_404(endpoint):
    """Dropped endpoints are not registered: a GET returns 404 (not the shell).

    The design property is "route not registered => 404". A GET on these paths
    reaches the serving.py catch-all, which 404s unknown ``/api/`` paths, so GET
    is the clean signal that the route is absent. (A POST may return 405 instead
    of 404 only because the catch-all route is GET-only -- that 405 is an
    artifact of the catch-all method set, NOT evidence of a registered endpoint.
    To test the property precisely, assert the GET case: 404 and never the SPA
    shell.)

    Validates: Requirements 5.3, 9.1
    """
    # ``endpoint`` is drawn from DROPPED; keep ``assume`` to document the domain.
    assume(endpoint in DROPPED)

    static_dir = _make_static_dir()
    try:
        client = _build_client(static_dir)
        resp = client.get(endpoint)

        assert resp.status_code == 404, (endpoint, resp.status_code)
        # A dropped route must never be answered with the SPA shell.
        assert resp.get_data(as_text=True) != INDEX_SENTINEL, endpoint
    finally:
        shutil.rmtree(static_dir, ignore_errors=True)
