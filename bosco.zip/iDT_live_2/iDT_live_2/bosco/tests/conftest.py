"""Shared pytest configuration for the bosco test suite.

Registers a hypothesis profile so property tests default to at least 100
iterations. Individual property tests should still set an explicit
``@settings(max_examples=100)`` (or more) per the design's testing rules;
this profile is a safety net that enforces the minimum globally.
"""

from hypothesis import settings, HealthCheck

# A profile that enforces the design's minimum of 100 examples per property.
settings.register_profile(
    "bosco",
    max_examples=100,
    deadline=None,
    suppress_health_check=[HealthCheck.too_slow],
)

# Load it by default for this suite. Tests may still override via their own
# @settings decorators.
settings.load_profile("bosco")
