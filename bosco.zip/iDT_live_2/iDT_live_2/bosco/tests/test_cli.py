"""Unit / example tests for the Bosco launcher (``bosco.cli``).

Covers:

* ``parse_args`` defaults and overrides.
* ``main()`` prints the local URL WITHOUT any token (Requirements 1.3, 5.5).
* ``--no-browser`` suppresses the browser launch (Requirement 1.4).
* Without ``--no-browser`` the browser-open path is attempted (Requirement 1.4).

``waitress.serve`` is always patched to a no-op so no real server starts, and
``webbrowser.open`` is patched so no browser is launched. ``find_available_port``
is patched to a fixed port for deterministic output. A fake ``waitress`` module
is injected into ``sys.modules`` if the real package is not importable, so the
lazy ``from waitress import serve`` inside ``main`` resolves without the
dependency being installed.
"""

from __future__ import annotations

import sys
import types
from unittest.mock import Mock

import pytest

from bosco import cli


@pytest.fixture
def fake_waitress(monkeypatch):
    """Ensure ``waitress.serve`` is a no-op Mock, injecting a fake module if
    the real ``waitress`` package is not installed.

    Yields the ``serve`` Mock so tests can assert it was invoked.
    """
    serve_mock = Mock(name="waitress.serve")
    module = sys.modules.get("waitress")
    if module is None:
        module = types.ModuleType("waitress")
        monkeypatch.setitem(sys.modules, "waitress", module)
    monkeypatch.setattr(module, "serve", serve_mock, raising=False)
    yield serve_mock


# --------------------------------------------------------------------------- #
# parse_args
# --------------------------------------------------------------------------- #
def test_parse_args_defaults():
    ns = cli.parse_args([])
    assert ns.host == "127.0.0.1"
    assert ns.port == 8765
    assert ns.no_browser is False


def test_parse_args_overrides():
    ns = cli.parse_args(["--host", "0.0.0.0", "--port", "9999", "--no-browser"])
    assert ns.host == "0.0.0.0"
    assert ns.port == 9999
    assert ns.no_browser is True


# --------------------------------------------------------------------------- #
# main() URL output
# --------------------------------------------------------------------------- #
def test_main_prints_url_without_token(monkeypatch, capsys, fake_waitress):
    """main() prints the running URL and never leaks a token (Req 1.3, 5.5)."""
    monkeypatch.setattr(cli, "find_available_port", lambda host, port: 8765)
    monkeypatch.setattr(cli.webbrowser, "open", Mock())

    rc = cli.main(["--no-browser"])

    assert rc == 0
    out = capsys.readouterr().out
    assert "http://127.0.0.1:8765" in out
    assert "token" not in out.lower()
    fake_waitress.assert_called_once()


# --------------------------------------------------------------------------- #
# --no-browser behavior
# --------------------------------------------------------------------------- #
def test_no_browser_suppresses_browser_launch(monkeypatch, fake_waitress):
    """--no-browser means webbrowser.open is never called (Req 1.4)."""
    monkeypatch.setattr(cli, "find_available_port", lambda host, port: 8765)
    open_mock = Mock()
    monkeypatch.setattr(cli.webbrowser, "open", open_mock)

    rc = cli.main(["--no-browser"])

    assert rc == 0
    open_mock.assert_not_called()
    fake_waitress.assert_called_once()


def test_browser_launch_attempted_without_flag(monkeypatch, fake_waitress):
    """Without --no-browser, the readiness check runs and webbrowser.open is
    called (Req 1.4). The readiness poll is replaced with an immediate return
    so the test is deterministic, and the browser-open thread is joined.
    """
    monkeypatch.setattr(cli, "find_available_port", lambda host, port: 8765)
    open_mock = Mock()
    monkeypatch.setattr(cli.webbrowser, "open", open_mock)

    started_threads = []
    real_thread_cls = cli.threading.Thread

    def capture_thread(*args, **kwargs):
        t = real_thread_cls(*args, **kwargs)
        started_threads.append(t)
        return t

    monkeypatch.setattr(cli.threading, "Thread", capture_thread)

    # Make the readiness helper call webbrowser.open immediately (no polling).
    def immediate(host, port, url, timeout=5.0):
        cli.webbrowser.open(url)

    monkeypatch.setattr(cli, "_open_browser_when_ready", immediate)

    rc = cli.main([])

    assert rc == 0
    # Join the browser-open thread so the assertion is race-free.
    for t in started_threads:
        t.join(timeout=5.0)

    open_mock.assert_called_once_with("http://127.0.0.1:8765")
    fake_waitress.assert_called_once()


def test_main_serves_with_single_thread(monkeypatch, fake_waitress):
    """main() invokes waitress.serve with threads=1 on the chosen host/port."""
    monkeypatch.setattr(cli, "find_available_port", lambda host, port: 8765)
    monkeypatch.setattr(cli.webbrowser, "open", Mock())

    cli.main(["--no-browser"])

    _, kwargs = fake_waitress.call_args
    assert kwargs.get("host") == "127.0.0.1"
    assert kwargs.get("port") == 8765
    assert kwargs.get("threads") == 1
