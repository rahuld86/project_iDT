"""Smoke test confirming the test tooling and package import work.

Verifies that:
  * the ``bosco`` package is importable in the test environment, and
  * hypothesis property tests run (trivial always-true property).
"""

from hypothesis import given, settings, strategies as st

import bosco


def test_bosco_importable_with_expected_version():
    assert bosco.__version__ == "0.1.0"


@settings(max_examples=100)
@given(st.integers())
def test_hypothesis_runs(n):
    # Trivial property: adding zero is a no-op. Confirms hypothesis executes.
    assert n + 0 == n
