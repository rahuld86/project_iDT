#!/usr/bin/env python3
"""Frontend build helper for the ``bosco`` package.

This script builds the Vite/React frontend from the bundled bosco COPY of the
frontend (``bosco/frontend/tree-forge-ui/``) -- NOT the original top-level
``frontend/tree-forge-ui/``. The bosco copy contains the local no-auth login
bypass (``authService.isAuthenticated()`` always returns ``true``), so the
packaged app lands directly on the dashboard instead of showing a login page.
It copies ONLY the build output (``dist/``) into the package's static asset
directory (``bosco/src/bosco/static/``). The built app uses the relative
``/api`` base so it talks to the same origin that serves it; this is achieved
by running the build with ``VITE_API_BASE_URL`` UNSET.

Build-time vs runtime
---------------------
Node.js / npm are required to RUN this script (it invokes ``npm ci`` /
``npm install`` and ``npm run build``). This is a packaging / build-time step
only -- the end user who ``pip install``s ``bosco`` never needs Node.js, because
the pre-built ``static/`` assets are bundled into the wheel.

Isolation constraint (Requirement 10.2 / 3.2)
--------------------------------------------
This script MUST NOT modify any tracked source files under the original
top-level ``frontend/``. It builds the self-contained bosco copy under
``bosco/frontend/tree-forge-ui/`` instead. Running the build produces that
copy's own normal ``dist/`` output (its standard build artifact directory),
and all writes made by this script go only under ``bosco/``.

Usage
-----
    python bosco/scripts/build_frontend.py

Paths are resolved relative to this file's location, so the script works
regardless of the current working directory.
"""

from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# Path resolution (relative to this script, independent of cwd)
# ---------------------------------------------------------------------------
# <workspace_root>/bosco/scripts/build_frontend.py
#   parent           -> <workspace_root>/bosco/scripts
#   parent.parent    -> <workspace_root>/bosco              (the Bosco_Dir)
#   parent.parent.parent -> <workspace_root>
_SCRIPT_PATH = Path(__file__).resolve()
_BOSCO_DIR = _SCRIPT_PATH.parent.parent
_WORKSPACE_ROOT = _BOSCO_DIR.parent

# Build from the bundled bosco COPY of the frontend (which contains the local
# no-auth login bypass), NOT the original top-level frontend/tree-forge-ui.
DEFAULT_FRONTEND_DIR = _BOSCO_DIR / "frontend" / "tree-forge-ui"
DEFAULT_STATIC_DIR = _BOSCO_DIR / "src" / "bosco" / "static"

# Name of the Vite build output directory (its standard output location).
DIST_DIRNAME = "dist"


def _resolve_npm() -> str:
    """Locate the npm executable, accounting for Windows (``npm.cmd``).

    Raises:
        SystemExit: if npm cannot be found on PATH.
    """
    # On Windows npm is typically ``npm.cmd``; shutil.which resolves the right
    # variant when given the base name, but we also try explicit candidates.
    candidates = ["npm"]
    if os.name == "nt":
        candidates = ["npm.cmd", "npm.exe", "npm"]

    for name in candidates:
        found = shutil.which(name)
        if found:
            return found

    raise SystemExit(
        "npm was not found on PATH. Node.js and npm are required to build the "
        "frontend. Install Node.js (https://nodejs.org/) and try again. "
        "Note: this is a build-time requirement only; end users installing the "
        "bosco wheel do not need Node.js."
    )


def _run_npm_build(frontend_dir: Path) -> None:
    """Run ``npm ci`` (fallback ``npm install``) then ``npm run build``.

    The build runs with ``VITE_API_BASE_URL`` removed from the environment so
    the compiled assets use the relative ``/api`` base and talk same-origin.

    Args:
        frontend_dir: The frontend project directory (contains package.json).

    Raises:
        SystemExit: if npm is missing or a build command fails.
    """
    npm = _resolve_npm()

    # Build a child environment with VITE_API_BASE_URL explicitly UNSET so the
    # frontend falls back to the relative '/api' base (Requirement 3.1 / 10.5).
    env = os.environ.copy()
    env.pop("VITE_API_BASE_URL", None)

    # On Windows, .cmd shims generally need shell semantics via the resolved
    # path; passing the resolved absolute path to subprocess works without
    # shell=True in practice. We keep shell=False and rely on the resolved path.
    def _run(args: list[str]) -> int:
        completed = subprocess.run(
            args,
            cwd=str(frontend_dir),
            env=env,
            check=False,
        )
        return completed.returncode

    # Prefer the reproducible `npm ci`; fall back to `npm install` if it fails
    # (e.g. no/mismatched lockfile).
    if _run([npm, "ci"]) != 0:
        if _run([npm, "install"]) != 0:
            raise SystemExit(
                f"Dependency installation failed in {frontend_dir}. "
                "Both 'npm ci' and 'npm install' returned a non-zero exit code."
            )

    if _run([npm, "run", "build"]) != 0:
        raise SystemExit(
            f"Frontend build failed ('npm run build') in {frontend_dir}."
        )


def _copy_dist_to_static(dist_dir: Path, static_dir: Path) -> None:
    """Replace the contents of ``static_dir`` with the contents of ``dist_dir``.

    Clears everything under ``static_dir`` first (so stale assets do not linger),
    then copies the build output in. Only ``bosco/`` paths are written.

    Args:
        dist_dir: The produced build output directory (must exist).
        static_dir: The package static target directory.

    Raises:
        SystemExit: if the dist output does not exist.
    """
    if not dist_dir.is_dir():
        raise SystemExit(
            f"Frontend assets missing: expected build output directory not "
            f"found at {dist_dir}. Did 'npm run build' succeed?"
        )

    # Clear the static target (recreate empty), then copy dist contents in.
    if static_dir.exists():
        shutil.rmtree(static_dir)
    static_dir.mkdir(parents=True, exist_ok=True)

    for entry in dist_dir.iterdir():
        target = static_dir / entry.name
        if entry.is_dir():
            shutil.copytree(entry, target)
        else:
            shutil.copy2(entry, target)


def build_frontend(
    frontend_dir: Path | str | None = None,
    static_dir: Path | str | None = None,
    run_build: bool = True,
    build_runner=None,
) -> Path:
    """Build the frontend and copy its ``dist/`` output into the static dir.

    Args:
        frontend_dir: Frontend project source directory. Defaults to the
            bundled bosco copy at ``<bosco_dir>/frontend/tree-forge-ui``.
        static_dir: Package static target directory. Defaults to
            ``<workspace_root>/bosco/src/bosco/static``.
        run_build: When True (default), run the real npm build. When False, the
            build step is skipped and the existing ``dist/`` under
            ``frontend_dir`` is used as-is (useful for tests that pre-populate a
            fake ``dist/``).
        build_runner: Optional callable ``(frontend_dir: Path) -> None`` that
            performs the build. When provided it is used instead of the default
            npm build runner (useful for injecting a no-op in tests). Implies a
            build step regardless of ``run_build``.

    Returns:
        The path to the static directory that now contains the frontend assets.

    Raises:
        SystemExit: if the frontend source dir is missing, the build fails, the
            dist output is missing, or ``static_dir/index.html`` is absent after
            the copy (Requirement 3.5).
    """
    fe_dir = Path(frontend_dir) if frontend_dir is not None else DEFAULT_FRONTEND_DIR
    target_dir = Path(static_dir) if static_dir is not None else DEFAULT_STATIC_DIR
    fe_dir = fe_dir.resolve()
    target_dir = target_dir.resolve()

    if not fe_dir.is_dir():
        raise SystemExit(f"Frontend source directory not found: {fe_dir}")

    # 1. Build (unless skipped). An injected build_runner takes precedence.
    if build_runner is not None:
        build_runner(fe_dir)
    elif run_build:
        _run_npm_build(fe_dir)

    # 2. Copy only the dist output into the static target (replacing contents).
    dist_dir = fe_dir / DIST_DIRNAME
    _copy_dist_to_static(dist_dir, target_dir)

    # 3. Verify the entry document is present (Requirement 3.5).
    index_html = target_dir / "index.html"
    if not index_html.exists():
        raise SystemExit(
            f"Frontend assets missing: index.html not found at {index_html} "
            "after build+copy. The frontend build did not produce the expected "
            "entry document."
        )

    return target_dir


def parse_args(argv=None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description=(
            "Build the bosco frontend (Node.js/npm required at build time) and "
            "copy the dist/ output into the package static directory."
        )
    )
    parser.add_argument(
        "--frontend-dir",
        default=None,
        help=f"Frontend source directory (default: {DEFAULT_FRONTEND_DIR}).",
    )
    parser.add_argument(
        "--static-dir",
        default=None,
        help=f"Static target directory (default: {DEFAULT_STATIC_DIR}).",
    )
    parser.add_argument(
        "--no-build",
        action="store_true",
        help=(
            "Skip the npm build step and only copy an existing dist/ into the "
            "static directory (useful when assets are already built)."
        ),
    )
    return parser.parse_args(argv)


def main(argv=None) -> int:
    args = parse_args(argv)
    static_dir = build_frontend(
        frontend_dir=args.frontend_dir,
        static_dir=args.static_dir,
        run_build=not args.no_build,
    )
    print(f"Frontend assets built and copied to: {static_dir}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
