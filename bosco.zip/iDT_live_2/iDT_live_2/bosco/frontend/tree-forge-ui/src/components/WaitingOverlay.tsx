import { useEffect, useState } from "react";
import { subscribe, isLoading as isLoadingNow } from "@/lib/loadingStore";
import waitingImg from "@/assets/waiting.png";

/**
 * Full-screen blocking overlay shown whenever any API request is in flight.
 *
 * While visible it covers the entire viewport at a high z-index and captures all
 * pointer events, so no buttons underneath can be clicked until the request
 * settles. The ``waiting.png`` graphic is shown with a gentle pulse.
 */
export const WaitingOverlay = () => {
  const [loading, setLoading] = useState<boolean>(isLoadingNow());

  useEffect(() => {
    // Sync in case state changed between render and effect, then subscribe.
    setLoading(isLoadingNow());
    const unsubscribe = subscribe(setLoading);
    return unsubscribe;
  }, []);

  if (!loading) return null;

  return (
    <div
      className="fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-background/70 backdrop-blur-sm"
      // Block all interaction with the page behind the overlay.
      style={{ pointerEvents: "all", cursor: "wait" }}
      aria-busy="true"
      aria-live="polite"
      role="alertdialog"
    >
      <div className="flex flex-col items-center gap-4 rounded-xl bg-card/90 px-8 py-6 shadow-lg">
        <img
          src={waitingImg}
          alt="Please wait"
          className="h-20 w-20 animate-pulse select-none"
          draggable={false}
        />
        <p className="text-sm font-medium text-foreground">Please wait…</p>
      </div>
    </div>
  );
};

export default WaitingOverlay;
