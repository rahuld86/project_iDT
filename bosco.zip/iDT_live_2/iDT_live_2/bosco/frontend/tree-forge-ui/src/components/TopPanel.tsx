import { ReactNode } from "react";
import topPanel from "@/assets/top_panel.png";

interface TopPanelProps {
  /**
   * Optional controls rendered on the right side of the panel (e.g. the
   * Tree Visualization toolbar buttons). When omitted, only the branding
   * image is shown.
   */
  children?: ReactNode;
}

/**
 * Shared top panel (branding bar) for the bosco build.
 *
 * Shows the `top_panel.png` branding image on the top-left, replacing the old
 * RedBox logo + "Decision Tree Builder" text. There is no Sign Out button
 * (the local bosco build has no authentication). Optional `children` are
 * rendered on the right of the same bar so pages like Tree Visualization can
 * keep their inline toolbar controls.
 */
export const TopPanel = ({ children }: TopPanelProps) => {
  return (
    <header className="bg-white/80 backdrop-blur-sm border-b border-border shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          <img
            src={topPanel}
            alt="Bosco"
            className="h-10 w-auto object-contain"
          />
          {children ? (
            <div className="flex items-center space-x-2">{children}</div>
          ) : null}
        </div>
      </div>
    </header>
  );
};

export default TopPanel;
