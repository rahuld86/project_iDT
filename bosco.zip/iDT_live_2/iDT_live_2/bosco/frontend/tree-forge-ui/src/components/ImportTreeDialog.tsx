import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Upload, FileText } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ImportTreeDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onImport: (file: File | string) => void;
}

const ImportTreeDialog: React.FC<ImportTreeDialogProps> = ({
  isOpen,
  onClose,
  onImport,
}) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Validate file type - accept both JSON and CSV files
      const fileName = file.name.toLowerCase();
      if (!fileName.endsWith('.json') && !fileName.endsWith('.csv')) {
        toast({
          title: "Invalid File Type",
          description: "Please select a JSON or CSV file.",
          variant: "destructive",
        });
        return;
      }
      setSelectedFile(file);
    }
  };

  const handleImport = async () => {
    try {
      setIsLoading(true);

      if (!selectedFile) {
        toast({
          title: "No File Selected",
          description: "Please select a JSON or CSV file to import.",
          variant: "destructive",
        });
        return;
      }
      // Pass the actual File object
      onImport(selectedFile);

    } catch (error) {
      console.error('Error during import:', error);
      toast({
        title: "Import Error",
        description: "Failed to import tree. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleClose = () => {
    setSelectedFile(null);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Import Decision Tree
          </DialogTitle>
          <DialogDescription>
            Upload a JSON file containing your decision tree data or a CSV file with raw data to continue working on it.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Local file upload */}
          <div className="space-y-4">
            <Label htmlFor="file-upload" className="text-sm font-medium">
              Select File
            </Label>
            <div className="border-2 border-dashed border-border rounded-lg p-6 text-center">
              <Upload className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <input
                id="file-upload"
                type="file"
                accept=".json,.csv"
                onChange={handleFileChange}
                className="hidden"
              />
              <Label
                htmlFor="file-upload"
                className="cursor-pointer text-primary hover:text-primary/80"
              >
                Click to browse files
              </Label>
              <p className="text-sm text-muted-foreground mt-2">
                JSON and CSV files are supported
              </p>
              {selectedFile && (
                <div className="mt-4 p-2 border border-border rounded bg-accent/10">
                  <p className="text-sm font-medium">{selectedFile.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {(selectedFile.size / 1024).toFixed(1)} KB
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={handleClose} disabled={isLoading}>
            Cancel
          </Button>
          <Button onClick={handleImport} disabled={isLoading}>
            {isLoading ? "Importing..." : "Import Tree"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ImportTreeDialog;
