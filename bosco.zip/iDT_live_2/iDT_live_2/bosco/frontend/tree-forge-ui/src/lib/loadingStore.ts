// Tiny global loading tracker.
//
// Every in-flight API request increments a counter; when it settles the counter
// is decremented. The UI subscribes to the derived boolean (count > 0) and shows
// a blocking "waiting" overlay while any request is pending. This is a plain
// module-level store (no external state lib) so both the api service and React
// components can share it.

type Listener = (isLoading: boolean) => void;

let activeCount = 0;
const listeners = new Set<Listener>();

function notify() {
  const isLoading = activeCount > 0;
  listeners.forEach((l) => l(isLoading));
}

/** Mark the start of an async operation. */
export function startLoading(): void {
  activeCount += 1;
  if (activeCount === 1) {
    notify();
  }
}

/** Mark the end of an async operation. */
export function stopLoading(): void {
  activeCount = Math.max(0, activeCount - 1);
  if (activeCount === 0) {
    notify();
  }
}

/** Current loading state. */
export function isLoading(): boolean {
  return activeCount > 0;
}

/** Subscribe to loading-state changes. Returns an unsubscribe function. */
export function subscribe(listener: Listener): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

/**
 * Wrap a promise so it participates in global loading tracking. The counter is
 * incremented immediately and decremented when the promise settles (success or
 * failure), guaranteeing the overlay never gets stuck on.
 */
export async function trackLoading<T>(promise: Promise<T>): Promise<T> {
  startLoading();
  try {
    return await promise;
  } finally {
    stopLoading();
  }
}
