# Bosco

Bosco packages the Tree Forge application as a single pip-installable Python
distribution, modeled on the `pip install jupyterlab` experience. After
installation, one console command starts a local server, serves the pre-built
web interface from the same process, and opens the app in your default browser.

Bosco is a purely client-side, single-user local utility. It runs entirely on
your own machine with no remote server, no authentication, no sessions, and no
persistence. All application state is held in memory and discarded when the
process exits, so each launch starts fresh.

## Requirements

- Python 3.10 through 3.14
- Windows or macOS (Linux works as a bonus because the server is cross-platform)

No Node.js, npm, or frontend build toolchain is required to run Bosco; the
pre-built frontend assets ship inside the wheel.

## Installation

```bash
pip install bosco
```

## Usage

Launch the application with the console command:

```bash
bosco
```

This starts the local server, prints the local URL (host and port) to the
terminal, and opens the application in your default web browser.

### Options

- `--host` — host to bind (default `127.0.0.1`)
- `--port` — preferred port (default `8765`); if the port is in use, an
  available port is selected automatically and reported
- `--no-browser` — start the server without opening a browser

Press `Ctrl+C` to stop the server; the bound port is released on exit.

### Examples

Run on a specific port:

```bash
bosco --port 9000
```

Run without opening a browser (useful on a headless machine or a remote
server you reach through an SSH tunnel):

```bash
bosco --no-browser
```

Bind a different local interface and port together:

```bash
bosco --host 127.0.0.1 --port 9000
```

### Platform notes

**Windows** — In PowerShell or Command Prompt, run `bosco` after installing.
If the `bosco` command is not recognized, your Python `Scripts` directory may
not be on `PATH`; either reopen the terminal, or invoke it through Python:

```powershell
python -m bosco
```

Stop the server with `Ctrl+C` in the same terminal window.

**macOS** — In Terminal (or iTerm), run `bosco` after installing. If you use
`pipx` to install the tool, the command is placed on `PATH` for you. The
default browser opens automatically unless you pass `--no-browser`. Stop the
server with `Ctrl+C`.

On both platforms the server binds to `127.0.0.1` by default, so it is only
reachable from your own machine.

## Troubleshooting

**Port already in use** — By default Bosco tries port `8765`. If that port is
already taken, Bosco automatically selects a free port instead and prints the
URL it actually bound. Read the printed URL in the terminal rather than
assuming `8765`.

**Picking a specific port** — Use `--port` to request a particular port, for
example `bosco --port 9000`. If the requested port is busy, Bosco still falls
back to an automatically chosen free port and reports it.

**Running headless or on a server** — Use `--no-browser` to start the server
without launching a browser. This is the right choice on machines with no
display or when you plan to open the printed URL yourself (for example over an
SSH port-forward).

**Python version** — Bosco supports Python 3.10 through 3.14. Its numpy and
pandas dependencies are specified as compatible minimum versions (not exact
pins), so pip installs a build with wheels for your interpreter. If
installation fails with a numpy/pandas build or compatibility error, check your
Python version with `python --version`; very new Python releases may briefly
lack published scientific-package wheels until the ecosystem catches up.

**Nothing is saved between runs** — Bosco is a local, single-user tool. There
is no login and no account. All application state (your uploaded data and the
tree you build) lives in memory only. Nothing is persisted to disk as
application state, and every launch starts from an empty state. Export or
download your tree before stopping the server if you want to keep it.

## Data and privacy

- Uploads and downloads use your local machine only (no cloud storage).
- Nothing is written to disk as application state; each run starts empty.
