"""Bosco: a pip-installable, single-user, in-memory local packaging of Tree Forge.

This package repackages the existing Tree Forge application as a single
pip-installable Python distribution. After ``pip install bosco`` the user runs
the ``bosco`` console command, which starts a local single-threaded HTTP server,
serves the pre-built frontend from the same process and port, and opens the
default browser.

All application state is held in memory for a single local user and is discarded
when the process exits; each launch starts fresh.
"""

__version__ = "0.1.0"

__all__ = ["__version__"]
