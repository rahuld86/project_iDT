"""Console entry point / Launcher for Bosco.

This module implements the ``bosco`` console command (referenced by the entry
point declared in ``pyproject.toml``). Responsibilities (design: "Launcher /
CLI"):

* ``parse_args`` -- argument parsing (``--host``, ``--port``, ``--no-browser``).
* ``find_available_port`` -- choose a bindable port: the preferred port when it
  is free, otherwise an OS-assigned free port (Requirement 1.5).
* ``main`` -- build the app, print the local URL (no token), optionally open the
  browser once the server is accepting connections, serve with a single-threaded
  Waitress, and shut down cleanly on ``KeyboardInterrupt`` (Requirements 1.2,
  1.3, 1.4, 1.6, 5.5, 7.1, 7.2).

``waitress`` is imported lazily inside :func:`main` so that importing this module
(and exercising ``parse_args`` / ``find_available_port``) does not require
``waitress`` to be installed, and so tests can monkeypatch ``waitress.serve``.
``webbrowser`` is imported at module top so tests can monkeypatch
``bosco.cli.webbrowser.open``.
"""

from __future__ import annotations

import argparse
import socket
import threading
import time
import webbrowser

from bosco.app import create_app


def parse_args(argv=None) -> argparse.Namespace:
    """Parse launcher command-line arguments.

    Args:
        argv: Optional argument list (defaults to ``sys.argv[1:]``).

    Returns:
        A namespace with ``host`` (default ``127.0.0.1``), ``port`` (int,
        default ``8765``), and ``no_browser`` (bool, default ``False``).
    """
    parser = argparse.ArgumentParser(
        prog="bosco",
        description="Run the Bosco local decision-tree app.",
    )
    parser.add_argument(
        "--host",
        default="127.0.0.1",
        help="Host interface to bind (default: 127.0.0.1).",
    )
    parser.add_argument(
        "--port",
        type=int,
        default=8765,
        help="Preferred port to bind (default: 8765). A free port is chosen "
        "automatically if this one is in use.",
    )
    parser.add_argument(
        "--no-browser",
        action="store_true",
        help="Do not open the default web browser on startup.",
    )
    return parser.parse_args(argv)


def find_available_port(host: str, preferred: int) -> int:
    """Return a bindable port for ``host``.

    Tries to bind the ``preferred`` port; if that succeeds the preferred port is
    returned. If binding the preferred port raises :class:`OSError` (for example
    because it is already in use), a fresh socket is bound to port ``0`` so the
    OS assigns a free port, which is then returned. ``SO_REUSEADDR`` is set so
    the returned port stays bindable by the server afterwards (Requirement 1.5).

    Args:
        host: Host/interface to probe.
        preferred: The port the caller would like to use.

    Returns:
        An integer port number that can be bound on ``host``.
    """
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        try:
            sock.bind((host, preferred))
            return preferred
        except OSError:
            # Preferred port is unavailable; let the OS assign a free one.
            sock.bind((host, 0))
            return sock.getsockname()[1]
    finally:
        sock.close()


def _open_browser_when_ready(host: str, port: int, url: str, timeout: float = 5.0) -> None:
    """Open ``url`` in the default browser once the server accepts connections.

    Polls ``(host, port)`` with short-lived TCP connect attempts until one
    succeeds (meaning the server is ready) or ``timeout`` seconds elapse, then
    calls :func:`webbrowser.open`. Intended to run in a background daemon thread
    so the page is ready when it opens (Requirements 1.2, 1.4).
    """
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            with socket.create_connection((host, port), timeout=0.5):
                break
        except OSError:
            time.sleep(0.1)
    webbrowser.open(url)


def main(argv=None) -> int:
    """Launch the Bosco local server.

    Selects a bindable port, builds the Flask app, prints the local URL (with no
    authentication token), optionally opens the browser from a background thread,
    and serves the app single-threaded via Waitress. ``KeyboardInterrupt``
    (Ctrl-C / SIGINT) stops serving and the bound port is released as the process
    returns (Requirement 1.6).

    Args:
        argv: Optional argument list (defaults to ``sys.argv[1:]``).

    Returns:
        Process exit code (``0``).
    """
    args = parse_args(argv)
    port = find_available_port(args.host, args.port)
    app = create_app()
    url = f"http://{args.host}:{port}"

    # Print the local URL WITHOUT any token (Requirements 1.3, 5.5).
    print(f"Bosco is running at {url}")

    if not args.no_browser:
        thread = threading.Thread(
            target=_open_browser_when_ready,
            args=(args.host, port, url),
            daemon=True,
        )
        thread.start()

    # Import Waitress lazily so importing this module does not require it and so
    # tests can monkeypatch ``waitress.serve`` (Requirements 1.2, 7.1, 7.2).
    from waitress import serve

    try:
        serve(app, host=args.host, port=port, threads=1)
    except KeyboardInterrupt:
        # Waitress stops serving; the bound socket is released as we return
        # (Requirement 1.6).
        return 0
    return 0


if __name__ == "__main__":  # pragma: no cover
    import sys

    sys.exit(main())
