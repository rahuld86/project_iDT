"""Static / SPA serving helpers for Bosco.

Provides:

- ``resolve_static_dir()``: locate the bundled frontend assets directory so it
  works both from an installed wheel (site-packages) and an editable/src
  layout.
- ``register_frontend_routes(app, static_dir)``: register Flask routes that
  serve the bundled single-page application (SPA) and its static assets, while
  leaving ``/api/*`` requests to the application's own API handlers.

Routing decision summary (for non-``/api`` requests that are not matched by a
more specific route):

1. ``GET /`` returns ``index.html`` (SPA entry document).
2. A path that matches an existing file under ``static_dir`` is served with the
   content type inferred from its extension.
3. A path that looks like a static asset (it has a file extension) but does not
   exist returns HTTP 404 -- it is never replaced by the SPA shell.
4. Any other path (no file extension -> a client-side route) returns
   ``index.html`` with HTTP 200 (SPA fallback).

Paths under ``api/`` are never served the SPA shell; if such a path reaches the
catch-all (i.e. no real API route matched it) it returns HTTP 404 so the 404 is
API-shaped rather than the HTML shell.
"""

from __future__ import annotations

import os
from importlib import resources
from pathlib import Path

from flask import Flask, abort, send_from_directory


def resolve_static_dir() -> Path:
    """Return the directory containing the bundled frontend assets.

    Primary mechanism uses ``importlib.resources`` so that the directory can be
    located from an installed wheel in site-packages. Falls back to a path
    relative to this module (editable / src layout) if resources resolution is
    unavailable.
    """
    try:
        resource = resources.files("bosco") / "static"
        # ``resources.files`` may return a non-filesystem traversable in exotic
        # loaders; guard by converting to a concrete path only when possible.
        candidate = Path(str(resource))
        if candidate.is_dir():
            return candidate
    except (ModuleNotFoundError, AttributeError, TypeError, OSError):
        pass

    return Path(__file__).parent / "static"


def register_frontend_routes(app: Flask, static_dir: Path) -> None:
    """Register SPA / static-asset serving routes on ``app``.

    ``static_dir`` is used directly (as a ``Path``), which makes the routes
    unit-testable by pointing them at a temporary directory.
    """
    static_dir = Path(static_dir)

    def _serve_index():
        # ``index.html`` may legitimately be absent during development (assets
        # are built later); ``send_from_directory`` will raise a 404 in that
        # case, which is acceptable.
        return send_from_directory(str(static_dir), "index.html")

    @app.route("/")
    def _root():  # pragma: no cover - thin wrapper exercised via test client
        return _serve_index()

    @app.route("/<path:path>")
    def _catch_all(path: str):
        # API paths must never be served the SPA shell. Real ``/api/*`` routes
        # are registered separately and take precedence; anything reaching here
        # with an ``api/`` prefix is an unmatched API path and gets a 404.
        if path == "api" or path.startswith("api/"):
            abort(404)

        candidate = static_dir / path
        if candidate.is_file():
            return send_from_directory(str(static_dir), path)

        # Distinguish an asset-looking path (has a file extension) from a
        # client-side route (no extension). Missing asset-looking paths 404;
        # extensionless paths fall back to the SPA shell.
        _, ext = os.path.splitext(path)
        if ext:
            abort(404)

        return _serve_index()
