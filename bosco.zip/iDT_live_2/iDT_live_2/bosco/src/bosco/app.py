"""Adapted Flask application factory for Bosco.

This module is adapted from ``backend/app.py`` (the Existing_App) into a
``create_app()`` factory for the single-user, in-memory, locally installed
package (Bosco_Dir). The original ``backend/app.py`` is left unmodified
(Requirement 10); this is an adapted copy.

Adaptations from the original (Requirements 5, 6, 9):

* No authentication: ``flask_jwt_extended`` / ``JWTManager`` / ``@jwt_required``
  are removed, as are ``load_dotenv`` and the ``AUTH_USERS`` / ``JWT_SECRET_KEY``
  configuration. The five auth/S3 endpoints (``/api/login``, ``/api/logout``,
  ``/api/user``, ``/api/verify``, ``/api/uploadFileToS3``) are dropped.
* No S3 / boto3 and no URL fetching: all S3 helpers and ``requests.get`` download
  branches are removed; file handling is local-disk only.
* In-memory state: ``from session import ...`` is replaced by
  ``from bosco.state import session_manager, session_id_from_jwt``. There is no
  Redis, no disk DataFrame store, no cache, and no cleanup scheduler.
* Static / SPA serving is registered from ``bosco.serving`` last so ``/api/*``
  routes take precedence.
"""

from __future__ import annotations

import json
import os
import traceback
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
from flask import Flask, Response, jsonify, request
from flask_cors import CORS
from werkzeug.exceptions import HTTPException

from bosco.serving import register_frontend_routes, resolve_static_dir
from bosco.state import session_id_from_jwt, session_manager
from bosco.util import (
    add_label,
    add_nodes,
    best_split,
    best_split_regression,
    build_tree,
    build_tree_node,
    classify_dtype,
    copy_node_wrapper,
    create_node_datasets,
    del_subtree,
    eval_split,
    find_var,
    find_var_regression,
    init_setup,
    split_node,
)

# No default upload size limit. bosco is a local single-user tool, so uploads
# are bounded only by the user's available memory. A cap can be opted into via
# the ``MAX_UPLOAD_SIZE`` environment variable or the ``create_app`` argument.


def df_to_json_safe(df):
    """Convert DataFrame to JSON-safe format by replacing NaN with None"""
    if df is None or df.empty:
        return []

    # Replace NaN values with None for JSON serialization
    df_clean = df.copy()

    # Handle different data types
    for col in df_clean.columns:
        if df_clean[col].dtype in ['float64', 'float32']:
            # Replace NaN with None for float columns
            df_clean[col] = df_clean[col].where(pd.notnull(df_clean[col]), None)
        elif df_clean[col].dtype == 'object':
            # For object columns, replace NaN with None
            df_clean[col] = df_clean[col].where(pd.notnull(df_clean[col]), None)

    # Convert to dict and ensure all values are JSON serializable
    result = df_clean.to_dict(orient='records')

    # Additional cleanup for any remaining NaN values
    for record in result:
        for key, value in record.items():
            # Skip NA check for container types; lists (e.g., list_values) are valid JSON
            if isinstance(value, (list, tuple, dict)):
                continue
            try:
                is_na = pd.isna(value) if hasattr(pd, 'isna') else (value != value)
                # If is_na is array-like, treat as not-NA to avoid ambiguous truth
                if isinstance(is_na, (np.ndarray, pd.Series)):
                    is_na = False
                if is_na:
                    record[key] = None
            except Exception:
                # On any check failure, leave the value as-is
                pass

    return result


def validate_required_fields(data, required_fields):
    """Validate that required fields are present in request data"""
    missing_fields = [field for field in required_fields if field not in data]
    if missing_fields:
        return False, f"Missing required fields: {', '.join(missing_fields)}"
    return True, None


def validate_file_exists(file_path):
    """Validate that file exists and is accessible"""
    if not file_path:
        return False, "File path is required"
    if not os.path.exists(file_path):
        return False, f"File '{file_path}' not found"
    return True, None


def handle_error(error_msg, status_code=500):
    """Standardized error handling"""
    print(f"Error: {error_msg}")
    print(traceback.format_exc())
    return jsonify({"error": error_msg}), status_code


def handle_storage_error(e):
    """Classify an exception into the right HTTP response.

    Simplified from the original multi-user/storage classifier for the
    single-process in-memory tool (design: Error Handling):

    * A Werkzeug ``HTTPException`` (e.g. ``RequestEntityTooLarge`` -> 413) is
      re-raised so Flask's registered handlers produce the correct response (the
      broad ``except Exception`` in endpoints must not swallow it into a 500).
    * ``OSError`` / ``IOError`` -> HTTP 500 with storage context (covers local
      file read/write failures on upload/download).
    * Anything else -> HTTP 500 with the error message.

    The original Redis ``ConnectionError`` / ``TimeoutError`` -> 503 branch and
    the ``SessionDataExpired`` / ``KeyError`` -> 400 branch are dropped: there is
    no Redis and no disk-backed pointer, so those cases cannot arise.
    """
    # Let Flask's own error handlers deal with HTTP exceptions (e.g. 413).
    if isinstance(e, HTTPException):
        raise e

    # Filesystem IO failure -> 500 with storage context.
    if isinstance(e, (OSError, IOError)):
        return handle_error(f"Storage error: {e}", 500)

    # Fall back to the prior generic 500 behavior.
    return handle_error(str(e), 500)


def create_app(static_dir=None, max_upload_bytes=None) -> Flask:
    """Build and return the Bosco Flask application.

    Args:
        static_dir: Directory containing the bundled frontend assets. When
            ``None``, it is resolved via :func:`bosco.serving.resolve_static_dir`.
        max_upload_bytes: Optional maximum request body size in bytes. When
            ``None`` (the default), NO upload size limit is enforced -- bosco is
            a local single-user tool, so uploads are bounded only by the user's
            available memory. A limit can still be opted into explicitly (or via
            the ``MAX_UPLOAD_SIZE`` environment variable) if desired.

    ``static_folder=None`` is passed so Flask does not register its own
    ``/static`` route; the SPA/static catch-all from ``bosco.serving`` fully
    governs static routes. API routes are registered first so they take
    precedence over the catch-all, which is registered last.
    """
    app = Flask(__name__, static_folder=None)

    # Scope CORS to localhost origins for the Local_Server. Because the frontend
    # is served same-origin, CORS is mostly a safety net (Requirement 9.3).
    CORS(
        app,
        origins=["http://127.0.0.1:*", "http://localhost:*"],
        supports_credentials=True,
    )

    # No upload size limit by default: as a local tool, the only real constraint
    # is the user's memory. ``MAX_CONTENT_LENGTH = None`` disables Flask's body
    # cap. A limit may still be set explicitly via the ``max_upload_bytes`` arg
    # or the ``MAX_UPLOAD_SIZE`` environment variable (opt-in).
    if max_upload_bytes is None:
        env_limit = os.environ.get("MAX_UPLOAD_SIZE")
        max_upload_bytes = int(env_limit) if env_limit else None
    app.config["MAX_CONTENT_LENGTH"] = int(max_upload_bytes) if max_upload_bytes else None

    @app.errorhandler(413)
    def handle_payload_too_large(error):
        """Return a JSON body if an (opt-in) upload size limit is ever exceeded."""
        return jsonify({"error": "Payload Too Large"}), 413

    @app.route('/api/test', methods=['GET'])
    def test():
        """Test endpoint to verify backend is working"""
        return jsonify({"message": "Backend is working", "timestamp": str(datetime.now())})

    @app.route('/api/importTree', methods=['POST'])
    def importTree():
        """Import an existing decision tree from JSON file (local file only)."""
        try:
            sid = session_id_from_jwt()
            state = session_manager.resolve(sid)
            print("=== IMPORT TREE ENDPOINT CALLED ===")
            print(f"Request content type: {request.content_type}")
            print(f"Request files: {list(request.files.keys())}")
            print(f"Request form: {list(request.form.keys())}")
            print("Starting import process...")

            # Check if this is a file upload (multipart/form-data)
            if 'file' in request.files:
                print("Processing file upload...")
                file = request.files['file']
                if file.filename == '':
                    return handle_error("No file selected", 400)

                print(f"Uploaded file: {file.filename}")

                # Check if it's a CSV file
                if file.filename.lower().endswith('.csv'):
                    print("CSV file detected - routing to upload endpoint")
                    # Save uploaded file to local uploads directory
                    upload_dir = os.path.join(os.getcwd(), 'uploads')
                    os.makedirs(upload_dir, exist_ok=True)

                    import uuid
                    unique_filename = f"{uuid.uuid4()}_{file.filename}"
                    file_path = os.path.join(upload_dir, unique_filename)

                    # Save the file
                    file.save(file_path)

                    # Load CSV file, store the heavy frame in memory.
                    df = pd.read_csv(file_path)
                    session_manager.set_dataframe(sid, state, "df", df)
                    state.file_name = file_path
                    state.original_data_source = file_path
                    session_manager.persist(sid, state)

                    rows, columns = df.shape
                    sample = df.head().replace({pd.NA: None, pd.NaT: None, np.nan: None}).to_dict(orient='records')
                    column_names = df.columns.tolist()

                    return jsonify({
                        "rows": rows,
                        "columns": columns,
                        "columnsList": column_names,
                        "sample": sample,
                        "is_csv_import": True,
                    })
                else:
                    # Handle JSON file
                    file_content = file.read().decode('utf-8')
                    print(f"File content length: {len(file_content)}")
                    data = json.loads(file_content)
                    print("Successfully parsed JSON from uploaded file")
            else:
                print("Processing JSON data with file_name...")
                data = request.get_json()
                if not data:
                    return handle_error("No JSON data provided", 400)

                is_valid, error_msg = validate_required_fields(data, ["file_name"])
                if not is_valid:
                    return handle_error(error_msg, 400)

                file_name = data.get("file_name")
                print(f"Looking for file: {file_name}")

                # Check if it's a CSV file (local path only)
                if file_name.lower().endswith('.csv'):
                    print("CSV file detected - local file path handling")
                    print(f"Current working directory: {os.getcwd()}")

                    # Try multiple path resolution strategies (local only)
                    file_paths_to_try = [
                        file_name,
                        os.path.basename(file_name),
                        os.path.join(os.getcwd(), file_name),
                        os.path.join(os.getcwd(), os.path.basename(file_name)),
                    ]

                    df = None
                    file_loaded = False
                    for file_path in file_paths_to_try:
                        print(f"Trying file path: {file_path}")
                        if os.path.exists(file_path):
                            df = pd.read_csv(file_path)
                            session_manager.set_dataframe(sid, state, "df", df)
                            state.file_name = file_path
                            state.original_data_source = file_name
                            print(f"Successfully loaded CSV with shape: {df.shape}")
                            file_loaded = True
                            break

                    if not file_loaded:
                        print(f"Local file not found in any of the attempted paths: {file_paths_to_try}")
                        return handle_error(f"File not found in any attempted paths: {file_paths_to_try}", 404)

                    session_manager.persist(sid, state)
                    rows, columns = df.shape
                    sample = df.head().replace({pd.NA: None, pd.NaT: None, np.nan: None}).to_dict(orient='records')
                    column_names = df.columns.tolist()

                    return jsonify({
                        "rows": rows,
                        "columns": columns,
                        "columnsList": column_names,
                        "sample": sample,
                        "is_csv_import": True,
                    })
                else:
                    # Handle JSON file (local path only)
                    is_valid, error_msg = validate_file_exists(file_name)
                    if not is_valid:
                        return handle_error(error_msg, 404)

                    with open(file_name, "r") as f:
                        data = json.load(f)

            # Load tree configuration
            state.file_name = data.get("file_name")
            state.badflag = data.get("badflag")
            state.max_depth = data.get("max_depth", 5)
            state.min_node_split = data.get("min_node_split", 500)
            state.min_leaf_size = data.get("min_leaf_size", 100)
            state.max_branches = data.get("max_branches", 5)
            state.criteria = data.get("criteria", "entropy")
            state.unique_var = data.get("unique_var", 0)
            state.monotonic = data.get("monotonic", 0)
            df_col_df = pd.DataFrame(data.get("mapper"))
            state.df_col = df_to_json_safe(df_col_df)
            node_master_read = pd.DataFrame(data.get("node_master"))

            df = None

            print(f"Loading data from file: {state.file_name}")
            original_file_name = state.file_name
            print(f"Attempting to load original data from: {original_file_name}")

            # Check if the file_name in JSON points to a CSV file (local only)
            if original_file_name and original_file_name.lower().endswith('.csv'):
                print("JSON contains CSV file path - processing as CSV import")
                try:
                    print(f"Processing local file path: {original_file_name}")
                    print(f"File exists check: {os.path.exists(original_file_name)}")

                    file_paths_to_try = [
                        original_file_name,
                        os.path.basename(original_file_name),
                        os.path.join(os.getcwd(), original_file_name),
                        os.path.join(os.getcwd(), os.path.basename(original_file_name)),
                    ]

                    file_loaded = False
                    for file_path in file_paths_to_try:
                        print(f"Trying file path: {file_path}")
                        if os.path.exists(file_path):
                            df = pd.read_csv(file_path)
                            print(f"Successfully loaded data from local file: {file_path}")
                            file_loaded = True
                            break

                    if not file_loaded:
                        print(f"Local file not found in any of the attempted paths: {file_paths_to_try}. Creating mock dataset...")
                        raise FileNotFoundError(f"File not found in any attempted paths: {file_paths_to_try}")

                except Exception as e:
                    print(f"Failed to load CSV data from JSON file_name: {e}")
                    print("Creating mock dataset based on column mapping to avoid file dependency issues...")

                    # Create a mock dataset based on the column mapping
                    df_col_small = df_col_df[df_col_df['datatype'].isin(['numerical', 'categorical'])]
                    mock_data = {}

                    for _, row in df_col_small.iterrows():
                        col_name = row['column_name']
                        if row['datatype'] == 'numerical':
                            mock_data[col_name] = [0.0] * 100
                        else:  # categorical
                            mock_data[col_name] = ['category1'] * 100

                    if state.badflag not in mock_data:
                        mock_data[state.badflag] = [0] * 100

                    df = pd.DataFrame(mock_data)
                    print(f"Created mock dataset with shape: {df.shape}")
                    print(f"Mock data columns: {list(df.columns)}")
            else:
                print("Non-CSV file detected - skipping data loading")
                pass

            # Verify all required columns exist
            df_col_small = df_col_df[df_col_df['datatype'].isin(['numerical', 'categorical'])]
            print(f"Columns to use for tree: {list(df_col_small.column_name)}")

            missing_cols = [col for col in df_col_small.column_name if col not in df.columns]
            if missing_cols:
                print(f"Adding missing columns: {missing_cols}")
                for col in missing_cols:
                    df[col] = [0.0] * 100

            if state.badflag not in df.columns:
                print(f"Adding missing badflag column: {state.badflag}")
                df[state.badflag] = [0] * 100

            df_for_tree = df[df_col_small.column_name]
            df_for_tree['badflag'] = df[state.badflag]

            print(f"Final df_for_tree columns: {list(df_for_tree.columns)}")
            print(f"Final df_for_tree shape: {df_for_tree.shape}")

            if 'variable' in node_master_read.columns:
                node_variables = node_master_read['variable'].dropna().unique()
                missing_vars = [var for var in node_variables if var not in df_for_tree.columns and var not in ['Parent', '']]
                if missing_vars:
                    return handle_error(f"Variables in tree not found in data: {missing_vars}. Available columns: {list(df_for_tree.columns)}", 400)

            print("Storing heavy frames in memory for imported tree...")
            session_manager.set_dataframe(sid, state, "df", df)
            session_manager.set_dataframe(sid, state, "df_for_tree", df_for_tree)

            # node_datasets is rederived on demand (not stored).
            print("node_datasets will be rederived on demand (not persisted)")

            df_col_small = df_col_df[df_col_df['datatype'].isin(['numerical', 'categorical'])]
            feature_columns = df_col_small['column_name'].tolist()
            print(f"Feature columns from mapper: {feature_columns}")

            available_features = [col for col in feature_columns if col in df_for_tree.columns]
            print(f"Available feature columns: {available_features}")

            if available_features:
                state.X_col = list(available_features)
                print(f"X_col set from mapper features: {list(state.X_col)}")
            else:
                if state.badflag in df_for_tree.columns:
                    state.X_col = list(df_for_tree.drop([state.badflag], axis=1).columns)
                    print(f"X_col set by dropping badflag: {list(state.X_col)}")
                else:
                    print(f"Warning: badflag '{state.badflag}' not in df_for_tree columns, using all columns")
                    state.X_col = list(df_for_tree.columns)

            print(f"Final X_col: {list(state.X_col)}")

            state.node_master = df_to_json_safe(node_master_read)
            session_manager.persist(sid, state)

            return jsonify({"node_master": df_to_json_safe(node_master_read)})

        except Exception as e:
            return handle_storage_error(e)

    @app.route('/api/getImportDiagnostics', methods=['GET'])
    def getImportDiagnostics():
        """Get diagnostic information about the imported tree data"""
        try:
            sid = session_id_from_jwt()
            state = session_manager.resolve(sid)

            if state.df is None:
                return handle_error("No data available. Please import a tree first.", 400)

            df = session_manager.active_df(state)
            if df is None:
                return handle_error("No data available. Please import a tree first.", 400)

            sample_records = df.head(5).replace({pd.NA: None, pd.NaT: None, np.nan: None}).to_dict(orient='records')

            columns_info = []
            for col in df.columns:
                dtype = str(df[col].dtype)
                unique_count = df[col].nunique()
                columns_info.append({
                    'column_name': col,
                    'datatype': dtype,
                    'unique_values': unique_count,
                    'sample_values': df[col].head(3).replace({pd.NA: None, pd.NaT: None, np.nan: None}).tolist(),
                })

            mapper_info = []
            if state.df_col is not None:
                for row in pd.DataFrame(state.df_col).to_dict('records'):
                    mapper_info.append({
                        'column_name': row['column_name'],
                        'datatype': row['datatype'],
                    })

            df_for_tree = (
                session_manager.active_df_for_tree(state)
                if state.df_for_tree is not None else None
            )
            diagnostics = {
                'dataset_info': {
                    'rows': df.shape[0],
                    'columns': df.shape[1],
                    'sample_records': sample_records,
                },
                'target_variable': state.badflag,
                'columns_info': columns_info,
                'mapper_info': mapper_info,
                'hyperparameters': {
                    'max_depth': state.max_depth,
                    'min_node_split': state.min_node_split,
                    'min_leaf_size': state.min_leaf_size,
                    'max_branches': state.max_branches,
                    'criteria': state.criteria,
                    'unique_var': state.unique_var,
                    'monotonic': state.monotonic,
                    'regression_flag': state.regression_flag,
                },
                'feature_columns': list(state.X_col) if state.X_col else [],
                'df_for_tree_shape': df_for_tree.shape if df_for_tree is not None else None,
            }

            return jsonify(diagnostics)

        except Exception as e:
            print(f"Error in getImportDiagnostics: {str(e)}")
            print(f"Traceback: {traceback.format_exc()}")
            return handle_storage_error(e)

    @app.route('/api/upload', methods=['POST'])
    def upload_csv():
        """Upload and validate CSV file (local file only)."""
        try:
            sid = session_id_from_jwt()
            state = session_manager.resolve(sid)

            df = None
            source = None
            file_path = None

            # Check if this is a file upload (multipart/form-data) or JSON request
            if request.files:
                uploaded_file = request.files.get('file')
                if not uploaded_file:
                    return handle_error("No file provided in upload", 400)

                if not uploaded_file.filename.endswith('.csv'):
                    return handle_error("Only CSV files are allowed", 400)

                # Save uploaded file to local uploads directory
                upload_dir = os.path.join(os.getcwd(), 'uploads')
                os.makedirs(upload_dir, exist_ok=True)

                import uuid
                unique_filename = f"{uuid.uuid4()}_{uploaded_file.filename}"
                file_path = os.path.join(upload_dir, unique_filename)

                uploaded_file.save(file_path)

                df = pd.read_csv(file_path)
                source = file_path
            else:
                # Handle JSON request (local file path only)
                data = request.get_json()
                if not data:
                    return handle_error("No JSON data provided", 400)

                is_valid, error_msg = validate_required_fields(data, ["file"])
                if not is_valid:
                    return handle_error(error_msg, 400)

                file_name = data.get("file")

                # Local file path only (no S3, no URL)
                file_paths_to_try = [
                    file_name,
                    os.path.basename(file_name),
                    os.path.join(os.getcwd(), file_name),
                    os.path.join(os.getcwd(), os.path.basename(file_name)),
                ]

                file_loaded = False
                for candidate in file_paths_to_try:
                    if os.path.exists(candidate):
                        df = pd.read_csv(candidate)
                        source = file_name
                        file_path = candidate
                        file_loaded = True
                        break

                if not file_loaded:
                    return handle_error(f"File not found in any attempted paths: {file_paths_to_try}", 404)

            # Store the heavy frame in memory; keep small metadata on state.
            session_manager.set_dataframe(sid, state, "df", df)
            state.file_name = file_path
            state.original_data_source = source
            session_manager.persist(sid, state)

            rows, columns = df.shape
            sample = df.head().replace({pd.NA: None, pd.NaT: None, np.nan: None}).to_dict(orient='records')
            column_names = df.columns.tolist()

            return jsonify({
                'rows': rows,
                'columns': columns,
                'sample': sample,
                'columnsList': column_names,
            })

        except Exception as e:
            return handle_storage_error(e)

    @app.route('/api/setTarget', methods=['POST'])
    def setTarget():
        """Set target variable for the decision tree"""
        try:
            data = request.get_json()
            if not data:
                return handle_error("No JSON data provided", 400)

            is_valid, error_msg = validate_required_fields(data, ["target"])
            if not is_valid:
                return handle_error(error_msg, 400)

            target = data.get("target")
            regression_flag = data.get("regression_flag")

            sid = session_id_from_jwt()
            state = session_manager.resolve(sid)

            df = session_manager.active_df(state)
            if df is None:
                return handle_error("No data loaded. Please upload a file first.", 400)

            if target not in df.columns:
                return handle_error(f"Target variable '{target}' not found in data", 400)

            state.badflag = target
            state.regression_flag = regression_flag
            session_manager.persist(sid, state)

            return jsonify({"message": f"Target variable set to {target}"})

        except Exception as e:
            return handle_storage_error(e)

    @app.route('/api/getRegressionFlag', methods=['GET'])
    def getRegressionFlag():
        """Return current regression/classification mode flag"""
        try:
            sid = session_id_from_jwt()
            state = session_manager.resolve(sid)
            return jsonify({"regression_flag": state.regression_flag})
        except Exception as e:
            return handle_storage_error(e)

    @app.route('/api/getTypes', methods=['GET'])
    def getTypes():
        """Get data types for all columns except target variable"""
        try:
            sid = session_id_from_jwt()
            state = session_manager.resolve(sid)

            df = session_manager.active_df(state)
            if df is None:
                return handle_error("No data loaded. Please upload a file first.", 400)

            if state.badflag is None:
                return handle_error("No target variable set. Please set target variable first.", 400)

            col_types = {
                col: classify_dtype(df.drop(state.badflag, axis=1)[col].dtype)
                for col in df.drop(state.badflag, axis=1).columns
            }

            return jsonify(col_types)

        except Exception as e:
            return handle_storage_error(e)

    @app.route('/api/keepVar', methods=['POST'])
    def keepVar():
        """Select variables to keep for tree building"""
        try:
            data = request.get_json()
            if not data:
                return handle_error("No JSON data provided", 400)

            sid = session_id_from_jwt()
            state = session_manager.resolve(sid)

            df = session_manager.active_df(state)
            if df is None:
                return handle_error("No data loaded. Please upload a file first.", 400)

            if state.badflag is None:
                return handle_error("No target variable set. Please set target variable first.", 400)

            df_col = pd.DataFrame(list(data.items()), columns=['column_name', 'datatype'])
            print(f"df_col created: {df_col}")
            state.df_col = df_col.to_dict('records')

            df_col_small = df_col[df_col['datatype'].isin(['numerical', 'categorical'])]
            print(f"df_col_small after filtering: {df_col_small}")

            feature_columns = df_col_small['column_name'].tolist()
            print(f"Feature columns to use: {feature_columns}")

            df_for_tree = df[feature_columns]
            print(f"df_for_tree columns after feature selection: {list(df_for_tree.columns)}")

            # Convert target variable to numeric (0/1) for tree building
            target_values = df[state.badflag]
            if target_values.dtype == 'object':
                unique_values = target_values.unique()
                if len(unique_values) == 2:
                    value_map = {unique_values[0]: 1, unique_values[1]: 0}
                    df_for_tree['badflag'] = target_values.map(value_map)
                else:
                    return handle_error(f"Target variable must have exactly 2 unique values, found {len(unique_values)}", 400)
            else:
                df_for_tree['badflag'] = target_values

            # Store the processed heavy frame in memory.
            session_manager.set_dataframe(sid, state, "df_for_tree", df_for_tree)
            session_manager.persist(sid, state)

            column_names = df_for_tree.columns.tolist()
            return jsonify({'columnsList': column_names})

        except Exception as e:
            return handle_storage_error(e)

    @app.route('/api/defineHP', methods=['POST'])
    def defineHP():
        """Define hyperparameters for decision tree"""
        try:
            sid = session_id_from_jwt()
            state = session_manager.resolve(sid)

            # Set default values
            state.max_depth = 5
            state.min_node_split = 500
            state.min_leaf_size = 100
            state.max_branches = 5
            state.criteria = "entropy"
            state.unique_var = 0
            state.monotonic = 0

            # Override with provided values
            data = request.get_json(silent=True) or {}
            state.max_depth = data.get("max_depth", state.max_depth)
            state.min_node_split = data.get("min_node_split", state.min_node_split)
            state.min_leaf_size = data.get("min_leaf_size", state.min_leaf_size)
            state.max_branches = data.get("max_branches", state.max_branches)
            state.criteria = data.get("criteria", state.criteria)
            state.unique_var = data.get("unique_var", state.unique_var)
            state.monotonic = data.get("monotonic", state.monotonic)

            session_manager.persist(sid, state)

            return jsonify({
                'max_depth': state.max_depth,
                'min_node_split': state.min_node_split,
                'min_leaf_size': state.min_leaf_size,
                'max_branches': state.max_branches,
                'criteria': state.criteria,
                'unique_var': state.unique_var,
                'monotonic': state.monotonic,
            })

        except Exception as e:
            return handle_storage_error(e)

    @app.route('/api/initTree', methods=['POST'])
    def initTree():
        """Initialize decision tree with root node"""
        try:
            sid = session_id_from_jwt()
            state = session_manager.resolve(sid)

            df_for_tree = session_manager.active_df_for_tree(state)
            if df_for_tree is None:
                return handle_error("No processed data available. Please complete data setup first.", 400)

            X_col, node_master, node_datasets = init_setup(
                df_for_tree, 'badflag', state.max_depth,
                state.min_node_split, state.min_leaf_size, state.max_branches,
            )

            # node_datasets is rederivable and intentionally not persisted.
            state.X_col = list(X_col)
            state.node_master = df_to_json_safe(node_master)
            session_manager.persist(sid, state)

            return jsonify({"node_master": df_to_json_safe(node_master)})

        except Exception as e:
            return handle_storage_error(e)

    @app.route('/api/autoTree', methods=['POST'])
    def autoTree():
        """Train entire tree automatically"""
        try:
            sid = session_id_from_jwt()
            state = session_manager.resolve(sid)

            df_for_tree = session_manager.active_df_for_tree(state)
            if df_for_tree is None:
                return handle_error("No processed data available. Please complete data setup first.", 400)

            node_master, node_datasets = build_tree(
                df_for_tree, 'badflag', state.max_depth,
                state.min_node_split, state.min_leaf_size,
                state.max_branches, pd.DataFrame(state.df_col), state.regression_flag,
                state.monotonic, state.unique_var,
            )

            state.node_master = df_to_json_safe(node_master)
            session_manager.persist(sid, state)

            return jsonify({"node_master": df_to_json_safe(node_master)})

        except Exception as e:
            return handle_storage_error(e)

    @app.route('/api/delSubTree', methods=['POST'])
    def delSubTree():
        """Delete subtree starting from specified node"""
        try:
            data = request.get_json()
            if not data:
                return handle_error("No JSON data provided", 400)

            is_valid, error_msg = validate_required_fields(data, ["node_number"])
            if not is_valid:
                return handle_error(error_msg, 400)

            node_number = data.get("node_number")

            sid = session_id_from_jwt()
            state = session_manager.resolve(sid)

            if state.node_master is None or state.df_for_tree is None:
                return handle_error("No tree initialized. Please initialize tree first.", 400)

            node_master_df = pd.DataFrame(state.node_master)
            node_datasets = session_manager.node_datasets_for(state)

            node_master_df, node_datasets = del_subtree(
                node_master_df, node_datasets, node_number,
            )

            if node_number in node_master_df['node_number'].values:
                print(f"Marking node {node_number} as non-leaf after deleting subtree")
                node_master_df.loc[node_master_df['node_number'] == node_number, 'leaf_flag'] = 0
                print(f"Node {node_number} leaf_flag set to 0")

            if node_number == 1:  # If deleting from root node
                print("Deleting subtree from root node - reassigning all data to root node")
                node_datasets = session_manager.active_df_for_tree(state).copy()
                node_datasets['node_number'] = 1
                print(f"Reassigned all data to root node. node_datasets shape: {node_datasets.shape}")

            state.node_master = df_to_json_safe(node_master_df)
            session_manager.persist(sid, state)

            return jsonify({"node_master": df_to_json_safe(node_master_df)})

        except Exception as e:
            return handle_storage_error(e)

    @app.route('/api/autoTrainSubTree', methods=['POST'])
    def autoTrainSubTree():
        """Automatically train subtree from specified node"""
        try:
            print("=== AUTO TRAIN SUBTREE ENDPOINT CALLED ===")
            data = request.get_json()
            if not data:
                return handle_error("No JSON data provided", 400)

            is_valid, error_msg = validate_required_fields(data, ["node_number"])
            if not is_valid:
                return handle_error(error_msg, 400)

            node_number = data.get("node_number")
            print(f"Processing auto train for node: {node_number}")

            sid = session_id_from_jwt()
            state = session_manager.resolve(sid)

            if state.node_master is None or state.df_for_tree is None:
                return handle_error("No tree initialized. Please initialize tree first.", 400)

            node_master_df = pd.DataFrame(state.node_master)

            if node_number not in node_master_df['node_number'].values:
                return handle_error(f"Node {node_number} not found in tree", 400)

            if state.df_for_tree is None:
                return handle_error("Data for tree not available", 400)
            if state.X_col is None:
                return handle_error("Feature columns not defined", 400)
            if state.df_col is None:
                return handle_error("Column mapping not defined", 400)

            df_for_tree = session_manager.active_df_for_tree(state)
            node_datasets = session_manager.node_datasets_for(state)
            df_col_df = pd.DataFrame(state.df_col)

            print(f"Auto training subtree for node {node_number}")
            print(f"Node master shape: {node_master_df.shape}")
            print(f"Node datasets shape: {node_datasets.shape}")
            print(f"df_for_tree shape: {df_for_tree.shape}")
            print(f"X_col: {list(state.X_col)}")
            print(f"df_col shape: {df_col_df.shape}")

            print("About to call build_tree_node...")
            node_master_df, node_datasets = build_tree_node(
                df_for_tree, 'badflag', state.max_depth,
                state.min_node_split, state.min_leaf_size,
                state.max_branches, node_number, state.X_col,
                node_master_df, node_datasets, df_col_df, state.regression_flag,
            )
            print("build_tree_node completed successfully")

            state.node_master = df_to_json_safe(node_master_df)
            session_manager.persist(sid, state)

            return jsonify({"node_master": df_to_json_safe(node_master_df)})

        except Exception as e:
            print(f"Error in autoTrainSubTree: {str(e)}")
            print(f"Exception type: {type(e)}")
            print(f"Traceback: {traceback.format_exc()}")
            return handle_error(f"Auto train failed: {str(e)}")

    @app.route('/api/findSplit', methods=['POST'])
    def findSplit():
        """Find best split for specified node"""
        try:
            data = request.get_json()
            if not data:
                return handle_error("No JSON data provided", 400)

            is_valid, error_msg = validate_required_fields(data, ["node_number"])
            if not is_valid:
                return handle_error(error_msg, 400)

            node_number = data.get("node_number")

            sid = session_id_from_jwt()
            state = session_manager.resolve(sid)

            if state.node_master is None or state.df_for_tree is None:
                return handle_error("No tree initialized. Please initialize tree first.", 400)

            node_master_df = pd.DataFrame(state.node_master)
            node_datasets = session_manager.node_datasets_for(state)
            df_col_df = pd.DataFrame(state.df_col)

            node_master_df, node_datasets = split_node(
                node_number, state.min_leaf_size, state.max_branches,
                state.max_depth, state.min_node_split, state.X_col,
                node_master_df, node_datasets, 'badflag', df_col_df, state.regression_flag,
                state.monotonic, [],
            )

            state.node_master = df_to_json_safe(node_master_df)
            session_manager.persist(sid, state)

            return jsonify({"node_master": df_to_json_safe(node_master_df)})

        except Exception as e:
            return handle_storage_error(e)

    @app.route('/api/findVar', methods=['POST'])
    def findVar():
        """Find top variables for splitting at specified node"""
        try:
            data = request.get_json()
            if not data:
                return handle_error("No JSON data provided", 400)

            is_valid, error_msg = validate_required_fields(data, ["node_number"])
            if not is_valid:
                return handle_error(error_msg, 400)

            node_number = data.get("node_number")

            sid = session_id_from_jwt()
            state = session_manager.resolve(sid)

            if state.node_master is None or state.df_for_tree is None:
                return handle_error("No tree initialized. Please initialize tree first.", 400)

            node_datasets = session_manager.node_datasets_for(state)
            df_col_df = pd.DataFrame(state.df_col)

            if state.regression_flag == 0:
                top_vars = find_var(
                    node_number, node_datasets, state.X_col,
                    'badflag', df_col_df,
                )
            else:
                top_vars = find_var_regression(
                    node_number, node_datasets, state.X_col,
                    'badflag', df_col_df,
                )

            return jsonify({"top_vars": df_to_json_safe(top_vars)})

        except Exception as e:
            return handle_storage_error(e)

    @app.route('/api/bestSplit', methods=['POST'])
    def bestSplit():
        """Find best split for specified variable at specified node"""
        try:
            data = request.get_json()
            if not data:
                return handle_error("No JSON data provided", 400)

            is_valid, error_msg = validate_required_fields(data, ["node_number", "variable_name"])
            if not is_valid:
                return handle_error(error_msg, 400)

            node_number = data.get("node_number")
            variable_name = data.get("variable_name")

            sid = session_id_from_jwt()
            state = session_manager.resolve(sid)

            if state.node_master is None or state.df_for_tree is None:
                return handle_error("No tree initialized. Please initialize tree first.", 400)

            node_datasets = session_manager.node_datasets_for(state)
            df_col_df = pd.DataFrame(state.df_col)

            if state.regression_flag == 0:
                df_out = best_split(
                    node_number, node_datasets, state.X_col,
                    'badflag', variable_name, state.min_leaf_size,
                    state.max_branches, df_col_df,
                )
            else:
                df_out = best_split_regression(
                    node_number, node_datasets, state.X_col,
                    'badflag', variable_name, state.min_leaf_size,
                    state.max_branches, df_col_df,
                )

            return jsonify({"best_split": df_to_json_safe(df_out)})

        except Exception as e:
            return handle_storage_error(e)

    @app.route('/api/evalSplit', methods=['POST'])
    def evalSplit():
        """Evaluate provided splits for specified node"""
        try:
            data = request.get_json()
            if not data:
                return handle_error("No JSON data provided", 400)

            is_valid, error_msg = validate_required_fields(data, ["node_number", "variable_name", "splits"])
            if not is_valid:
                return handle_error(error_msg, 400)

            node_number = data.get("node_number")
            variable_name = data.get("variable_name")
            splits_data = data.get("splits")

            sid = session_id_from_jwt()
            state = session_manager.resolve(sid)

            if state.node_master is None or state.df_for_tree is None:
                return handle_error("No tree initialized. Please initialize tree first.", 400)

            node_datasets = session_manager.node_datasets_for(state)
            df_col_df = pd.DataFrame(state.df_col)

            # Create DataFrame and add required columns
            df = pd.DataFrame(splits_data)

            df['variable'] = variable_name
            if 'missing' not in df.columns:
                df['missing'] = False
            else:
                df['missing'] = df['missing'].astype(int)

            if 'list_values' not in df.columns:
                df['list_values'] = [[] for _ in range(len(df))]
            else:
                def normalize_list_values(x):
                    if x is None:
                        return []
                    if isinstance(x, list):
                        out = []
                        for v in x:
                            try:
                                if isinstance(v, (np.ndarray, pd.Series)):
                                    out.extend(list(v))
                                else:
                                    out.append(v)
                            except Exception:
                                out.append(v)
                        return out
                    try:
                        if isinstance(x, (np.ndarray, pd.Series)):
                            return list(x)
                    except Exception:
                        pass
                    return [x]

                df['list_values'] = df['list_values'].apply(normalize_list_values)

            df_out = eval_split(node_number, node_datasets, 'badflag', df, df_col_df)

            return jsonify({"eval_split": df_to_json_safe(df_out)})

        except Exception as e:
            return handle_storage_error(e)

    @app.route('/api/addNode', methods=['POST'])
    def addNode():
        """Add new nodes based on provided splits"""
        try:
            data = request.get_json()
            if not data:
                return handle_error("No JSON data provided", 400)

            is_valid, error_msg = validate_required_fields(data, ["node_number", "variable_name", "splits"])
            if not is_valid:
                return handle_error(error_msg, 400)

            node_number = data.get("node_number")
            variable_name = data.get("variable_name")
            splits_data = data.get("splits")

            sid = session_id_from_jwt()
            state = session_manager.resolve(sid)

            if state.node_master is None or state.df_for_tree is None:
                return handle_error("No tree initialized. Please initialize tree first.", 400)

            node_master_df = pd.DataFrame(state.node_master)
            node_datasets = session_manager.node_datasets_for(state)
            df_col_df = pd.DataFrame(state.df_col)

            df = pd.DataFrame(splits_data)

            df['variable'] = variable_name
            if 'missing' not in df.columns:
                df['missing'] = 0
            else:
                df['missing'] = df['missing'].astype(int)
            if 'list_values' not in df.columns:
                df['list_values'] = [[] for _ in range(len(df))]
            else:
                def normalize_list_values(x):
                    if x is None:
                        return []
                    if isinstance(x, list):
                        out = []
                        for v in x:
                            try:
                                if isinstance(v, (np.ndarray, pd.Series)):
                                    out.extend(list(v))
                                else:
                                    out.append(v)
                            except Exception:
                                out.append(v)
                        return out
                    try:
                        if isinstance(x, (np.ndarray, pd.Series)):
                            return list(x)
                    except Exception:
                        pass
                    return [x]

                df['list_values'] = df['list_values'].apply(normalize_list_values)

            node_master_df, node_datasets = add_nodes(
                df, node_number, state.max_depth, state.min_node_split,
                0, node_master_df, node_datasets, 'badflag', df_col_df,
            )

            state.node_master = df_to_json_safe(node_master_df)
            session_manager.persist(sid, state)

            return jsonify({"success": True, "message": "Nodes added successfully", "node_master": df_to_json_safe(node_master_df)})

        except Exception as e:
            return handle_storage_error(e)

    @app.route('/api/copyNode', methods=['POST'])
    def copyNode():
        """Copy subtree from one node to another"""
        try:
            data = request.get_json()
            if not data:
                return handle_error("No JSON data provided", 400)

            is_valid, error_msg = validate_required_fields(data, ["from_node", "to_node"])
            if not is_valid:
                return handle_error(error_msg, 400)

            from_node = data.get("from_node")
            to_node = data.get("to_node")

            sid = session_id_from_jwt()
            state = session_manager.resolve(sid)

            if state.node_master is None or state.df_for_tree is None:
                return handle_error("No tree initialized. Please initialize tree first.", 400)

            node_master_df = pd.DataFrame(state.node_master)
            node_datasets = session_manager.node_datasets_for(state)
            df_col_df = pd.DataFrame(state.df_col)

            node_master_df, node_datasets = copy_node_wrapper(
                from_node, to_node, node_master_df, node_datasets,
                state.max_depth, state.min_node_split, 'badflag', df_col_df,
            )

            state.node_master = df_to_json_safe(node_master_df)
            session_manager.persist(sid, state)

            return jsonify({"node_master": df_to_json_safe(node_master_df)})

        except Exception as e:
            return handle_storage_error(e)

    @app.route('/api/labelNode', methods=['POST'])
    def labelNode():
        """Add label to specified node"""
        try:
            data = request.get_json()
            if not data:
                return handle_error("No JSON data provided", 400)

            is_valid, error_msg = validate_required_fields(data, ["node_number", "label"])
            if not is_valid:
                return handle_error(error_msg, 400)

            node_number = data.get("node_number")
            label = data.get("label")

            sid = session_id_from_jwt()
            state = session_manager.resolve(sid)

            if state.node_master is None:
                return handle_error("No tree initialized. Please initialize tree first.", 400)

            node_master_df = pd.DataFrame(state.node_master)
            node_master_df = add_label(node_number, label, node_master_df)

            state.node_master = df_to_json_safe(node_master_df)
            session_manager.persist(sid, state)

            return jsonify({"node_master": df_to_json_safe(node_master_df)})

        except Exception as e:
            return handle_storage_error(e)

    @app.route('/api/exportTree', methods=['GET', 'POST'])
    def exportTree():
        """Export current tree state as JSON (local JSON only)."""
        try:
            sid = session_id_from_jwt()
            state = session_manager.resolve(sid)

            if state.node_master is None:
                return handle_error("No tree to export. Please initialize tree first.", 400)

            # Return JSON response
            return jsonify({
                'file_name': state.file_name,
                'badflag': state.badflag,
                'max_depth': state.max_depth,
                'min_node_split': state.min_node_split,
                'min_leaf_size': state.min_leaf_size,
                'max_branches': state.max_branches,
                'criteria': state.criteria,
                'unique_var': state.unique_var,
                'monotonic': state.monotonic,
                'mapper': df_to_json_safe(pd.DataFrame(state.df_col)),
                'node_master': df_to_json_safe(pd.DataFrame(state.node_master)),
            })

        except Exception as e:
            return handle_storage_error(e)

    @app.route('/api/downloadTree', methods=['GET', 'POST'])
    def downloadTree():
        """Download current tree state as a JSON file (local download only)."""
        try:
            sid = session_id_from_jwt()
            state = session_manager.resolve(sid)

            if state.node_master is None:
                return handle_error("No tree to download. Please initialize tree first.", 400)

            data = {
                'file_name': state.original_data_source or state.file_name,
                'badflag': state.badflag,
                'max_depth': state.max_depth,
                'min_node_split': state.min_node_split,
                'min_leaf_size': state.min_leaf_size,
                'max_branches': state.max_branches,
                'criteria': state.criteria,
                'unique_var': state.unique_var,
                'monotonic': state.monotonic,
                'mapper': df_to_json_safe(pd.DataFrame(state.df_col)),
                'node_master': df_to_json_safe(pd.DataFrame(state.node_master)),
            }

            # Return file download
            json_str = json.dumps(data, indent=2)
            response = Response(
                json_str,
                mimetype="application/json",
                headers={"Content-Disposition": "attachment;filename=tree_export.json"},
            )
            return response

        except Exception as e:
            return handle_storage_error(e)

    @app.route('/api/getTreeData', methods=['GET'])
    def getTreeData():
        """Get current tree data"""
        try:
            sid = session_id_from_jwt()
            state = session_manager.resolve(sid)

            if state.node_master is None:
                return handle_error("No tree data available. Please build a tree first.", 400)

            # state.node_master is already a JSON-safe list of records.
            return jsonify({"node_master": state.node_master})

        except Exception as e:
            return handle_storage_error(e)

    @app.route('/api/health', methods=['GET'])
    def health_check():
        """Health check endpoint"""
        return jsonify({"status": "healthy", "message": "Decision Tree API is running"})

    # Register static / SPA serving LAST so the explicit /api routes above take
    # precedence over the catch-all (Requirements 2.1-2.6).
    if static_dir is None:
        static_dir = resolve_static_dir()
    register_frontend_routes(app, Path(static_dir))

    return app
