"""In-memory application state for Bosco.

Replaces the entire ``backend/session/`` package (Redis metadata store, on-disk
parquet DataFrame store, per-worker LRU cache, and the APScheduler cleanup) with
a tiny in-process, single-user, in-memory model suitable for a locally installed
single-process utility.

Two pieces live here:

* :class:`AppState` -- a plain dataclass mirroring the *field shapes* of the
  original ``backend/session/state.py`` :class:`SessionState` (so the JSON
  contracts used by ``df_to_json_safe`` / export / import stay unchanged), but
  with the heavy ``pandas`` DataFrames held **directly in memory**
  (``df`` / ``df_for_tree``) in place of the opaque store-key pointers
  (``df_key`` / ``df_for_tree_key``). ``node_datasets`` is intentionally not
  stored -- it is rederived on demand, matching the original semantics.

* :class:`InMemorySessionManager` -- a thin facade exposing the same method
  surface as the original ``backend/session/manager.py`` :class:`SessionManager`
  (``resolve`` / ``persist`` / ``set_dataframe`` / ``active_df`` /
  ``active_df_for_tree`` / ``node_datasets_for`` / ``purge``) so the copied Flask
  endpoints need only minimal edits. State is a module-level singleton; because
  everything lives in memory for one local user, ``persist`` is a no-op and
  ``resolve`` always returns the same live object.

No Redis, JWT, boto3, or disk pointers are imported or referenced here
(Requirements 4.1-4.5, 9.1, 9.2).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

import pandas as pd


@dataclass
class AppState:
    """Single-user, in-memory application state.

    Field shapes mirror the original ``SessionState`` so the JSON-safe payloads
    (``df_col`` / ``node_master`` / ``X_col``) keep identical structure and the
    export / import / ``df_to_json_safe`` contracts are unchanged
    (Requirements 4.5, 9.1, 9.2).

    The defaults match the original ``SessionState`` defaults exactly so that
    behavior relying on those defaults (hyperparameter seeds, ``regression_flag``
    gate, the ``None`` sentinel for the small tables) is preserved. The only
    structural change: the heavy ``df_key`` / ``df_for_tree_key`` pointers are
    replaced by the actual ``pd.DataFrame`` objects held in memory, and
    ``node_datasets`` is not stored (rederived on demand).
    """

    # --- identifiers / source ---
    file_name: Optional[str] = None
    original_data_source: Optional[str] = None  # original path / URL / s3://

    # --- target & mode ---
    badflag: Optional[str] = None
    regression_flag: int = 0

    # --- hyperparameters (original SessionState defaults) ---
    max_depth: int = 5
    min_node_split: int = 500
    min_leaf_size: int = 100
    max_branches: int = 5
    criteria: str = "entropy"
    unique_var: int = 0
    monotonic: int = 0

    # --- small tables (JSON-serializable; default None to match original) ---
    df_col: Optional[list[dict]] = None       # column_name/datatype rows
    node_master: Optional[list[dict]] = None  # the tree (df_to_json_safe output)
    X_col: Optional[list[str]] = None         # feature column names

    # --- heavy DataFrames held DIRECTLY in memory ---
    # These replace the original opaque store-key pointers
    # (``df_key`` / ``df_for_tree_key``). ``node_datasets`` is intentionally
    # absent -- it is rederived on demand via ``node_datasets_for``.
    df: Optional[pd.DataFrame] = None           # raw uploaded df
    df_for_tree: Optional[pd.DataFrame] = None  # processed features + 'badflag'


# The known heavy-frame names and the AppState attribute each maps to.
# ``set_dataframe`` uses this to decide which frame field to populate, mirroring
# the original manager's ``_NAME_TO_KEY_FIELD`` mapping.
_NAME_TO_FRAME_FIELD = {
    "df": "df",
    "df_for_tree": "df_for_tree",
}


class InMemorySessionManager:
    """Facade matching the old ``SessionManager`` surface, backed by a single
    in-memory :class:`AppState` singleton for one local user.

    Unlike the original, there is no Redis store, no on-disk DataFrame store, and
    no worker cache: ``resolve`` always returns the same live object and
    ``persist`` is a no-op because mutations are already visible in memory.
    """

    def __init__(self) -> None:
        self._state = AppState()
        # --- node_datasets cache ---
        # ``node_datasets`` is fully derivable from (df_for_tree, node_master).
        # Recomputing it on every interactive endpoint call is the single
        # largest repeated cost (profiling: ~0.94s/call). We cache the derived
        # frame and only recompute when either input changes.
        #
        # ``state.node_master`` is reassigned to a *new* list object on every
        # tree mutation (``state.node_master = df_to_json_safe(...)``), and
        # ``df_for_tree`` is replaced wholesale when data is (re)processed, so
        # the ``id()`` of each input changes exactly when the derived
        # ``node_datasets`` would change. Keying the cache on those identities
        # is therefore both correct and cheap (no content hashing required).
        self._nd_cache = None          # cached node_datasets DataFrame
        self._nd_cache_key = None      # (id(df_for_tree), id(node_master))

    # ------------------------------------------------------------------ #
    # Resolve / persist
    # ------------------------------------------------------------------ #
    def resolve(self, session_id: str) -> AppState:
        """Return the live singleton :class:`AppState`.

        The ``session_id`` is accepted for signature compatibility with the
        original manager but ignored: there is exactly one local user.
        """
        return self._state

    def persist(self, session_id: str, state: AppState) -> None:
        """No-op: state is live in memory, so writes are already durable within
        the running process. Accepts the original ``(session_id, state)``
        signature so the copied endpoints' ``persist`` calls work unchanged.
        """
        # Intentionally nothing to do -- mutations on ``state`` are already
        # reflected in the singleton because ``resolve`` hands back the same
        # object.
        return None

    # ------------------------------------------------------------------ #
    # Heavy DataFrame write
    # ------------------------------------------------------------------ #
    def set_dataframe(
        self,
        session_id: str,
        state: AppState,
        name: str,
        df: pd.DataFrame,
    ) -> pd.DataFrame:
        """Store ``df`` directly on ``state`` in memory and return it.

        Contract (for Task 5 / app.py adaptation):
        * Sets ``state.df`` when ``name == "df"`` and ``state.df_for_tree`` when
          ``name == "df_for_tree"`` (unknown names are ignored, mirroring the
          original manager's ``_NAME_TO_KEY_FIELD.get(name)`` guard).
        * **Returns the DataFrame itself.** The original endpoints assign the
          return value, e.g. ``state.df_key = session_manager.set_dataframe(...)``.
          Because the frame is set in memory here, that residual assignment is
          harmless (it would just stash the frame on a now-unused attribute) and
          will be removed in Task 5. The key point: calling ``set_dataframe`` as
          in the original app.py neither raises nor loses data.
        """
        frame_field = _NAME_TO_FRAME_FIELD.get(name)
        if frame_field is not None:
            setattr(state, frame_field, df)
        return df

    # ------------------------------------------------------------------ #
    # Heavy DataFrame hydration
    # ------------------------------------------------------------------ #
    def active_df(self, state: AppState) -> Optional[pd.DataFrame]:
        """Return the raw uploaded frame held in memory (or ``None``)."""
        return state.df

    def active_df_for_tree(self, state: AppState) -> Optional[pd.DataFrame]:
        """Return the processed tree frame, falling back to the raw frame.

        Matches the design: ``df_for_tree`` if present, otherwise ``df``.
        """
        return state.df_for_tree if state.df_for_tree is not None else state.df

    # ------------------------------------------------------------------ #
    # node_datasets rederivation
    # ------------------------------------------------------------------ #
    def node_datasets_for(self, state: AppState):
        """Rederive the per-node data slices for ``state``.

        Rebuilds the ``mapper`` DataFrame from ``state.df_col`` and the
        ``node_master`` DataFrame from ``state.node_master``, hydrates
        ``df_for_tree`` via :meth:`active_df_for_tree`, and calls the copied
        ``util.create_node_datasets(df_for_tree, mapper, node_master)``.

        ``create_node_datasets`` returns ``(node_master, node_datasets)``; only
        ``node_datasets`` is returned here, matching the original
        ``SessionManager.node_datasets_for`` semantics. ``node_datasets`` is
        never stored -- it is fully derivable, so it is recomputed on demand.
        """
        df_for_tree = self.active_df_for_tree(state)
        if df_for_tree is None:
            raise ValueError(
                "Cannot rederive node_datasets: df_for_tree is not available. "
                "Complete data setup first."
            )

        # Cache hit: inputs unchanged since last computation. ``node_master`` is
        # reassigned to a fresh list on every tree mutation and ``df_for_tree``
        # is swapped wholesale on reprocessing, so identity equality here is a
        # safe proxy for "the derived node_datasets is still valid".
        cache_key = (id(df_for_tree), id(state.node_master))
        if self._nd_cache is not None and self._nd_cache_key == cache_key:
            return self._nd_cache

        # Imported lazily to avoid a heavy import at module load, mirroring the
        # original manager's deferred ``from util import create_node_datasets``.
        from bosco.util import create_node_datasets

        mapper = pd.DataFrame(state.df_col)
        node_master = pd.DataFrame(state.node_master)

        _node_master, node_datasets = create_node_datasets(
            df_for_tree, mapper, node_master
        )

        self._nd_cache = node_datasets
        self._nd_cache_key = cache_key
        return node_datasets

    # ------------------------------------------------------------------ #
    # Workspace teardown
    # ------------------------------------------------------------------ #
    def purge(self, session_id: str) -> None:
        """Reset the singleton to a fresh default :class:`AppState`.

        This is the former logout / fresh-start path. After return, every field
        is back to its default and both heavy frames are dropped. Idempotent.
        """
        self._state = AppState()
        # Drop the derived-frame cache so a fresh workspace never serves slices
        # computed from the previous dataset/tree.
        self._nd_cache = None
        self._nd_cache_key = None


# Module-level singleton: one local user, one live state.
session_manager = InMemorySessionManager()


def session_id_from_jwt() -> str:
    """Return the constant single-user session id.

    Shim replacing the original JWT-derived identity. There is no auth in the
    packaged app (Requirement 5), so every request maps to the same ``"local"``
    session.
    """
    return "local"
