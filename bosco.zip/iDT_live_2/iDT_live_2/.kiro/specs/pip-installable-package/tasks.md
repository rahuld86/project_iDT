# Implementation Plan: Pip-Installable Package (bosco)

## Overview

This plan builds the self-contained `bosco/` package (Bosco_Dir) that repackages the existing Tree Forge app as a pip-installable, single-user, in-memory local utility. Work proceeds bottom-up: scaffold the package and metadata, copy the pure tree logic, build the in-memory state facade, add static/SPA serving, adapt the Flask app factory, add the CLI launcher, wire the frontend build helper and packaging data, then layer in property-based, unit, integration, and smoke tests.

**HARD CONSTRAINT (Requirement 10):** All new and adapted code lives only under the new top-level `bosco/` directory. No file under `backend/` or `frontend/` is edited or deleted. Reuse is by copy + adapt.

The design specifies Python with Flask, Waitress, pytest, and hypothesis, so no implementation-language selection is needed.

## Tasks

- [x] 1. Scaffold the `bosco/` package skeleton and packaging metadata
  - Create the src-layout directory structure: `bosco/src/bosco/`, `bosco/scripts/`, `bosco/tests/`, and `bosco/src/bosco/static/` (placeholder).
  - Create `bosco/src/bosco/__init__.py` with a `__version__ = "0.1.0"` and package exports; create empty module stubs `app.py`, `state.py`, `util.py`, `cli.py`, `serving.py`.
  - Create `bosco/pyproject.toml` with PEP 621 metadata: `name = "bosco"`, `version`, `requires-python = ">=3.10,<3.13"`, runtime dependencies (`Flask`, `Flask-CORS`, `Werkzeug`, `waitress`, `pandas==2.2.3`, `numpy==1.26.4`), console entry point `bosco = "bosco.cli:main"`, and the `hatchling` build backend with `[tool.hatch.build.targets.wheel]` packages `["src/bosco"]`.
  - Explicitly EXCLUDE `redis`, `boto3`, `gunicorn`, `Flask-JWT-Extended`, `APScheduler`, `python-dotenv`, and `pyarrow` from dependencies.
  - Create `bosco/README.md` with install + usage notes.
  - _Requirements: 7.3, 8.1, 8.2, 8.4, 8.5, 10.1, 10.7, 1.1_

- [x] 2. Copy pure tree logic into the package
  - Copy `backend/util.py` verbatim into `bosco/src/bosco/util.py` (do NOT modify the original under `backend/`).
  - Verify imports in the copy are pure-Python/pandas/numpy and require no adaptation.
  - _Requirements: 10.4, 9.2_

- [x] 3. Implement in-memory state (`state.py`)
  - [x] 3.1 Implement `AppState` dataclass and `InMemorySessionManager` facade
    - Define `AppState` with the same field shapes as `SessionState` (`file_name`, `original_data_source`, `badflag`, `regression_flag`, hyperparameters, `df_col`, `node_master`, `X_col`) plus `df` and `df_for_tree` held directly in memory (replacing `df_key`/`df_for_tree_key`); do not store `node_datasets`.
    - Implement `InMemorySessionManager` facade over a module-level singleton with `resolve`, `persist` (no-op), `set_dataframe`, `active_df`, `active_df_for_tree`, `node_datasets_for` (rederive via `util.create_node_datasets`), and `purge` (reset to default `AppState`).
    - Implement module-level `session_manager` singleton and `session_id_from_jwt()` shim returning constant `"local"`.
    - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 9.1, 9.2_

  - [x]* 3.2 Write property test for in-memory write/read round-trip
    - **Property 7: In-memory write/read round-trip within a run**
    - Use hypothesis to generate state field values and small DataFrames; write via the facade, then assert `resolve`/`active_df`/`active_df_for_tree` return equivalent values. Tag `# Feature: pip-installable-package, Property 7`, min 100 iterations.
    - **Validates: Requirements 4.2**

  - [x]* 3.3 Write property test for fresh empty state on a new run
    - **Property 8: Fresh empty state on a new run**
    - Use hypothesis to apply arbitrary mutations, then construct a new manager (simulating a new process) and assert the `AppState` equals the default empty state. Tag `# Feature: pip-installable-package, Property 8`, min 100 iterations.
    - **Validates: Requirements 4.4**

- [x] 4. Implement static / SPA serving (`serving.py`)
  - [x] 4.1 Implement asset resolution and route registration
    - Implement `resolve_static_dir()` using `importlib.resources.files("bosco") / "static"` with a `Path(__file__).parent / "static"` fallback.
    - Implement `register_frontend_routes(app, static_dir)`: `GET /` returns `index.html`; existing-file paths are served with correct content type; non-existent paths with a file extension return 404; non-`api/`, non-asset paths return `index.html` (SPA fallback). Ensure explicit `/api/*` routes take precedence.
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 3.4_

  - [x]* 4.2 Write property test for SPA fallback on non-API, non-asset paths
    - **Property 1: SPA fallback for non-API, non-asset paths**
    - Generate client-route paths (no `api/` prefix, no matching asset); assert HTTP 200 and `index.html` body. Tag `# Feature: pip-installable-package, Property 1`, min 100 iterations.
    - **Validates: Requirements 2.4**

  - [x]* 4.3 Write property test for missing static asset returns 404
    - **Property 2: Missing static asset returns 404**
    - Generate asset-looking paths (with extension) absent from the static dir; assert HTTP 404 and that the body is not the SPA shell. Tag `# Feature: pip-installable-package, Property 2`, min 100 iterations.
    - **Validates: Requirements 2.6**

  - [x]* 4.4 Write property test for bundled assets served with matching content type
    - **Property 4: Bundled assets served with matching content type**
    - Populate a temp static dir with generated asset files; request each and assert HTTP 200 and a `Content-Type` consistent with the extension. Tag `# Feature: pip-installable-package, Property 4`, min 100 iterations.
    - **Validates: Requirements 2.3**

- [x] 5. Adapt the Flask app factory (`app.py`)
  - [x] 5.1 Build `create_app(static_dir, max_upload_bytes)` from the copied app logic
    - Copy the relevant parts of `backend/app.py` into `bosco/src/bosco/app.py` as a `create_app` factory (do NOT modify the original).
    - Remove `flask_jwt_extended`/`JWTManager` and all `@jwt_required`; remove `load_dotenv` and `AUTH_USERS`/`JWT_SECRET_KEY` config.
    - Remove the five dropped endpoints (`/api/login`, `/api/logout`, `/api/user`, `/api/verify`, `/api/uploadFileToS3`) and all S3 helpers (`get_s3_client`, `is_s3_path`, `parse_s3_path`, `download_from_s3`, `upload_to_s3`) plus URL-fetch branches.
    - Keep `df_to_json_safe`, `validate_required_fields`, `validate_file_exists`, `handle_error`, the `@errorhandler(413)`, and `MAX_CONTENT_LENGTH` (sensible default).
    - Simplify `handle_storage_error`: keep the `HTTPException` re-raise, `OSError`/`IOError` → 500, and generic → 500; drop the Redis 503 branch and the `SessionDataExpired`/`KeyError` 400 branch.
    - Wire endpoints to `bosco.state` (`session_manager`, `session_id_from_jwt`) keeping the `resolve`/`persist` lines; preserve all ~24 non-auth endpoints.
    - Scope `flask_cors` CORS to localhost origins (`http://127.0.0.1:*` / `http://localhost:*`) and register frontend routes from `serving.py`.
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 6.1, 6.2, 6.3, 6.4, 6.5, 9.1, 9.3_

  - [x] 5.2 Restrict `/api/upload` to local file uploads only
    - Remove remote/S3/URL handling from the upload path so only local file uploads remain.
    - _Requirements: 6.1, 6.3, 6.4_

  - [x]* 5.3 Write property test for API paths never returning the SPA shell
    - **Property 3: API paths never return the SPA shell**
    - Generate `/api/...` paths; assert responses are API-produced (handler result or API 404/405) and never the `index.html` shell. Tag `# Feature: pip-installable-package, Property 3`, min 100 iterations.
    - **Validates: Requirements 2.5**

  - [x]* 5.4 Write property test for preserved endpoints reachable without authentication
    - **Property 5: Preserved endpoints reachable without authentication**
    - Parameterize over the preserved endpoint list via the test client; assert no 401/auth-redirect and that each route is registered/reachable. Tag `# Feature: pip-installable-package, Property 5`, min 100 iterations.
    - **Validates: Requirements 5.1, 5.2, 9.1**

  - [x]* 5.5 Write property test for dropped endpoints returning 404
    - **Property 6: Dropped endpoints return 404**
    - Parameterize over the dropped endpoint list; assert HTTP 404 (route not registered). Tag `# Feature: pip-installable-package, Property 6`, min 100 iterations.
    - **Validates: Requirements 5.3, 9.1**

  - [x]* 5.6 Write unit/example tests for app behavior
    - Root returns `index.html` (2.2); local CSV upload accepted (6.1); download delivers payload (6.2); no S3/URL special-casing (6.3, 6.4); localhost CORS headers present (9.3); `create_app()` succeeds with no auth env vars (5.4).
    - _Requirements: 2.2, 5.4, 6.1, 6.2, 6.3, 6.4, 9.3_

- [x] 6. Checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 7. Implement the CLI launcher (`cli.py`)
  - [x] 7.1 Implement argument parsing, port selection, and `main()`
    - Implement `parse_args(argv)` with `--host` (default `127.0.0.1`), `--port` (default `8765`), `--no-browser`.
    - Implement `find_available_port(host, preferred)`: bind the preferred port if free, else bind port 0 for an OS-assigned free port.
    - Implement `main(argv=None)`: select the port, call `create_app`, print the local URL WITHOUT any token, open the browser (unless `--no-browser`) from a background thread that polls for TCP readiness then calls `webbrowser.open`, serve via `waitress.serve(..., threads=1)`, and handle `KeyboardInterrupt`/SIGINT for clean shutdown and port release.
    - _Requirements: 1.2, 1.3, 1.4, 1.5, 1.6, 5.5, 7.1, 7.2_

  - [x]* 7.2 Write property test for port selection returning a bindable port
    - **Property 10: Port selection returns a bindable port**
    - Occupy random sets of ports with real sockets; assert `find_available_port` returns a port that can be bound and returns the preferred port whenever it is free. Tag `# Feature: pip-installable-package, Property 10`, min 100 iterations.
    - **Validates: Requirements 1.5**

  - [x]* 7.3 Write unit/example tests for launcher output and flags
    - URL printed without a token (1.3, 5.5); `--no-browser` suppresses browser launch (1.4).
    - _Requirements: 1.3, 1.4, 5.5_

- [x] 8. Implement the frontend build helper (`scripts/build_frontend.py`)
  - Build the frontend read-only from `frontend/tree-forge-ui/` with `VITE_API_BASE_URL` unset (`npm ci` + `npm run build`); do NOT modify any tracked frontend source.
  - Copy only `dist/*` into `bosco/src/bosco/static/` (replacing contents).
  - Fail with a clear `SystemExit`/error naming the missing Frontend_Assets if `static/index.html` is absent after the build.
  - _Requirements: 3.1, 3.2, 3.5, 3.6, 10.5_

- [x] 9. Wire package data for frontend assets
  - Create `bosco/MANIFEST.in` to include `src/bosco/static/**` in the sdist.
  - Confirm `pyproject.toml` package-data/build config includes `src/bosco/static/**` in the wheel.
  - _Requirements: 3.3, 3.4, 10.6_

- [x] 10. Export/import round-trip validation
  - [x]* 10.1 Write property test for export then import round-trip equivalence
    - **Property 9: Export then import round-trip equivalence**
    - Generate small datasets, build a tree through the facade, round-trip through `exportTree`/`importTree`, and compare normalized `node_master`/`df_col` JSON. Tag `# Feature: pip-installable-package, Property 9`, min 100 iterations.
    - **Validates: Requirements 9.2**

- [x] 11. Integration tests
  - [x]* 11.1 Write integration tests for launcher, build helper, and serving
    - `main()` starts (mocked) Waitress and opens (mocked) browser (1.2); interrupt releases the bound port (1.6); build helper copies `dist` and leaves FE source unmodified verified via before/after hashing (3.1, 3.2); no app-state files written to disk after a run (4.3); Waitress serves without Gunicorn (7.1, 7.2).
    - _Requirements: 1.2, 1.6, 3.1, 3.2, 4.3, 7.1, 7.2_

- [x] 12. Smoke tests
  - [x]* 12.1 Write smoke tests for packaging, assets, and isolation
    - Entry point `bosco` declared (1.1); wheel contains `static/index.html` (3.3); `resolve_static_dir()` resolves a dir containing `index.html` (3.4); `create_app()` works with no auth env (5.4); `pyproject` metadata fields and `requires-python` constraint present (7.3, 8.1, 8.2); excluded deps absent (`boto3`/`redis`/`gunicorn`/`Flask-JWT-Extended`) (6.5, 8.4); `python -m build` yields wheel + sdist (8.5); `backend/` and `frontend/` tracked files unchanged and all new code under `bosco/` (10.1–10.7).
    - _Requirements: 1.1, 3.3, 3.4, 5.4, 6.5, 7.3, 8.1, 8.2, 8.4, 8.5, 10.1, 10.2, 10.3, 10.4, 10.5, 10.6, 10.7_

- [x] 13. Set up test tooling under `bosco/`
  - Add pytest + hypothesis configuration under `bosco/` (e.g. `bosco/tests/` package, pytest config in `pyproject.toml` or `pytest.ini`), and ensure the test dependencies are declared (test extra) so the suite runs within the workspace.
  - _Requirements: 8.2_

- [x] 14. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x]* 15. Optional polish
  - [x]* 15.1 Expand `README.md` with troubleshooting and platform notes
    - Add Windows/macOS usage details and `--host`/`--port`/`--no-browser` examples.
    - _Requirements: 7.1_
  - [x]* 15.2 Add extra example tests for edge cases
    - Additional upload/download edge-case and content-type examples beyond the required set.
    - _Requirements: 6.1, 6.2_

## Notes

- Tasks marked with `*` are optional (test-writing sub-tasks and polish) and can be skipped for a faster MVP, but they validate the design's correctness properties and are recommended.
- Each task references specific requirement sub-clauses for traceability; property sub-tasks reference their design Property number and the requirement they validate.
- There is exactly one property-based test per correctness property (Properties 1–10), each tagged and run at a minimum of 100 iterations with hypothesis.
- Checkpoints ensure incremental validation.
- Publishing to PyPI and manual browser testing are intentionally out of scope for these coding tasks; publishing can be done separately after the wheel/sdist build is verified by the smoke tests.
- The Requirement 10 isolation constraint applies to every task: never edit or delete anything under `backend/` or `frontend/`.
