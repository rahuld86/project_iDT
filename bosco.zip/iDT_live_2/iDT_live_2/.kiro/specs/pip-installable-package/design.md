# Design Document

## Overview

This design packages the existing Tree Forge application (a Flask backend plus a Vite/React/TypeScript frontend) into a single pip-installable Python distribution named `bosco`, modeled on the `pip install jupyterlab` experience. After `pip install bosco`, the user runs one console command, `bosco`, which starts a local single-threaded HTTP server, serves the pre-built frontend from the same process and port, and opens the default browser.

The design is governed by one hard constraint (Requirement 10): **all new and adapted code lives in a new, self-contained top-level `bosco/` directory (the Bosco_Dir). The existing `backend/` and `frontend/` directories are never edited or deleted.** Existing code is recycled by *copying* it into the Bosco_Dir and adapting the copies there. The original app continues to work unchanged.

The repackaged app is a purely client-side, single-user, single-process, in-memory utility. The multi-user server machinery of the Existing_App is dropped:

- No Redis, no disk DataFrame store, no LRU cache, no APScheduler cleanup (replaces the entire `backend/session/` package with a tiny in-memory `AppState`). (Requirement 4)
- No authentication, no JWT, no sessions (drops `/api/login`, `/api/logout`, `/api/user`, `/api/verify`). (Requirement 5)
- No S3/boto3, no URL fetching; local file I/O only (drops `/api/uploadFileToS3`). (Requirement 6)
- No Gunicorn/nginx; a cross-platform WSGI server (Waitress) serves both API and static assets on Windows and macOS (Linux as a bonus). (Requirements 2, 7)

Key investigated facts that shape this design:

- **Frontend API base is already relative-friendly.** `frontend/tree-forge-ui/src/services/api.ts` uses `const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || '/api';` and `authService.ts` uses the same fallback. Building the frontend with `VITE_API_BASE_URL` **unset** yields a relative `/api` base, so requests hit the same origin that serves the page. No source edit is needed. (Requirement 9.3)
- **Export/import/download use JSON/CSV, not parquet.** The API layer returns data via `jsonify` + `df_to_json_safe`; parquet appears only in the dropped session storage layer and in a comment. Therefore `pyarrow` is **not required** at runtime and can be excluded from dependencies. (Requirement 8.2)
- **`util.py` is pure tree logic** imported by `app.py` and can be copied unmodified into the Bosco_Dir. (Requirement 10.4)

## Architecture

### Runtime architecture

At runtime there is a single process. The Launcher (invoked by the `bosco` console command) builds the Flask app via an app factory, then serves it with Waitress on `127.0.0.1:<port>`. The same Flask app both routes `/api/*` to preserved backend handlers and serves the bundled frontend (SPA) for all other paths. All state lives in a module-level in-memory `AppState` singleton.

```mermaid
flowchart TD
    User([User terminal]) -->|runs 'bosco'| CLI[cli.main Launcher]
    CLI -->|select free port if needed| Port{Port in use?}
    Port -->|yes| Pick[pick available port]
    Port -->|no| Use[use requested port]
    Pick --> Factory
    Use --> Factory
    CLI -->|create_app| Factory[app factory]
    Factory --> Flask[Flask app]
    CLI -->|waitress.serve single thread| Server[Local_Server 127.0.0.1:port]
    CLI -->|after ready, unless --no-browser| Browser[[webbrowser.open]]

    Browser --> Server
    Server -->|GET / or client route| SPA[serve index.html]
    Server -->|GET /assets/*| Static[serve bundled asset or 404]
    Server -->|/api/* preserved| API[API handlers]
    API --> State[(AppState singleton in memory)]
    API --> Util[util.py tree logic]
```

### Request routing

A single catch-all plus explicit `/api` routes resolve every request:

1. `GET /` and any non-`/api`, non-asset path return `index.html` (SPA fallback) so client-side routing resolves. (Requirements 2.2, 2.4)
2. A request matching a real file under the bundled assets returns that file with a correct content type. (Requirement 2.3)
3. A request to a path under `/api/*` is routed to the corresponding handler, never to `index.html`. (Requirement 2.5)
4. A request for a static asset path that does not exist returns HTTP 404 (not the SPA shell). (Requirement 2.6)

### Packaging / build architecture

The Wheel bundles the pre-built frontend as package data so end users need no Node.js. The frontend is built from the Existing_App source (read-only) and only the `dist/` output is copied into the Bosco_Dir package's static folder. A build-time check fails if the assets are missing. (Requirements 3.1–3.6, 10.5–10.6)

```mermaid
flowchart LR
    subgraph ExistingApp[Existing_App read-only]
      FE[frontend/tree-forge-ui source]
    end
    subgraph BoscoDir[Bosco_Dir self-contained]
      BuildScript[build helper script]
      Static[bosco/src/bosco/static/]
      PkgCode[adapted backend + cli + util]
      PyProject[pyproject.toml]
    end

    BuildScript -->|npm ci and npm run build in copy or read-only source| Dist[(dist output)]
    Dist -->|copy only dist output| Static
    FE -. unmodified .-> Dist
    BuildScript -->|verify assets present else fail| Check{index.html exists?}
    PyProject -->|python -m build| Wheel[(bosco-x.y.z.whl + sdist)]
    Static --> Wheel
    PkgCode --> Wheel
    Wheel -->|pip install bosco| SitePackages[(site-packages/bosco)]
```

## Directory Layout of `bosco/`

The Bosco_Dir is self-contained (Requirement 10.7). It uses a `src/` layout so the installed package resolves assets from site-packages cleanly.

```
bosco/                              # Bosco_Dir (new, top-level)
├── pyproject.toml                  # PEP 621 metadata, deps, entry point, build backend
├── README.md                      # install + usage
├── MANIFEST.in                    # include static assets in sdist (if needed by backend)
├── scripts/
│   └── build_frontend.py          # build helper: build FE read-only, copy dist -> static, verify
└── src/
    └── bosco/
        ├── __init__.py            # version, exports
        ├── app.py                 # adapted Flask app factory (create_app) + API routes
        ├── state.py               # AppState + SessionManager-compatible facade (in-memory)
        ├── util.py                # COPIED UNMODIFIED from backend/util.py
        ├── cli.py                 # console entry point: main()
        ├── serving.py             # static/SPA serving helpers + asset path resolution
        └── static/                # BUILT Frontend_Assets (package data)
            ├── index.html
            └── assets/            # hashed JS/CSS, favicon, etc.
```

Notes:
- `backend/util.py` is copied verbatim into `src/bosco/util.py` (Requirement 10.4). If `util.py` has its own imports, they are pure-Python/pandas/numpy and need no adaptation.
- `src/bosco/static/` is generated by the Build_Process; it is not hand-authored and may be gitignored with the understanding the build step repopulates it before wheel build.

## Components and Interfaces

### 1. In-memory state: `AppState` + facade (`state.py`)

The Existing_App threads state through a `SessionManager` with Redis/disk/cache behind pointers (`df_key`, `df_for_tree_key`). For a single-user, single-process tool we replace the entire `backend/session/` package with an in-memory `AppState` that holds the **same field shapes** as `SessionState`, plus the heavy DataFrames held **directly** in memory (not as keys).

**Two options considered:**

- **Option A (recommended): A `SessionManager`-compatible facade backed by memory.** Keep the copied `app.py` almost identical by providing a module-level singleton `session_manager` and `session_id_from_jwt()` shim whose methods (`resolve`, `persist`, `active_df`, `active_df_for_tree`, `set_dataframe`, `node_datasets_for`, `purge`) operate on the in-memory `AppState`. The endpoints' `sid = session_id_from_jwt(); state = session_manager.resolve(sid) ... session_manager.persist(sid, state)` lines keep working unchanged. This minimizes edits to the ~25 copied endpoints and preserves behavior, lowering the risk of regressions (Requirement 9.2).
- **Option B: Rewrite endpoints to use `AppState` directly.** Cleaner end state, but touches every endpoint, increasing regression risk and review surface.

**Recommendation: Option A.** It satisfies Requirement 4 (in-memory, no external store) and Requirement 9 (preserve behavior) with the smallest change to the recycled code. The facade is a thin adapter; the heavy lifting (`util.create_node_datasets`, etc.) is identical.

Facade interface (pseudocode/signatures):

```python
# state.py
@dataclass
class AppState:
    file_name: str | None = None
    original_data_source: str | None = None
    badflag: str | None = None
    regression_flag: bool = False
    # hyperparameters
    max_depth: int | None = None
    min_node_split: int | None = None
    min_leaf_size: int | None = None
    max_branches: int | None = None
    criteria: str | None = None
    unique_var: ... = None
    monotonic: ... = None
    # JSON-safe column/structure payloads (same shapes as SessionState)
    df_col: list[dict] = field(default_factory=list)
    node_master: list[dict] = field(default_factory=list)
    X_col: list[str] = field(default_factory=list)
    # heavy frames held DIRECTLY in memory (replaces df_key / df_for_tree_key)
    df: "pd.DataFrame | None" = None
    df_for_tree: "pd.DataFrame | None" = None
    # node_datasets intentionally NOT stored; rederived on demand

class InMemorySessionManager:
    """Facade matching the old SessionManager surface, single singleton state."""
    def __init__(self): self._state = AppState()
    def resolve(self, sid) -> AppState: return self._state
    def persist(self, sid, state) -> None: pass            # no-op; state is live
    def set_dataframe(self, sid, state, name, df) -> None:  # name in {"df","df_for_tree"}
        setattr(state, name, df)
    def active_df(self, state) -> "pd.DataFrame | None": return state.df
    def active_df_for_tree(self, state) -> "pd.DataFrame | None":
        return state.df_for_tree if state.df_for_tree is not None else state.df
    def node_datasets_for(self, state):                     # identical derivation to original
        mapper = pd.DataFrame(state.df_col)
        node_master = pd.DataFrame(state.node_master)
        df_for_tree = self.active_df_for_tree(state)
        return util.create_node_datasets(df_for_tree, mapper, node_master)
    def purge(self, sid) -> None: self._state = AppState()  # reset; used by former logout/fresh start

session_manager = InMemorySessionManager()   # module-level singleton
def session_id_from_jwt(): return "local"     # constant single-user id shim
```

This keeps `df_to_json_safe`, export/import, and the JSON contracts unchanged because the field shapes (`df_col`, `node_master`, `X_col`) are preserved (Requirement 9.1, 9.2). `node_datasets` remains rederived, matching original semantics.

### 2. App factory (`app.py`)

The copied `app.py` becomes a `create_app()` factory. Adaptations from the original:

- Remove `flask_jwt_extended` import and `JWTManager`; remove all `@jwt_required(...)` decorators. (Requirement 5.2)
- Remove `load_dotenv`/dotenv usage and `AUTH_USERS`/`JWT_SECRET_KEY` config. (Requirement 5.4)
- Remove the five dropped endpoints and the S3 helpers (`get_s3_client`, `is_s3_path`, `parse_s3_path`, `download_from_s3`, `upload_to_s3`). (Requirements 5.3, 6.3–6.5)
- Replace `from session import ...` with `from bosco.state import session_manager, session_id_from_jwt`. Endpoints keep their `resolve/persist` lines (Option A).
- Keep `df_to_json_safe`, `validate_required_fields`, `validate_file_exists`, `handle_error`, the `@app.errorhandler(413)`, and `MAX_CONTENT_LENGTH` (with a sensible default from `MAX_UPLOAD_SIZE`).
- Keep `flask_cors` CORS but scope it to localhost origins for the Local_Server (Requirement 9.3). Since the frontend is same-origin, CORS is mostly a safety net; restrict to `http://127.0.0.1:*` / `http://localhost:*`.
- Register static/SPA routes from `serving.py` (below).

Interface:

```python
def create_app(static_dir: Path | None = None, max_upload_bytes: int | None = None) -> Flask: ...
```

### 3. Static / SPA serving (`serving.py`)

Locates bundled assets and registers routes. Asset resolution must work from site-packages, so it uses `importlib.resources` (preferred) or `Path(__file__).parent / "static"` as fallback. (Requirement 3.4)

```python
def resolve_static_dir() -> Path:
    # importlib.resources.files("bosco") / "static"; fallback to __file__ parent
    ...

def register_frontend_routes(app: Flask, static_dir: Path) -> None:
    # GET "/" -> send index.html
    # GET "/<path:path>":
    #   if path starts with "api/" -> not handled here (API routes win)
    #   if (static_dir / path) is an existing file -> send it (correct mimetype)
    #   if path looks like a static asset (has a file extension) and missing -> 404
    #   else -> send index.html (SPA fallback)
    ...
```

Flask route precedence: explicit `/api/...` rules are registered and match first; the catch-all only handles the remainder. Content types are set by `send_from_directory`/`send_file` based on extension. (Requirements 2.1–2.6)

### 4. Launcher / CLI (`cli.py`)

Console entry point. Responsibilities: parse args, choose a port, build the app, serve with Waitress (cross-platform, production-grade, single-thread), print the URL, open the browser when ready, and shut down cleanly on interrupt.

**Server choice:** Waitress over the Flask dev server. The Flask dev server is explicitly not for general use and is less robust; Waitress is pure-Python, cross-platform (Windows + macOS + Linux), and WSGI-native. Configure `threads=1` for the single-user single-thread requirement. (Requirements 7.1, 7.2)

```python
def parse_args(argv) -> Namespace:   # --host (default 127.0.0.1), --port (default 8765), --no-browser

def find_available_port(host, preferred) -> int:
    # try to bind preferred; on OSError (in use) bind port 0 to get a free one
    ...

def main(argv=None) -> int:
    args = parse_args(argv)
    port = find_available_port(args.host, args.port)      # Requirement 1.5
    app = create_app()
    url = f"http://{args.host}:{port}"
    print(f"Bosco is running at {url}")                   # Requirement 1.3 / 5.5 (no token)
    if not args.no_browser:                               # Requirement 1.4
        open_browser_when_ready(url)                      # background thread polls / then webbrowser.open
    try:
        waitress.serve(app, host=args.host, port=port, threads=1)   # Requirement 1.2, 7
    except KeyboardInterrupt:
        # waitress stops serving; socket released on return         # Requirement 1.6
        return 0
    return 0
```

Browser open happens from a short-lived background thread that waits until the server accepts a TCP connection, then calls `webbrowser.open(url)`, so the page is ready when it opens. The main thread runs `serve()`; `KeyboardInterrupt`/SIGINT ends `serve()` and the bound port is released as the process exits. (Requirement 1.6)

### 5. Packaging config (`pyproject.toml`)

PEP 621 metadata with a modern build backend (hatchling recommended for simple package-data inclusion; setuptools acceptable). Entry point `bosco = bosco.cli:main`. (Requirements 8.1, 8.5)

```toml
[project]
name = "bosco"
version = "0.1.0"
requires-python = ">=3.10,<3.13"          # Requirement 7.3 / 7.4 (numpy 1.26.4 excludes 3.13+)
dependencies = [
    "Flask",
    "Flask-CORS",                          # localhost CORS safety net (Requirement 9.3)
    "Werkzeug",
    "waitress",                            # cross-platform Local_Server (Requirement 7)
    "pandas==2.2.3",
    "numpy==1.26.4",
    # NOTE: pyarrow intentionally omitted (no parquet at runtime); add back only if a copied
    # code path is found to require it. redis/boto3/gunicorn/Flask-JWT-Extended/APScheduler/
    # python-dotenv are intentionally excluded. (Requirements 8.4, 6.5)
]

[project.scripts]
bosco = "bosco.cli:main"                   # Requirement 1.1, 8.1

[tool.hatch.build.targets.wheel]
packages = ["src/bosco"]
# include src/bosco/static/** as package data (Requirement 3.3)
```

Excluded dependencies (Requirement 8.4): `redis`, `boto3`, `gunicorn`, `Flask-JWT-Extended`. Also dropped because unused in-memory: `APScheduler`, `python-dotenv`, and `pyarrow` (pending the build-time check confirming no parquet path).

### 6. Build helper (`scripts/build_frontend.py`)

Operates entirely from within the Bosco_Dir (Requirement 10.5). Builds the frontend **read-only** from `frontend/tree-forge-ui/` (or a copy) with `VITE_API_BASE_URL` unset (relative `/api`), then copies only the `dist/` output into `src/bosco/static/`. Fails if the produced assets (e.g. `index.html`) are missing. (Requirements 3.1, 3.2, 3.5)

```python
def build_frontend():
    # 1. run `npm ci` + `npm run build` against the FE source (do not modify source;
    #    build artifacts land in the FE project's own dist/ which is its normal output)
    # 2. copy dist/* -> src/bosco/static/   (replace contents)
    # 3. assert (static/index.html).exists() else raise SystemExit("Frontend assets missing: ...")
```

Recommended approach: build from the original location read-only and copy only the `dist/` output into the package. (Building creates the FE project's normal `dist/` folder, which is the frontend's own output location, not an edit to tracked source files.)

## Data Models

### AppState (mirrors `SessionState` field shapes; adds live frames)

| Field | Type | Origin / Notes |
|---|---|---|
| `file_name` | `str \| None` | same as SessionState |
| `original_data_source` | `str \| None` | same as SessionState |
| `badflag` | `str \| None` | target column name |
| `regression_flag` | `bool` | same as SessionState |
| `max_depth` | `int \| None` | hyperparameter |
| `min_node_split` | `int \| None` | hyperparameter |
| `min_leaf_size` | `int \| None` | hyperparameter |
| `max_branches` | `int \| None` | hyperparameter |
| `criteria` | `str \| None` | hyperparameter |
| `unique_var` | varies | hyperparameter |
| `monotonic` | varies | hyperparameter |
| `df_col` | `list[dict]` | JSON-safe column metadata (unchanged shape) |
| `node_master` | `list[dict]` | JSON-safe tree node table (unchanged shape) |
| `X_col` | `list[str]` | feature columns |
| `df` | `pd.DataFrame \| None` | **replaces `df_key`**: heavy frame held in memory |
| `df_for_tree` | `pd.DataFrame \| None` | **replaces `df_for_tree_key`**: heavy frame in memory |
| *(node_datasets)* | — | NOT stored; rederived via `util.create_node_datasets` |

The JSON-safe fields (`df_col`, `node_master`, `X_col`) keep identical shapes so `df_to_json_safe`, export, and import contracts are unchanged. (Requirements 4.5, 9.1, 9.2)

### API surface: preserved vs dropped

| Endpoint | Method | Disposition | Reason / Requirement |
|---|---|---|---|
| `/api/test` | GET | Preserve | no auth today (9.1) |
| `/api/health` | GET | Preserve | health check (9.1) |
| `/api/importTree` | POST | Preserve (strip jwt, in-memory) | 5.2, 9.1 |
| `/api/getImportDiagnostics` | GET | Preserve | 9.1 |
| `/api/upload` | POST | Preserve (local file only) | 6.1, 9.1 |
| `/api/setTarget` | POST | Preserve | 9.1 |
| `/api/getRegressionFlag` | GET | Preserve | 9.1 |
| `/api/getTypes` | GET | Preserve | 9.1 |
| `/api/keepVar` | POST | Preserve | 9.1 |
| `/api/defineHP` | POST | Preserve | 9.1 |
| `/api/initTree` | POST | Preserve | 9.1 |
| `/api/autoTree` | POST | Preserve | 9.1 |
| `/api/delSubTree` | POST | Preserve | 9.1 |
| `/api/autoTrainSubTree` | POST | Preserve | 9.1 |
| `/api/findSplit` | POST | Preserve | 9.1 |
| `/api/findVar` | POST | Preserve | 9.1 |
| `/api/bestSplit` | POST | Preserve | 9.1 |
| `/api/evalSplit` | POST | Preserve | 9.1 |
| `/api/addNode` | POST | Preserve | 9.1 |
| `/api/copyNode` | POST | Preserve | 9.1 |
| `/api/labelNode` | POST | Preserve | 9.1 |
| `/api/exportTree` | GET/POST | Preserve (JSON/CSV) | 6.2, 9.1 |
| `/api/downloadTree` | GET/POST | Preserve (local download) | 6.2, 9.1 |
| `/api/getTreeData` | GET | Preserve | 9.1 |
| `/api/login` | POST | **Drop** | 5.3 |
| `/api/logout` | POST | **Drop** | 5.3 |
| `/api/user` | GET | **Drop** | 5.3 |
| `/api/verify` | GET | **Drop** | 5.3 |
| `/api/uploadFileToS3` | POST | **Drop** | 6.3, 6.5 |

### Frontend API base URL handling

The frontend already resolves its API base as `import.meta.env.VITE_API_BASE_URL || '/api'` in both `api.ts` and `authService.ts`. The Build_Process builds the frontend with `VITE_API_BASE_URL` **unset**, so the compiled assets issue requests to the relative `/api` path, which the Local_Server serves from the same origin. No frontend source change is required (satisfying Requirement 10.2/10.3 no-edit isolation and Requirement 9.3 same-origin). `authService.ts` references the dropped `/api/login`; since auth is removed, the login flow is not exercised by the packaged app — the catch-all SPA routing still serves the UI, and any residual auth calls simply 404 without affecting core tree workflows.

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system — essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

Property-based testing applies to this feature's **pure routing and state logic** (SPA/static routing decisions, in-memory state round-trips, export/import JSON round-trip, and port selection). Packaging metadata, build steps, pip behavior, browser launch, and signal handling are verified with smoke/integration/example tests instead (see Testing Strategy), because their behavior does not vary meaningfully with input.

### Property 1: SPA fallback for non-API, non-asset paths

*For any* request path that does not start with `api/` and does not correspond to an existing bundled asset (i.e. a client-side route, typically with no file extension), the Local_Server returns the Frontend_Assets entry HTML document (`index.html`) with a 200 status.

**Validates: Requirements 2.4**

### Property 2: Missing static asset returns 404

*For any* request path that looks like a static asset (has a file extension) and is not present in the bundled Frontend_Assets, the Local_Server returns HTTP 404 (and does not return the SPA entry document).

**Validates: Requirements 2.6**

### Property 3: API paths never return the SPA shell

*For any* request path under `/api/`, the response is produced by API routing (a handler result or an API-level 404/405) and is never the Frontend_Assets entry HTML document.

**Validates: Requirements 2.5**

### Property 4: Bundled assets served with matching content type

*For any* bundled asset file present in the static directory, requesting its path returns HTTP 200 with a `Content-Type` consistent with the asset's file extension.

**Validates: Requirements 2.3**

### Property 5: Preserved endpoints reachable without authentication

*For any* preserved Backend API endpoint, issuing a request without any authentication credentials does not fail due to authentication (no 401/unauthorized and no auth redirect); the endpoint is registered and reachable.

**Validates: Requirements 5.1, 5.2, 9.1**

### Property 6: Dropped endpoints return 404

*For any* dropped endpoint (`/api/login`, `/api/logout`, `/api/user`, `/api/verify`, `/api/uploadFileToS3`), the Local_Server returns HTTP 404 because the route is not registered.

**Validates: Requirements 5.3, 9.1**

### Property 7: In-memory write/read round-trip within a run

*For any* set of application-state field values (including DataFrames written via `set_dataframe`), after writing them through the in-memory facade a subsequent read (`resolve`/`active_df`/`active_df_for_tree`) within the same running process returns equivalent values.

**Validates: Requirements 4.2**

### Property 8: Fresh empty state on a new run

*For any* sequence of state mutations performed on an in-memory manager, constructing a new manager (simulating a new process launch) yields an `AppState` equal to the default empty state.

**Validates: Requirements 4.4**

### Property 9: Export then import round-trip equivalence

*For any* uploaded dataset and built tree, exporting the tree via `exportTree` and then importing that exported payload via `importTree` reproduces an equivalent tree state (equivalent `node_master`/`df_col` JSON structures).

**Validates: Requirements 9.2**

### Property 10: Port selection returns a bindable port

*For any* set of occupied ports, `find_available_port` returns a port that can actually be bound on the host, and returns the requested preferred port whenever that port is free.

**Validates: Requirements 1.5**

## Error Handling

The error-handling contract is adapted from the Existing_App's `handle_error` / `handle_storage_error`, with the multi-user/storage classifications removed because they are dead code in a single-process in-memory tool:

- **Keep `handle_error(message, status_code)`** — logs and returns `jsonify({"error": message}), status_code`. Unchanged.
- **Keep the 413 handler** — `@app.errorhandler(413)` returns `{"error": "Payload Too Large"}` when `MAX_CONTENT_LENGTH` (from a sensible `MAX_UPLOAD_SIZE` default, ~600MB) is exceeded. (Requirement 8.2 contract)
- **Simplify `handle_storage_error`** into a generic exception classifier:
  - Re-raise `werkzeug.exceptions.HTTPException` (e.g. 413) so Flask's handlers produce the right response — preserved.
  - **Drop** the Redis `ConnectionError`/`TimeoutError` → 503 branch (no Redis).
  - **Drop** the `SessionDataExpired`/`KeyError` → 400 "session data expired" branch (no disk-backed pointers; frames live in memory, so there is no stale-pointer case).
  - **Keep** `OSError`/`IOError` → HTTP 500 with storage context (covers local file read/write failures on upload/download). (Requirement 6.1, 6.2)
  - **Keep** the generic fallback → HTTP 500 with the error message.
- **Static/SPA errors:** missing asset with a file extension → 404 (Property 2 / Requirement 2.6); non-asset, non-API path → 200 SPA shell (Property 1 / Requirement 2.4).
- **Launcher errors:** if the preferred port is occupied, selection falls back to an OS-assigned free port rather than erroring (Requirement 1.5); `KeyboardInterrupt`/SIGINT is caught to stop serving and release the port cleanly (Requirement 1.6).
- **Build errors:** the build helper raises a clear `SystemExit`/error naming the missing Frontend_Assets when `index.html` is absent (Requirement 3.5).

Because `SessionDataExpired` and the Redis error types no longer exist in the Bosco_Dir, the simplified classifier imports neither; the copied endpoints' `except Exception as e: return handle_storage_error(e)` blocks keep working against the reduced classifier with no per-endpoint edits.

## Testing Strategy

A dual approach is used: **property-based tests** for input-varying logic and **unit/integration/smoke tests** for everything else.

**Property-based tests** (one test per property above; minimum 100 iterations each; use a standard PBT library — `hypothesis` for Python). Each test is tagged:
`# Feature: pip-installable-package, Property {number}: {property_text}`

- Properties 1–4 (routing/static): build the Flask app with a temporary static dir populated by generated asset/route paths; drive via Flask's test client. Use `hypothesis` strategies for path strings and asset file sets.
- Properties 5–6 (endpoint reachability / drops): parameterize over the preserved and dropped endpoint lists via the test client.
- Properties 7–8 (in-memory state): `hypothesis` strategies generate state field values and small DataFrames; assert round-trip and reset.
- Property 9 (export/import round-trip): generate small datasets, build a tree through the facade, round-trip through `exportTree`/`importTree`, compare normalized JSON.
- Property 10 (port selection): occupy random port sets with real sockets, assert the returned port binds and preferred-when-free holds.

**Unit / example tests:** URL print format with/without token (1.3, 5.5), `--no-browser` suppression (1.4), root returns index.html (2.2), upload accepts a local CSV (6.1), download delivers payload (6.2), no S3/URL special-casing (6.3, 6.4), localhost CORS headers present (9.3).

**Integration tests:** `main()` starts (mocked) Waitress and opens (mocked) browser (1.2); interrupt releases the port (1.6); build helper copies dist and leaves FE source unmodified via before/after hashing (3.1, 3.2); no app-state files written to disk after a run (4.3); Waitress serves without Gunicorn (7.1, 7.2); clean-venv install pulls declared deps (8.3); install rejected on unsupported Python in CI (7.4).

**Smoke tests:** entry point declared (1.1); wheel contains `static/index.html` (3.3); `resolve_static_dir()` exists and has `index.html` (3.4); `create_app()` succeeds with no auth env vars (5.4); `pyproject` metadata fields and `requires-python` constraint (7.3, 8.1, 8.2); excluded deps absent incl. `boto3`/`redis`/`gunicorn`/`Flask-JWT-Extended` (6.5, 8.4); `python -m build` yields wheel + sdist (8.5); `backend/` and `frontend/` source unchanged and all new code under `bosco/` (10.1–10.7).

**Property testing rules:**
- Use `hypothesis`; do not hand-roll property testing.
- Minimum 100 iterations per property test.
- Each property test references its design property via the tag format above.
- Each correctness property is implemented by a single property-based test.

## No-Edit Isolation Constraint (Requirement 10)

This is a hard constraint on the entire implementation:

- All new and adapted code lives under the top-level `bosco/` directory only (Requirement 10.1, 10.7).
- No file under `backend/` or `frontend/` is edited or deleted (Requirements 10.2, 10.3). The Redis session modules, Gunicorn/nginx/systemd configs, and ops scripts in the Existing_App remain in place, untouched.
- Reuse is by **copy + adapt**: `backend/util.py` is copied verbatim into `bosco/src/bosco/util.py`; the relevant parts of `backend/app.py` and the `SessionState` field shapes are reimplemented in the Bosco_Dir; the frontend is built from read-only source and only its `dist/` output is copied in (Requirement 10.4).
- The Build_Process runs from within the Bosco_Dir and the Package is built from the Bosco_Dir (Requirements 10.5, 10.6). The frontend build produces the frontend project's own normal `dist/` output (its standard build artifact location) and no tracked source file under `frontend/` is modified.
- A smoke test asserts the isolation (new files only under `bosco/`, `backend/`/`frontend/` tracked files unchanged) so a regression that edits the Existing_App fails CI.
