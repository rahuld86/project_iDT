# Requirements Document

## Introduction

This feature converts the existing web application (a Flask backend plus a Vite/React/TypeScript frontend) into a single pip-installable Python distribution, modeled after the `pip install jupyterlab` experience. After installation, a user runs one console command, `bosco`, that starts a local server, serves the pre-built frontend assets from the same process, and opens the application in the default web browser.

All new and adapted work for this feature lives in a new, self-contained top-level directory named `bosco/` (the Bosco_Dir). The existing `backend/` and `frontend/` directories are left completely unmodified: no file under those directories is edited or deleted. Existing code is recycled by copying it into the Bosco_Dir and adapting the copies there (for example, copying `backend/util.py`, the relevant parts of `backend/app.py`, and the built frontend assets), while the originals remain untouched. The Bosco_Dir is independent of the existing application and contains the adapted backend code, the bundled frontend assets, the launcher, and the packaging configuration.

The application is repackaged as a purely client-side, single-user local utility. It runs entirely on the user's own machine with no remote server, no authentication, no sessions, and no persistence. The current production topology (Gunicorn behind nginx, a separately managed Redis instance, JWT/auth configuration, cloud storage via boto3/S3, and a local-disk DataFrame store) is designed for multi-user server deployments and is out of scope for the one-command local install. The existing server-deployment files remain in place in the existing application as-is; they are neither deleted nor edited, because all new work is isolated in the Bosco_Dir.

All application state is held in memory for the single local user and is discarded when the process exits; each launch starts fresh. "No sessions" means the session layer from the original `backend/session/` is replaced, within the adapted copy in the Bosco_Dir, with simple in-process in-memory state, not that state handling is removed altogether.

This phase covers requirements only. No application code is modified.

## Glossary

- **Bosco_Dir**: The new, self-contained top-level `bosco/` directory created by this feature. The Bosco_Dir contains the packaged application: the adapted backend code (derived by copying from `backend/`), the bundled pre-built frontend assets, the Launcher, and the packaging configuration. The Bosco_Dir is independent of the existing `backend/` and `frontend/` directories.
- **Existing_App**: The original application consisting of the unmodified `backend/` and `frontend/` directories. The Existing_App is never edited or deleted by this feature; it serves only as a source of code to copy and adapt into the Bosco_Dir.
- **Package**: The pip-installable Python distribution produced by this feature from the Bosco_Dir, distributed under the PyPI name `bosco`, containing the adapted backend code and the pre-built frontend assets.
- **Wheel**: The built distribution artifact (`.whl`) that pip installs.
- **Console_Command**: The command-line entry point installed by the Package, named `bosco`, that a user runs to launch the application.
- **Launcher**: The component in the Bosco_Dir, invoked by the Console_Command, that starts the Local_Server, serves the frontend, and opens the browser.
- **Local_Server**: The HTTP server process started by the Launcher that serves both the backend API and the frontend assets from a single port on the local machine, running a single thread for one local user.
- **Backend**: The adapted Flask application inside the Bosco_Dir, derived by copying and adapting the relevant parts of `backend/app.py` (and supporting modules such as `backend/util.py`). The Backend is the adapted copy in the Bosco_Dir, not the original `backend/app.py`, which remains unmodified.
- **Frontend_Assets**: The pre-built static output of the Vite/React build (HTML, JavaScript, CSS, and other static files), bundled inside the Bosco_Dir as package data. The Frontend_Assets are built from the Existing_App frontend source (`frontend/tree-forge-ui/`) or a copy of that source, without modifying the original frontend project.
- **In_Memory_State**: The in-process, in-memory application state that holds uploaded data and built trees for the single local user. In_Memory_State is created fresh at launch and discarded when the process exits.
- **Build_Process**: The steps executed at packaging time, operating from within the Bosco_Dir, to produce the Frontend_Assets and include them in the Wheel.
- **Supported_Python**: The set of Python interpreter versions the Package supports (3.10, 3.11, 3.12; numpy 1.26.4 does not support 3.13+).
- **Target_Platform**: An operating system the Package is required to support (Windows and macOS). Linux is a non-required bonus target because the chosen Local_Server is cross-platform.

## Resolved Decisions

All prior scope assumptions are resolved (no Redis, no auth, no sessions, no S3/boto3, fully in-memory, Windows/macOS targets, concrete names `bosco`). The previously-open question about the disposition of existing server-deployment files is now resolved: the Existing_App (`backend/` and `frontend/`, including the Gunicorn config, nginx config, systemd unit, deploy/ops scripts, and the Redis-backed session modules under `backend/session/`) is left completely unmodified. Those files are neither deleted nor edited. All new and adapted code is isolated in the Bosco_Dir, which is self-contained and independent of the Existing_App.

## Requirements

### Requirement 1: Single Console Command Launch

**User Story:** As an end user, I want to launch the entire application with the `bosco` command after installing it with pip, so that I can use the app without manual server, proxy, or environment setup.

#### Acceptance Criteria

1. WHEN the Package is installed via pip, THE Package SHALL register the Console_Command `bosco` as an entry point that is runnable from a terminal.
2. WHEN a user runs the Console_Command with no arguments, THE Launcher SHALL start the Local_Server, serve the Frontend_Assets, and open the application in the default web browser.
3. WHEN the Local_Server has started and is ready to accept connections, THE Launcher SHALL print the local URL, including host and port, to standard output.
4. WHERE the user provides a flag to suppress browser launch, THE Launcher SHALL start the Local_Server without opening a browser.
5. IF the default port is already in use, THEN THE Launcher SHALL select an available port and report the selected port to the user.
6. WHEN a user sends an interrupt signal to the Console_Command, THE Launcher SHALL stop the Local_Server and release the bound port before the process exits.

### Requirement 2: Serve Frontend Assets From the Local Server

**User Story:** As an end user, I want the local server process to serve the web interface directly, so that I do not need nginx or a separate static file server.

#### Acceptance Criteria

1. THE Local_Server SHALL serve the Frontend_Assets from the same host and port that serves the Backend API.
2. WHEN a browser requests the application root path, THE Local_Server SHALL return the Frontend_Assets entry HTML document.
3. WHEN a browser requests a static asset path contained in the Frontend_Assets, THE Local_Server SHALL return the corresponding asset with a content type matching the asset's file type.
4. WHEN a browser requests a client-side route path that is not an API path and not a static asset, THE Local_Server SHALL return the Frontend_Assets entry HTML document so that client-side routing resolves the route.
5. WHEN a browser requests a Backend API path, THE Local_Server SHALL route the request to the Backend API handler rather than returning the entry HTML document.
6. IF a requested static asset is not present in the Frontend_Assets, THEN THE Local_Server SHALL return an HTTP 404 response.

### Requirement 3: Bundle Pre-Built Frontend Assets in the Wheel

**User Story:** As a package maintainer, I want the compiled frontend to ship inside the wheel, so that users receive a ready-to-run interface without needing Node.js or a build step.

#### Acceptance Criteria

1. WHEN the Wheel is built, THE Build_Process SHALL produce the Frontend_Assets by building the Vite/React frontend from the Existing_App frontend source (`frontend/tree-forge-ui/`) or a copy of that source placed under the Bosco_Dir.
2. WHEN the Build_Process produces the Frontend_Assets, THE Build_Process SHALL leave the Existing_App frontend source files unmodified.
3. WHEN the Wheel is built, THE Build_Process SHALL include the Frontend_Assets as package data inside the Bosco_Dir in the Wheel.
4. WHEN the Package is installed from the Wheel, THE Package SHALL locate the bundled Frontend_Assets using a path that is valid after installation into a site-packages location.
5. IF the Frontend_Assets are absent at Build_Process time, THEN THE Build_Process SHALL fail with an error that identifies the missing Frontend_Assets.
6. THE Package SHALL serve the Frontend_Assets at runtime without requiring Node.js, npm, or a frontend build toolchain on the user's machine.

### Requirement 4: In-Memory Application State

**User Story:** As an end user, I want the app to keep my uploaded data and built trees in memory while it runs and start fresh each time, so that I do not need to install or manage Redis or any external data store.

#### Acceptance Criteria

1. WHEN the Console_Command is run, THE Backend SHALL hold application state in In_Memory_State without requiring Redis or any external data store.
2. WHEN application state is written while the Local_Server is running, THE Backend SHALL retrieve equivalent state for subsequent reads from In_Memory_State within that running process.
3. WHEN the Local_Server process exits, THE Backend SHALL discard In_Memory_State so that no application state is written to disk.
4. WHEN the Console_Command is run after a previous run has exited, THE Backend SHALL start with empty In_Memory_State.
5. THE Backend SHALL maintain In_Memory_State for a single local user using in-process state in place of the session layer adapted from the original `backend/session/` into the Bosco_Dir.

### Requirement 5: No Authentication for Local Use

**User Story:** As an end user, I want to start using the app immediately without logging in or configuring users and secrets, so that the local tool is ready to use the moment it launches.

#### Acceptance Criteria

1. WHEN a user opens the application served by the Local_Server, THE Backend SHALL grant access to all Backend API paths without requiring authentication.
2. THE Backend SHALL expose the preserved Backend API paths without JWT protection.
3. THE Package SHALL omit the authentication endpoints `/api/login`, `/api/logout`, `/api/user`, and `/api/verify` from the Backend API.
4. THE Package SHALL operate without requiring `AUTH_USERS` or `JWT_SECRET_KEY` configuration.
5. WHEN the Launcher prints the local URL, THE Launcher SHALL print the URL without an access token.

### Requirement 6: Local-Only File Uploads and Downloads

**User Story:** As an end user, I want to upload and download files from my local machine, so that I can work with my own data without any cloud storage.

#### Acceptance Criteria

1. WHEN a user uploads a file, THE Backend SHALL accept the file from the user's local machine.
2. WHEN a user downloads a file, THE Backend SHALL deliver the file to the user's local machine.
3. THE Backend SHALL perform file handling without S3 path handling.
4. THE Backend SHALL perform file handling without downloading from `http://` or `https://` URLs.
5. THE Package SHALL operate without boto3 as a dependency.

### Requirement 7: Cross-Platform Local Server

**User Story:** As an end user on Windows or macOS, I want the `bosco` command to work on my operating system, so that distribution is not limited to Linux servers.

#### Acceptance Criteria

1. THE Launcher SHALL start the Local_Server using a server that runs on each Target_Platform (Windows and macOS).
2. WHEN the Console_Command is run on any Target_Platform, THE Launcher SHALL start the Local_Server without requiring Gunicorn.
3. THE Package SHALL declare Supported_Python versions 3.10, 3.11, and 3.12 in its distribution metadata.
4. IF the Package is installed on a Python interpreter outside the Supported_Python range, THEN pip SHALL reject the installation based on the declared metadata constraint.

### Requirement 8: Dependency and Packaging Metadata

**User Story:** As a package maintainer, I want the distribution to declare its dependencies and metadata correctly, so that pip installs a working application with only the libraries it actually needs.

#### Acceptance Criteria

1. THE Package SHALL define distribution metadata including the name `bosco`, a version, the Supported_Python constraint, and the Console_Command entry point `bosco`.
2. WHEN the Wheel is built, THE Package SHALL declare its runtime dependencies limited to the libraries required by the local application at runtime, including the chosen cross-platform Local_Server.
3. WHEN the Package is installed, pip SHALL install the declared runtime dependencies.
4. THE Package SHALL exclude `redis`, `boto3`, `gunicorn`, and `Flask-JWT-Extended` from its declared dependencies.
5. THE Package SHALL be publishable to PyPI as a Wheel and an accompanying source distribution.

### Requirement 9: Preserve Existing Application Behavior

**User Story:** As an end user, I want the packaged app to behave like the existing web app minus the removed server features, so that core functionality is not lost in the repackaging.

#### Acceptance Criteria

1. WHEN a user interacts with the Backend API through the served Frontend_Assets, THE Backend SHALL expose the same Backend API endpoints available in the existing application except for the removed authentication endpoints.
2. WHEN a user uploads data and builds a tree through the packaged application, THE Backend SHALL produce results equivalent to the existing application for the same input.
3. WHERE cross-origin configuration is needed for requests from the served Frontend_Assets, THE Backend SHALL allow requests originating from the Local_Server on localhost.

### Requirement 10: Isolate All Work in the Self-Contained Bosco Directory

**User Story:** As a maintainer of the existing application, I want all packaging work confined to a new self-contained directory, so that the existing app keeps working unchanged and I can adopt the package without risk to current deployments.

#### Acceptance Criteria

1. THE feature SHALL place all new and adapted code within the Bosco_Dir.
2. THE feature SHALL leave every file under the existing `backend/` directory unmodified and undeleted.
3. THE feature SHALL leave every file under the existing `frontend/` directory unmodified and undeleted.
4. WHERE existing code from the Existing_App is reused, THE feature SHALL reuse the code by copying it into the Bosco_Dir and adapting the copy, while the original file remains unchanged.
5. THE Build_Process SHALL operate entirely from within the Bosco_Dir.
6. THE Package SHALL be built from the Bosco_Dir so that the Package contents originate from the Bosco_Dir rather than from the Existing_App directories.
7. THE Bosco_Dir SHALL contain the adapted Backend code, the bundled Frontend_Assets, the Launcher, and the packaging configuration so that the Bosco_Dir is self-contained and independent of the Existing_App.
