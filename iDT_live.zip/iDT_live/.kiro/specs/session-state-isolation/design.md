# Design Document: Session State Isolation

## Overview

The Decision Tree backend (Flask + pandas) currently keeps all working state in a single
module-level global, `tree_state = TreeState()`, in `project_iDT_2/backend/app.py`. Every
endpoint reads and writes this one object. Because the global lives in process memory and is
not keyed by user, (a) a second user's upload overwrites the first user's DataFrame, and
(b) the deployment is pinned to a single Gunicorn worker (`WEB_CONCURRENCY=1`) since separate
worker processes cannot see each other's memory. This blocks the goal of ~10 concurrent users
each working datasets up to ~500MB on independent trees.

This feature makes each worker process **stateless between requests** by moving
state out of the global and splitting it by size and lifecycle:

- **Small session metadata** (hyperparameters, `badflag`, `regression_flag`, `df_col` mapper,
  `node_master` as JSON, file paths/keys, a pointer to the active dataset) is stored in
  **Redis**, keyed by a session ID derived from the existing JWT identity.
- **Heavy pandas DataFrames** (the up-to-500MB `df`, the processed `df_for_tree`, and the
  per-node `node_datasets`) are serialized to **parquet on disk** (Phase 1) or **S3**
  (Phase 2) and referenced by path/key in the session metadata — never stored in Redis.
- A **per-worker in-memory LRU cache** holds the active DataFrame so a 500MB file is not
  reloaded from disk on every request.
- **Session TTL and cleanup** remove abandoned dataset files so `uploads/` does not grow
  without bound.

The design is phased so that Phase 2 (horizontal scale behind a load balancer) is mostly a
configuration change, not a rewrite: Redis connection and the DataFrame store are both behind
env-configured abstractions.

## Phased Topology

### Phase 1 — Single EC2 instance (implement now)

- One EC2 instance (e.g. `r5.xlarge`, ap-south-1 / Mumbai, ~$195/mo).
- Gunicorn with multiple workers (`WEB_CONCURRENCY > 1`).
- Redis running **on the same instance** (`REDIS_HOST=127.0.0.1`).
- DataFrames stored on **local disk** under a configurable directory.
- Per-worker in-memory DataFrame cache.

Phase 1 fixes per-user isolation and unlocks multiple workers.

### Phase 2 — Horizontal scale (design for, implement later)

- Multiple stateless EC2 instances behind an Application Load Balancer (ALB).
- Redis externalized to **ElastiCache** (`REDIS_HOST` points to the ElastiCache endpoint).
- DataFrames stored on **S3** (shared across instances).
- Optional ALB sticky sessions so a user tends to hit the same instance and benefit from the
  warm per-instance DataFrame cache.

The only code-affecting switches between phases are the `DataFrameStore` implementation
(disk vs S3) and the Redis endpoint — both selected by env vars.

## Architecture

```mermaid
graph TD
    subgraph Client
        FE[React Frontend]
    end

    subgraph EC2["EC2 Instance (Phase 1)"]
        NGINX["nginx (client_max_body_size 600M)"]
        subgraph GUNI["Gunicorn (WEB_CONCURRENCY > 1)"]
            W1[Worker 1 + DF cache]
            W2[Worker 2 + DF cache]
            W3[Worker N + DF cache]
        end
        REDIS[("Redis (same instance)")]
        DISK[("Local disk: df_store/ parquet files")]
    end

    FE -->|JWT + /api/*| NGINX
    NGINX --> W1
    NGINX --> W2
    NGINX --> W3
    W1 -->|session metadata| REDIS
    W2 -->|session metadata| REDIS
    W3 -->|session metadata| REDIS
    W1 -->|heavy DataFrames| DISK
    W2 -->|heavy DataFrames| DISK
    W3 -->|heavy DataFrames| DISK
```

```mermaid
graph TD
    subgraph Phase2["Phase 2 (future)"]
        ALB["Application Load Balancer (optional sticky sessions)"]
        subgraph I1[EC2 Instance A]
            A1[Workers + DF cache]
        end
        subgraph I2[EC2 Instance B]
            B1[Workers + DF cache]
        end
        EC[("ElastiCache Redis")]
        S3[("S3 bucket: DataFrames")]
    end

    ALB --> A1
    ALB --> B1
    A1 --> EC
    B1 --> EC
    A1 --> S3
    B1 --> S3
```

### What lives where

| State field | Size | Store | Rationale |
|---|---|---|---|
| `max_depth`, `min_node_split`, `min_leaf_size`, `max_branches`, `criteria`, `unique_var`, `monotonic`, `regression_flag` | tiny | Redis | config, read on most requests |
| `badflag`, `file_name`, `original_data_source` | tiny | Redis | identifiers / target |
| `df_col` (column→datatype mapper) | small (KB) | Redis (JSON) | small table, needed by tree ops |
| `node_master` (the tree) | small–moderate (KB–MB) | Redis (JSON) | serialized to JSON already by `df_to_json_safe`; the authoritative tree |
| `df_key` / `df_for_tree_key` (pointers) | tiny | Redis | reference into DataFrame store |
| `df` (raw upload, up to 500MB) | heavy | Disk/S3 parquet + worker cache | too big for Redis |
| `df_for_tree` (processed features + `badflag`) | heavy | Disk/S3 parquet + worker cache | derived from `df` |
| `node_datasets` (per-node slices) | heavy | **not persisted** — rederived | computable from `df_for_tree` + `node_master` via `create_node_datasets` |

Key insight from the existing code (`util.create_node_datasets(df_for_tree, mapper, node_master)`):
`node_datasets` is fully derivable from `df_for_tree`, `df_col`, and `node_master`. So we do not
persist `node_datasets`; we rehydrate it on demand and cache it per worker. This keeps the
persisted heavy state down to `df` and `df_for_tree`.

## Request Lifecycle

```mermaid
sequenceDiagram
    participant FE as Frontend
    participant EP as Endpoint (Flask)
    participant SS as SessionStore (Redis)
    participant DS as DataFrameStore (disk/S3)
    participant C as Worker DF Cache

    FE->>EP: POST /api/autoTree (JWT)
    EP->>EP: session_id = session_id_from_jwt()
    EP->>SS: get_session(session_id)
    SS-->>EP: SessionState (metadata, df_for_tree_key, node_master JSON)
    EP->>C: get(df_for_tree_key)
    alt cache miss
        C->>DS: load_dataframe(df_for_tree_key)
        DS-->>C: DataFrame
        C->>C: put(key, df)  (evict LRU if over budget)
    end
    C-->>EP: df_for_tree
    EP->>EP: build_tree(df_for_tree, ...)  -> node_master, node_datasets
    EP->>SS: save_session(session_id, metadata + node_master JSON)
    EP->>SS: touch TTL
    EP-->>FE: node_master JSON
```

General rule for every state-touching endpoint:

1. **Resolve** `session_id` from the JWT.
2. **Load** session metadata from Redis (create empty session on first touch).
3. **Hydrate** any heavy DataFrame needed via the worker cache (cache → store → parquet).
4. **Handle** the request using session-scoped values instead of the global.
5. **Persist** changed metadata (and any newly written DataFrame) back to Redis / the store.
6. **Refresh TTL** so active sessions are kept alive.

**Workspace teardown.** A workspace (the Redis session plus its heavy parquet files) is purged on
exactly two paths, and work is never recovered across them:

- **Logout** (`/api/logout`): synchronously calls `session_manager.purge(session_id)`, deleting the
  Redis session key and every `{session_id}/{name}` parquet file.
- **Session_TTL expiry**: the Redis key expires after `SESSION_TTL_SECONDS`, then
  `SessionCleanup.sweep()` deletes the now-orphaned parquet files.

In both cases a subsequent authenticated request for the same identity resolves the same stable
`session_id`, finds no stored `SessionState`, and starts from a fresh default — there is no
auto-resume of prior work.

---

## Components and Interfaces

### Component 1: `SessionState`

**Purpose**: A plain data container that replaces the `TreeState` global. It holds only the
**small** fields plus **pointers** (keys) to heavy DataFrames in the `DataFrameStore`. It is the
unit serialized to / from Redis.

**Responsibilities**:
- Hold config + identifiers + `df_col` + `node_master` (as JSON-serializable structures).
- Hold `df_key` and `df_for_tree_key` (store references), not the DataFrames themselves.
- Serialize to / from a JSON dict for Redis.

### Component 2: `SessionStore`

**Purpose**: Abstraction over Redis for session metadata. Keyed by `session_id`. Handles TTL.

**Responsibilities**:
- `get_session`, `save_session`, `delete_session`, `touch` (refresh TTL).
- Namespacing of Redis keys (`session:{session_id}`).
- Connection configured from env (`REDIS_HOST`, `REDIS_PORT`), so Phase 2 only changes env.

### Component 3: `DataFrameStore`

**Purpose**: Abstraction over the persistence of heavy DataFrames as parquet. Two
implementations selected by env: `LocalDiskDataFrameStore` (Phase 1) and `S3DataFrameStore`
(Phase 2).

**Responsibilities**:
- `save_dataframe(session_id, name, df) -> key`, `load_dataframe(key) -> df`,
  `delete_dataframe(key)`, `list_keys(session_id)`.
- Serialize with parquet (`df.to_parquet` / `pd.read_parquet`).

### Component 4: `DataFrameCache`

**Purpose**: Per-worker, in-process LRU cache of hydrated DataFrames keyed by store key, with a
total-bytes budget to bound memory.

**Responsibilities**:
- `get(key, loader)` returns cached DF or loads via `loader` and caches it.
- Evict least-recently-used entries when over the byte budget.
- Thread-safe (Gunicorn `sync` workers are single-threaded, but guard anyway).

### Component 5: `SessionManager` (facade used by endpoints)

**Purpose**: Ties the above together and exposes the small surface endpoints actually use.

**Responsibilities**:
- `resolve(session_id)` → load or create `SessionState`.
- `active_df(state)` / `active_df_for_tree(state)` → cache-aware hydration.
- `persist(session_id, state)` → save metadata + refresh TTL.
- `set_dataframe(state, name, df)` → write parquet, set key, update cache.
- `purge(session_id)` → delete the Redis session **and** every DataFrame file for that
  `session_id` from the `DataFrameStore` (used by logout). Idempotent: purging an already-empty
  workspace is a no-op.

### Component 6: `SessionCleanup`

**Purpose**: Remove abandoned DataFrame files whose sessions have expired, so `uploads/` /
`df_store/` do not accumulate 500MB files.

**Responsibilities**:
- Periodically scan the store for keys with no live session in Redis and delete them.
- Run as a lightweight background job (APScheduler thread) and/or on worker boot.

---

## Data Models

### SessionState (persisted to Redis as JSON)

```python
from dataclasses import dataclass, field, asdict
from typing import Optional, Any
import json

@dataclass
class SessionState:
    # --- identifiers / source ---
    file_name: Optional[str] = None
    original_data_source: Optional[str] = None  # original path / URL / s3://

    # --- target & mode ---
    badflag: Optional[str] = None
    regression_flag: int = 0

    # --- hyperparameters ---
    max_depth: int = 5
    min_node_split: int = 500
    min_leaf_size: int = 100
    max_branches: int = 5
    criteria: str = "entropy"
    unique_var: int = 0
    monotonic: int = 0

    # --- small tables (JSON-serializable) ---
    df_col: Optional[list[dict]] = None       # column_name/datatype rows
    node_master: Optional[list[dict]] = None  # the tree (df_to_json_safe output)
    X_col: Optional[list[str]] = None         # feature column names

    # --- pointers to heavy DataFrames in DataFrameStore (NOT the data) ---
    df_key: Optional[str] = None              # raw uploaded df
    df_for_tree_key: Optional[str] = None     # processed features + 'badflag'

    # NOTE: node_datasets is intentionally NOT stored; it is rederived from
    # df_for_tree + df_col + node_master via util.create_node_datasets.

    def to_json(self) -> str:
        return json.dumps(asdict(self))

    @classmethod
    def from_json(cls, raw: str) -> "SessionState":
        return cls(**json.loads(raw))
```

**Validation rules**:
- `df_key` must reference an existing object in the `DataFrameStore` when non-null.
- `df_col` rows use `{'column_name': str, 'datatype': str}` to match existing `keepVar` output.
- `node_master` JSON matches the shape produced by `df_to_json_safe(node_master)` today.

### Redis key layout

```
session:{session_id}            -> JSON string of SessionState   (TTL = SESSION_TTL_SECONDS)
session_index                   -> ZSET session_id -> last_seen epoch (for cleanup scans)
```

### DataFrame store key layout

```
# Local disk (Phase 1):  {DF_STORE_DIR}/{session_id}/{name}.parquet
# S3 (Phase 2):          s3://{DF_S3_BUCKET}/{DF_S3_PREFIX}/{session_id}/{name}.parquet
# key format (opaque to callers): "{session_id}/{name}"
```

---

## Session ID from JWT

The app already issues JWTs with `identity=username` (`create_access_token(identity=username)`)
and reads it with `get_jwt_identity()`. We derive a **stable session id per user** so that all of
a user's requests (across workers) address the same session.

```python
from flask_jwt_extended import get_jwt_identity

def session_id_from_jwt() -> str:
    """Return a stable session id tied to the authenticated principal.

    Preconditions:  called inside a @jwt_required() endpoint (valid JWT present).
    Postconditions: returns a non-empty, deterministic id for the same identity.
    """
    identity = get_jwt_identity()            # e.g. "idfcuser"
    # One workspace per user -> the session id is derived directly from the
    # authenticated user identity. There is exactly one workspace per user.
    return f"user:{identity}"
```

The session id is derived directly from the authenticated user identity, so there is exactly
**one workspace per user**. This directly satisfies "two different users never share a
workspace", and uploading a new dataset replaces that user's single existing workspace. There is
no mechanism for a single user to hold multiple concurrent workspaces/trees.

**No cross-login recovery.** The session id is *stable* per user, but stability does not imply
work is preserved across sessions. Logout and session-TTL expiry both **purge** the user's
workspace — the Redis `session:{session_id}` key and the parquet files under that `session_id` are
deleted. Because the id is derived from identity, logging back in as the same user resolves the
same `session_id`, finds no stored `SessionState`, and therefore starts from a **fresh default
`SessionState`** (see `get_session` postconditions and the "No session yet" row in Error
Handling). There is intentionally **no auto-resume of prior work**: logout and TTL expiry are the
two — and only two — paths that purge a user's workspace and heavy files.

---

## Key Functions with Formal Specifications

### `SessionStore.get_session(session_id)`

```python
def get_session(self, session_id: str) -> SessionState: ...
```

**Preconditions**: `session_id` is a non-empty string; Redis reachable.
**Postconditions**: returns the stored `SessionState` if present; otherwise returns a fresh
default `SessionState` (never raises on "not found"). Does not mutate TTL.

### `SessionStore.save_session(session_id, state)`

```python
def save_session(self, session_id: str, state: SessionState) -> None: ...
```

**Preconditions**: `state` is a valid `SessionState`; Redis reachable.
**Postconditions**: `session:{session_id}` holds `state.to_json()` with expiry
`SESSION_TTL_SECONDS`; `session_index` updated with current epoch. Overwrites any prior value
for that id atomically (single `SET ... EX`).

### `SessionStore.delete_session(session_id)`

```python
def delete_session(self, session_id: str) -> None: ...
```

**Postconditions**: the Redis key is removed and the id dropped from `session_index`. Idempotent
(deleting a missing session is a no-op). Does **not** delete DataFrame files on its own; file
removal is driven either by `SessionCleanup.sweep()` (TTL-expiry path) or by
`SessionManager.purge()` (logout path), which deletes the session **and** its files together.

### `SessionManager.purge(session_id)`

```python
def purge(self, session_id: str) -> None: ...
```

**Preconditions**: `session_id` is a non-empty string; Session_Store and DataFrame_Store reachable.
**Postconditions**: after return, `get_session(session_id)` yields a fresh default `SessionState`
(the `session:{session_id}` key is absent from Redis) **and** `DataFrameStore.list_keys(session_id)`
is empty (every `{session_id}/{name}` parquet file is deleted). Idempotent: purging a
`session_id` that has no session and no files is a no-op. This is the logout path; the TTL-expiry
path reaches the same end state via `SessionCleanup.sweep()`.

### `DataFrameStore.save_dataframe(session_id, name, df)`

```python
def save_dataframe(self, session_id: str, name: str, df: "pd.DataFrame") -> str: ...
```

**Preconditions**: `df` is a non-None DataFrame; `name` in a known set
(`"df"`, `"df_for_tree"`).
**Postconditions**: writes parquet at the key location; returns the opaque `key`
(`"{session_id}/{name}"`). Overwriting the same key replaces prior content atomically
(write temp file then rename for local; `put_object` for S3).

### `DataFrameStore.load_dataframe(key)`

```python
def load_dataframe(self, key: str) -> "pd.DataFrame": ...
```

**Preconditions**: `key` references an object previously written (or raises `KeyError`).
**Postconditions**: returns a DataFrame equal to the one saved under `key`
(`read_parquet(write_parquet(df)) == df`). No mutation of the store.

### `DataFrameCache.get(key, loader)`

```python
def get(self, key: str, loader: "Callable[[], pd.DataFrame]") -> "pd.DataFrame": ...
```

**Preconditions**: `loader()` returns the DataFrame for `key` on a miss.
**Postconditions**: returns the DataFrame for `key`; on miss, `loader` is called exactly once and
the result cached; total cached bytes `<= DF_CACHE_MAX_BYTES` after insertion (LRU eviction).
**Loop invariant** (eviction loop): at each step, evicted keys are the least-recently-used and
`current_bytes` strictly decreases until `current_bytes + incoming <= budget`.

### `SessionCleanup.sweep()`

```python
def sweep(self) -> int: ...
```

**Preconditions**: store and Redis reachable.
**Postconditions**: every DataFrame key whose `session_id` has **no** live `session:{id}` key in
Redis is deleted from the store; returns the count deleted. Live sessions' files are never
touched. Idempotent across runs.

---

## Algorithmic Pseudocode

### Endpoint migration — the general transform

Every endpoint that currently does `tree_state.X` becomes session-scoped. The mechanical rule:

```pascal
ALGORITHM migrate_endpoint(request)
BEGIN
  sid   <- session_id_from_jwt()
  state <- session_manager.resolve(sid)          // Redis GET or fresh default

  // ... read/compute using state.* instead of tree_state.* ...
  // ... hydrate heavy frames via the worker cache when needed ...

  session_manager.persist(sid, state)            // Redis SET + TTL refresh
  RETURN response
END
```

### `upload` (migrated)

```python
@app.route('/api/upload', methods=['POST'])
@jwt_required()
def upload_csv():
    sid = session_id_from_jwt()
    state = session_manager.resolve(sid)

    df, file_path, source = load_uploaded_dataframe(request)  # existing save+read_csv logic

    # Persist the heavy frame to the store; keep only the key in session metadata.
    state.df_key = session_manager.set_dataframe(state, "df", df)   # writes parquet + caches
    state.file_name = file_path
    state.original_data_source = source

    session_manager.persist(sid, state)

    rows, columns = df.shape
    return jsonify({
        'rows': rows, 'columns': columns,
        'sample': df.head().replace({pd.NA: None, pd.NaT: None, np.nan: None}).to_dict('records'),
        'columnsList': df.columns.tolist(),
    })
```

### `setTarget` (migrated)

```python
@app.route('/api/setTarget', methods=['POST'])
@jwt_required()
def setTarget():
    sid = session_id_from_jwt()
    state = session_manager.resolve(sid)

    data = request.get_json() or {}
    target = data.get("target")

    df = session_manager.active_df(state)              # cache -> store -> parquet
    if df is None:
        return handle_error("No data loaded. Please upload a file first.", 400)
    if target not in df.columns:
        return handle_error(f"Target variable '{target}' not found in data", 400)

    state.badflag = target
    state.regression_flag = data.get("regression_flag")
    session_manager.persist(sid, state)
    return jsonify({"message": f"Target variable set to {target}"})
```

### `autoTree` (migrated — rehydrate processed frame, persist tree as JSON)

```python
@app.route('/api/autoTree', methods=['POST'])
@jwt_required()
def autoTree():
    sid = session_id_from_jwt()
    state = session_manager.resolve(sid)

    df_for_tree = session_manager.active_df_for_tree(state)  # hydrate heavy processed frame
    if df_for_tree is None:
        return handle_error("No processed data available. Please complete data setup first.", 400)

    df_col = pd.DataFrame(state.df_col)
    node_master, _node_datasets = build_tree(
        df_for_tree, 'badflag', state.max_depth, state.min_node_split,
        state.min_leaf_size, state.max_branches, df_col,
        state.regression_flag, state.monotonic, state.unique_var,
    )

    # Persist only the small tree (as JSON) to Redis; node_datasets is rederivable.
    state.node_master = df_to_json_safe(node_master)
    session_manager.persist(sid, state)
    return jsonify({"node_master": state.node_master})
```

### `logout` (migrated — now state-mutating: purge session + files)

Logout was previously a no-op (`return jsonify({"message": "Logout successful"})`) because the JWT
is stateless. With externalized state it becomes **state-mutating**: it resolves the session id
from the JWT and purges both the Redis session key and the parquet files under that session id,
then returns the **same** success response as before. This implements the "no work recovered across
logout" policy — logging back in as the same user starts from a fresh default `SessionState`.

```python
@app.route('/api/logout', methods=['POST'])
@jwt_required()
def logout():
    """Logout endpoint - purges the user's session + heavy DataFrame files, then
    returns the existing success message. The JWT itself remains stateless."""
    sid = session_id_from_jwt()
    # Deletes Redis session:{sid} AND every {sid}/{name} parquet file; idempotent
    # no-op if the workspace is already empty (nothing to recover across logout).
    session_manager.purge(sid)
    return jsonify({"message": "Logout successful"})   # response contract unchanged
```

### `SessionManager.active_df_for_tree` (hydration with rederivation)

```pascal
ALGORITHM active_df_for_tree(state)
INPUT:  state (SessionState)
OUTPUT: df_for_tree (DataFrame) or NULL
BEGIN
  IF state.df_for_tree_key = NULL THEN
    RETURN NULL
  END IF
  // Worker cache first; load parquet on miss.
  RETURN cache.get(state.df_for_tree_key,
                   loader = () => df_store.load_dataframe(state.df_for_tree_key))
END
```

```pascal
ALGORITHM node_datasets_for(state)      // used by endpoints needing per-node slices
INPUT:  state
OUTPUT: node_datasets (DataFrame)
BEGIN
  df_for_tree <- active_df_for_tree(state)
  ASSERT df_for_tree != NULL
  mapper      <- DataFrame(state.df_col)
  node_master <- DataFrame(state.node_master)
  _nm, node_datasets <- create_node_datasets(df_for_tree, mapper, node_master)  // existing util
  RETURN node_datasets                   // may be cached per (session, node_master-hash)
END
```

### `DataFrameCache.get` (LRU with byte budget)

```pascal
ALGORITHM cache_get(key, loader)
BEGIN
  IF key IN entries THEN
    mark key most-recently-used
    RETURN entries[key].df
  END IF

  df   <- loader()
  size <- estimate_bytes(df)                 // df.memory_usage(deep=True).sum()

  // Eviction loop
  WHILE current_bytes + size > DF_CACHE_MAX_BYTES AND entries NOT EMPTY DO
    victim <- least-recently-used key
    current_bytes <- current_bytes - entries[victim].size
    REMOVE victim
  END WHILE

  entries[key] <- {df, size}
  current_bytes <- current_bytes + size
  mark key most-recently-used
  RETURN df
END
```

**Loop invariant**: after each iteration, `current_bytes` equals the summed sizes of remaining
entries and is strictly smaller than before; the loop terminates because entries is finite.

### `SessionCleanup.sweep` (abandoned file removal)

```pascal
ALGORITHM sweep()
BEGIN
  deleted <- 0
  FOR each key IN df_store.all_keys() DO          // "{session_id}/{name}"
    sid <- session_id_of(key)
    IF NOT redis.exists("session:" + sid) THEN     // session expired or deleted
      df_store.delete_dataframe(key)
      deleted <- deleted + 1
    END IF
  END FOR
  RETURN deleted
END
```

---

## Configuration / Environment Additions

Additions to `backend/env.example` (and documented in `DEPLOYMENT.md`):

```env
# --- Redis (session metadata store) ---
# Phase 1: same-instance Redis. Phase 2: point to ElastiCache endpoint (no code change).
REDIS_HOST=127.0.0.1
REDIS_PORT=6379
REDIS_DB=0
# REDIS_PASSWORD=        # optional

# --- Session lifecycle ---
SESSION_TTL_SECONDS=86400          # abandoned sessions expire after 24h
SESSION_CLEANUP_INTERVAL=3600      # background sweep cadence (seconds)

# --- DataFrame store ---
DF_STORE_BACKEND=disk              # 'disk' (Phase 1) or 's3' (Phase 2)
DF_STORE_DIR=/home/ubuntu/project_iDT_2/backend/df_store   # for disk backend
# DF_S3_BUCKET=                    # for s3 backend (Phase 2)
# DF_S3_PREFIX=dataframes

# --- Per-worker DataFrame cache ---
DF_CACHE_MAX_BYTES=2147483648      # 2GB per worker cache budget (tune to instance RAM)

# --- Raised limits ---
MAX_UPLOAD_SIZE=629145600          # ~600MB (was 104857600 / 100MB)

# --- Gunicorn: multiple workers now safe (state is externalized) ---
WEB_CONCURRENCY=4
```

Corresponding infra change (in `DEPLOYMENT.md` nginx block and `nginx.conf.example`):

```nginx
# was: client_max_body_size 100M;
client_max_body_size 600M;
```

And `gunicorn_config.py` comment/worker note updated: state is now in Redis + the DataFrame
store, so `workers` may exceed 1 safely (`WEB_CONCURRENCY=4` default).

---

## Endpoint Migration Inventory

Every endpoint that references `tree_state.` must be migrated to the
`resolve → use state → persist` pattern. Endpoints are JWT-protected already, so
`session_id_from_jwt()` is always available.

| Endpoint | State read | State written | Heavy frame needed |
|---|---|---|---|
| `/api/upload` | — | `df_key`, `file_name`, `original_data_source` | writes `df` |
| `/api/importTree` | — | all config, `df_col`, `node_master`, `badflag`, `df_key` | writes `df` |
| `/api/getImportDiagnostics` | config/`node_master` | — | — |
| `/api/setTarget` | `df` (cols) | `badflag`, `regression_flag` | reads `df` |
| `/api/getRegressionFlag` | `regression_flag` | — | — |
| `/api/getTypes` | `df`, `badflag` | — | reads `df` |
| `/api/keepVar` | `df`, `badflag` | `df_col`, writes `df_for_tree` | reads `df`, writes `df_for_tree` |
| `/api/defineHP` | — | all hyperparameters | — |
| `/api/initTree` | `df_for_tree`, HPs | `X_col`, `node_master` | reads `df_for_tree` |
| `/api/autoTree` | `df_for_tree`, HPs, `df_col` | `node_master` | reads `df_for_tree` |
| `/api/delSubTree` | `node_master`, `df_for_tree` | `node_master` | rederive `node_datasets` |
| `/api/autoTrainSubTree` | `node_master`, `df_for_tree`, `X_col`, `df_col`, HPs | `node_master` | rederive `node_datasets` |
| `/api/findSplit` | `node_master`, `df_for_tree` | possibly `node_master` | rederive `node_datasets` |
| `/api/findVar` | `node_master`, `df_for_tree` | — | rederive `node_datasets` |
| `/api/bestSplit` | `node_master`, `df_for_tree` | — | rederive `node_datasets` |
| `/api/evalSplit` | `node_master`, `df_for_tree` | — | rederive `node_datasets` |
| `/api/addNode` | `node_master`, `df_for_tree` | `node_master` | rederive `node_datasets` |
| `/api/copyNode` | `node_master` | `node_master` | — |
| `/api/labelNode` | `node_master` | `node_master` | — |
| `/api/exportTree` | all config, `df_col`, `node_master` | — | — |
| `/api/downloadTree` | all config, `df_col`, `node_master` | — | — |
| `/api/getTreeData` | `node_master` | — | — |
| `/api/uploadFileToS3` | — (uses request body only) | — | — |
| `/api/logout` | — | **deletes** session + all DataFrame files (`purge`) | deletes `df`, `df_for_tree` |
| `/api/login`, `/api/user`, `/api/verify`, `/api/test`, `/api/health` | none (no migration) | — | — |

Notes:
- `node_datasets` is never read from persisted state; endpoints that need it call
  `node_datasets_for(state)` (rederive via `create_node_datasets`, optionally cached per worker
  keyed by a hash of `node_master`).
- The several `tree_state.df = pd.read_csv(...)` sites inside `importTree`/`upload` all collapse
  into a single "load then `set_dataframe`" step.
- `/api/logout` is now a **state-mutating** endpoint: it resolves `session_id_from_jwt()` and calls
  `session_manager.purge(sid)` to delete the Redis session key **and** the parquet files under that
  `session_id`, while keeping its response contract unchanged (`{"message": "Logout successful"}`).
  This is one of the two workspace-purge paths; the other is `SessionCleanup.sweep()` on Session_TTL
  expiry.

---

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a
system — essentially, a formal statement about what the system should do. Properties serve as the
bridge between human-readable specifications and machine-verifiable correctness guarantees.*

These are verified with a property-based test library such as **Hypothesis** for the store/cache
invariants, plus integration tests for the cross-worker and backward-compatibility behaviors.

### Property 1: Deterministic, distinct session id per user

*For any* authenticated identity, `session_id_from_jwt()` returns `"user:" + identity`, and *for
any* two distinct identities the derived session ids are distinct; repeated resolution for the same
identity always yields the same single session id (stable across logout and TTL-expiry — the id is
preserved even though the workspace it addresses is purged).

**Validates: Requirements 1.1, 1.2, 2.1, 2.3, 2.4**

### Property 2: Session metadata isolation (no cross-talk)

*For any* two distinct session ids `s1 ≠ s2` and any values `a`, `b`, after `save_session(s1, a)`
and `save_session(s2, b)` in any order, `get_session(s1) == a` and `get_session(s2) == b`; a write
to one session never changes the state read for another.

**Validates: Requirements 1.3, 1.4**

### Property 3: Heavy DataFrame isolation across sessions

*For any* two distinct session ids, saving or overwriting a DataFrame under one session leaves the
DataFrame referenced by the other session unchanged (`load_dataframe(df_key(s1))` is unaffected by
any operation on `s2`).

**Validates: Requirements 1.5**

### Property 4: Upload replaces the single workspace

*For any* session and any two datasets `df1`, `df2`, uploading `df1` then `df2` results in the
session's active DataFrame being equivalent to `df2` and the `df_key` referencing `df2`.

**Validates: Requirements 2.2**

### Property 5: Cross-worker persistence

*For any* session id and state, metadata saved by one `SessionManager`/`SessionStore` instance is
read back equal by a second instance sharing the same Redis, and a DataFrame saved by one
`DataFrameStore` instance is loaded back equivalent by a second instance sharing the same
directory/bucket.

**Validates: Requirements 3.2, 3.3**

### Property 6: DataFrame round-trip fidelity with overwrite and key layout

*For any* DataFrame `df` and `name` in the known set, `save_dataframe(session_id, name, df)` returns
the key `"{session_id}/{name}"`, writes parquet at the namespaced location, and
`load_dataframe(key)` returns a DataFrame equal to `df` in values, columns, and dtypes; writing a
second DataFrame under the same key yields that second DataFrame on load.

**Validates: Requirements 4.1, 4.3, 4.4, 4.6**

### Property 7: SessionState JSON round-trip

*For any* `SessionState`, `SessionState.from_json(state.to_json())` produces a `SessionState` equal
to the original, preserving config, target flag, `df_col`, `node_master`, feature columns, and
DataFrame keys.

**Validates: Requirements 5.2**

### Property 8: node_datasets rederivation equivalence

*For any* `df_for_tree`, column mapper (`df_col`), and `node_master`, `node_datasets_for(state)`
produces data equivalent to `create_node_datasets(df_for_tree, mapper, node_master)` — i.e. the
same slices the former in-memory `tree_state.node_datasets` would have held.

**Validates: Requirements 5.4**

### Property 9: Cache transparency and single load

*For any* key and loader, `cache.get(key, loader)` returns the same DataFrame as a direct
`store.load_dataframe(key)`, and `loader` is invoked at most once per key between evictions (a hit
never re-invokes the loader).

**Validates: Requirements 6.1, 6.2**

### Property 10: Cache budget bound with LRU eviction

*For any* sequence of `get` calls, total cached bytes stay `<= DF_CACHE_MAX_BYTES` after each call,
and when insertion would exceed the budget the evicted entries are the least-recently-used ones.

**Validates: Requirements 6.3, 6.4**

### Property 11: Cleanup safety (delete iff orphaned)

*For any* set of DataFrame keys, `sweep()` deletes a key **if and only if** its `session_id` has no
live `session:{id}` key in Redis; files of live sessions are never deleted and expired sessions
leave no orphan files after a sweep. A session made keyless by Session_TTL expiry therefore has its
abandoned Heavy DataFrame files removed on the next sweep.

**Validates: Requirements 7.3, 7.4, 12.5**

### Property 12: TTL refresh keeps active sessions alive

*For any* sequence of state-touching requests spaced within `SESSION_TTL_SECONDS`, each request
refreshes the session TTL so the session remains available and is not expired mid-work.

**Validates: Requirements 7.1, 7.2**

### Property 13: Externalized build equivalence (backward compatibility)

*For any* dataset and configuration, performing the upload → set target → set types → build-tree
sequence against the session-backed `SessionManager` produces the same `node_master` outputs as the
former in-memory `tree_state` flow for the same inputs.

**Validates: Requirements 10.3**

### Property 14: Fresh default on missing session

*For any* session id that has no stored state (a brand-new user, or one whose session was removed by
logout or Session_TTL expiry), `get_session` returns a fresh default `SessionState` without raising,
so the request is handled as a new workspace with no recovered prior work.

**Validates: Requirements 11.4**

### Property 15: Logout purges session and files, idempotently

*For any* session id and *any* set of Heavy DataFrames previously saved under it (including the empty
set), after `session_manager.purge(session_id)` the `session:{session_id}` key is absent from the
Session_Store **and** `DataFrameStore.list_keys(session_id)` is empty; applying `purge` again (or to a
never-populated session) changes nothing and raises nothing (idempotent no-op).

**Validates: Requirements 12.1, 12.3**

### Property 16: No work recovered after logout or TTL expiry

*For any* populated `SessionState` persisted under a session id, after that workspace is purged (by
logout `purge`, or by the session key expiring so a sweep removes its files), resolving the same
session id for the same identity yields a `SessionState` equal to a brand-new default — no `df_key`,
no `node_master`, default hyperparameters — i.e. no prior work is recovered.

**Validates: Requirements 2.4, 11.4, 12.4**

---

## Error Handling

| Scenario | Condition | Response | Recovery |
|---|---|---|---|
| Redis unavailable | connection refused / timeout | 503 "Session store unavailable" | retry with backoff; health check surfaces Redis status |
| Missing DataFrame key | session references a key deleted by cleanup | 400 "Session data expired, please re-upload" | prompt re-upload; clear stale keys from session |
| Parquet read/write failure | disk full / S3 error | 500 with context | surface disk/S3 error; cleanup frees space |
| No session yet | first request has no stored state (new user, or after logout / TTL-expiry purge) | treat as fresh default `SessionState` (no recovered work) | normal flow (e.g. "No data loaded" where appropriate) |
| Logout purge | user calls `/api/logout` | delete Redis session + all `{sid}/*` parquet files via `purge`; return `{"message": "Logout successful"}` | next request for the same identity starts a fresh default workspace |
| TTL expiry purge | session key expires after `SESSION_TTL_SECONDS` | `SessionCleanup.sweep()` removes the now-orphaned parquet files | next request for the same identity starts a fresh default workspace |
| Oversized upload | body > `MAX_UPLOAD_SIZE` | 413 Payload Too Large | raise limit config / nginx `client_max_body_size` |
| Cache memory pressure | DF larger than budget | load without caching (one-shot), log warning | tune `DF_CACHE_MAX_BYTES` or instance size |

## Testing Strategy

### Unit testing
- `SessionState` JSON round-trip (serialize/deserialize equals original).
- `DataFrameStore` (disk and a mocked S3 via `moto`): save/load/delete, overwrite atomicity.
- `DataFrameCache`: hit/miss, LRU eviction order, byte-budget enforcement.
- `session_id_from_jwt`: deterministic id per identity.
- `/api/logout` contract (example-based): with a valid JWT the endpoint returns exactly
  `{"message": "Logout successful"}` with the same status code as before the migration, while
  `purge` is invoked for the resolved session id (Requirement 12.2).

### Property-based testing
- **Library**: Hypothesis.
- Properties 1, 2, 3, 6, 7, 9, 10, 15, 16 above expressed as Hypothesis properties over random
  session ids, random small DataFrames, random `SessionState` values, and random operation
  sequences (Property 15 generators include the empty-workspace and purge-twice cases for
  idempotence; Property 16 persists a random populated state then purges and re-resolves).

### Integration testing
- Spin up a real Redis (or `fakeredis`) + a temp `DF_STORE_DIR`.
- Two simulated users through the real Flask test client: upload different CSVs, set different
  targets/HPs, build trees; assert each user only ever sees their own data (Properties 2, 3).
- Multi-worker simulation: write via one `SessionManager` instance, read via a second instance
  sharing the same Redis + store (Property 5).
- Backward compatibility: run the full upload → target → types → build sequence and compare tree
  outputs against the legacy in-memory flow (Property 13).
- Cleanup: create a session, let it expire (short TTL), run `sweep()`, assert its parquet files
  are gone and live sessions' files remain (Property 11).
- Logout purge: upload a CSV + build a tree for a user, call `/api/logout`, assert the Redis session
  key and the user's parquet files are gone, then issue a subsequent authenticated request for the
  same identity and assert it is treated as a fresh default workspace with no recovered work
  (Properties 15, 16).

## Performance Considerations

- **Avoid reloading 500MB per request**: the per-worker cache serves the hot `df_for_tree`; a
  cache hit skips parquet I/O entirely.
- **Parquet over CSV/pickle**: columnar, compressed, fast to (de)serialize; smaller on disk than
  the raw CSV for typical tabular data.
- **node_datasets rederivation cost**: for endpoints that need per-node slices, cache the derived
  `node_datasets` per worker keyed by a hash of `node_master` to avoid recomputing each call.
- **Memory budgeting**: `DF_CACHE_MAX_BYTES` × `WEB_CONCURRENCY` must fit instance RAM alongside
  working copies during tree building. For ~10 users × up to 500MB with 4 workers on an
  `r5.xlarge` (32GB), size the cache conservatively (e.g. 2GB/worker) and rely on the store for
  cold data.
- **Redis payload stays small**: only JSON metadata + `node_master` + `df_col` live in Redis, so
  Redis memory is modest and network transfer per request is small.

## Security Considerations

- Session id is derived from the authenticated JWT identity; an unauthenticated request can never
  resolve another user's session (endpoints remain `@jwt_required()`).
- DataFrame store paths are namespaced by `session_id`; keys are server-constructed from the JWT
  identity + a fixed name set, never from raw client input, preventing path traversal across
  sessions.
- Redis should be bound to localhost in Phase 1 (or secured with `REDIS_PASSWORD` / VPC + SG in
  Phase 2 ElastiCache); it is not exposed publicly.
- Uploaded files and parquet artifacts inherit the existing restricted `uploads/` permissions
  (`chmod 700`); `df_store/` should be similarly restricted.

## Dependencies

- `redis` (Python client) — session metadata store.
- `pyarrow` (or `fastparquet`) — parquet engine for `to_parquet` / `read_parquet`.
- `boto3` — already present; used by the Phase 2 `S3DataFrameStore`.
- `APScheduler` (or a cron/systemd timer) — periodic `SessionCleanup.sweep()`.
- `hypothesis`, `fakeredis`, `moto` — test-time only.
- Infra: a Redis server (same-instance in Phase 1; ElastiCache in Phase 2).
