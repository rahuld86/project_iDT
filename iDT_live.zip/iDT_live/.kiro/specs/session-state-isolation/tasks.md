# Implementation Plan: Session State Isolation

## Overview

This plan externalizes the single `tree_state` global in `project_iDT_2/backend/app.py` into a
Redis-backed `SessionStore` (small metadata, tree-as-JSON, DataFrame pointers) plus a
`DataFrameStore` (parquet on disk in Phase 1, S3 stub for Phase 2) for heavy DataFrames, fronted by
a per-worker `DataFrameCache` and a `SessionManager` facade. It then migrates every state-touching
`/api/*` endpoint to the `resolve → use state → persist` pattern, wires logout to purge the
workspace, adds TTL-based background cleanup, raises upload limits, and makes multiple Gunicorn
workers safe.

The work is ordered foundational-components-first (data container → stores → cache → facade →
helpers → cleanup), then wiring into `app.py`, then endpoint migration in logical batches, then
error handling and config/infra, closing with backward-compatibility and multi-worker integration
tests. Property-based tests (Hypothesis) are placed next to the component they validate so
invariants are caught early. Language: **Python** (matches the existing Flask/pandas backend).

All new code lives under `project_iDT_2/backend/` (suggested new package `session/`), with tests
under `project_iDT_2/backend/tests/`.

## Tasks

- [x] 1. Add dependencies and test scaffolding
  - Add runtime deps to `project_iDT_2/backend/requirements.txt`: `redis`, `pyarrow`, `APScheduler`
    (`boto3` already present for the Phase 2 S3 store).
  - Add test-only deps: `hypothesis`, `fakeredis`, `moto` (and `pytest` if not already configured).
  - Create the `project_iDT_2/backend/tests/` directory with an empty `__init__.py` / conftest
    placeholder and confirm the test runner (pytest) discovers it.
  - _Requirements: 9.1, 4.1, 7.5_

- [x] 2. Implement SessionState data container
  - [x] 2.1 Create `SessionState` dataclass
    - Add `session/state.py` with the `SessionState` dataclass holding config
      (`max_depth`, `min_node_split`, `min_leaf_size`, `max_branches`, `criteria`, `unique_var`,
      `monotonic`, `regression_flag`), identifiers (`file_name`, `original_data_source`, `badflag`),
      small tables (`df_col`, `node_master`, `X_col`), and heavy-frame pointers (`df_key`,
      `df_for_tree_key`) — never the DataFrames themselves.
    - Implement `to_json()` (via `asdict` + `json.dumps`) and `from_json(raw)` classmethod.
    - _Requirements: 5.1, 4.2_
  - [x] 2.2 Write property test for SessionState JSON round-trip
    - **Property 7: SessionState JSON round-trip**
    - **Validates: Requirements 5.2**
    - Hypothesis strategy over random `SessionState` values; assert
      `SessionState.from_json(s.to_json()) == s` preserving config, `badflag`, `df_col`,
      `node_master`, `X_col`, and DataFrame keys.

- [x] 3. Implement SessionStore (Redis)
  - [x] 3.1 Create `SessionStore` with env-driven connection and TTL
    - Add `session/store_redis.py` building a Redis client from `REDIS_HOST`, `REDIS_PORT`,
      `REDIS_DB`, and optional `REDIS_PASSWORD`.
    - Implement `get_session(session_id)` (return stored `SessionState` or a fresh default, never
      raise on miss, do not mutate TTL), `save_session(session_id, state)` (single `SET ... EX`
      with `SESSION_TTL_SECONDS`, update `session_index` ZSET), `delete_session(session_id)`
      (idempotent remove + drop from index), and `touch(session_id)` (refresh TTL).
    - Use Redis key layout `session:{session_id}` and `session_index`.
    - _Requirements: 5.1, 7.1, 7.2, 9.1, 9.2, 9.3, 11.4_
  - [x] 3.2 Write property test for session metadata isolation
    - **Property 2: Session metadata isolation (no cross-talk)**
    - **Validates: Requirements 1.3, 1.4**
    - Use `fakeredis`; for distinct `s1 ≠ s2`, after `save_session(s1,a)`/`save_session(s2,b)` in
      any order assert `get_session(s1)==a` and `get_session(s2)==b`.
  - [x] 3.3 Write property test for fresh default on missing session
    - **Property 14: Fresh default on missing session**
    - **Validates: Requirements 11.4**
    - For any session id with no stored state, assert `get_session` returns a default
      `SessionState` without raising.

- [ ] 4. Implement DataFrameStore abstraction and local disk backend
  - [x] 4.1 Define the `DataFrameStore` interface and `LocalDiskDataFrameStore`
    - Add `session/dataframe_store.py` with an abstract `DataFrameStore`
      (`save_dataframe(session_id, name, df) -> key`, `load_dataframe(key) -> df`,
      `delete_dataframe(key)`, `list_keys(session_id)`, `all_keys()`).
    - Implement `LocalDiskDataFrameStore` under `DF_STORE_DIR`, writing
      `{DF_STORE_DIR}/{session_id}/{name}.parquet`, returning opaque key `"{session_id}/{name}"`.
    - Use parquet (`df.to_parquet` / `pd.read_parquet`); overwrite atomically (write temp file then
      rename); `load_dataframe` raises `KeyError` on a missing key.
    - _Requirements: 4.1, 4.3, 4.4, 4.6_
  - [x] 4.2 Write property test for DataFrame round-trip, overwrite, and key layout
    - **Property 6: DataFrame round-trip fidelity with overwrite and key layout**
    - **Validates: Requirements 4.1, 4.3, 4.4, 4.6**
    - Hypothesis over small random DataFrames and `name` in `{"df","df_for_tree"}`; assert returned
      key is `"{session_id}/{name}"`, round-trip equality (values/columns/dtypes), and that
      rewriting the same key yields the second DataFrame.
  - [x] 4.3 Write property test for heavy DataFrame isolation across sessions
    - **Property 3: Heavy DataFrame isolation across sessions**
    - **Validates: Requirements 1.5**
    - For distinct session ids, assert operations on `s2` never change
      `load_dataframe(df_key(s1))`.
  - [ ] 4.4 Implement `S3DataFrameStore` (Phase 2) — optional
    - Implement the S3-backed store writing/reading parquet at
      `s3://{DF_S3_BUCKET}/{DF_S3_PREFIX}/{session_id}/{name}.parquet`, selected when
      `DF_STORE_BACKEND=s3`.
    - If implemented, test with `moto`; otherwise leave a clearly marked Phase-2 stub that raises
      `NotImplementedError` and document the switch via `DF_STORE_BACKEND`.
    - _Requirements: 4.5_

- [x] 5. Implement per-worker DataFrameCache
  - [x] 5.1 Create `DataFrameCache` (LRU + byte budget)
    - Add `session/cache.py` with `get(key, loader)`: return cached DF on hit; on miss call
      `loader()` exactly once, estimate size via `df.memory_usage(deep=True).sum()`, evict LRU
      entries while `current_bytes + size > DF_CACHE_MAX_BYTES`, then insert and mark MRU.
    - When a single DF exceeds the budget, return it without caching (over-budget passthrough).
    - Guard with a lock for thread safety.
    - _Requirements: 6.1, 6.2, 6.3, 6.4, 6.5_
  - [x] 5.2 Write property test for cache transparency and single load
    - **Property 9: Cache transparency and single load**
    - **Validates: Requirements 6.1, 6.2**
    - Assert `cache.get(key, loader)` equals a direct store load and that a counting `loader` is
      invoked at most once per key between evictions.
  - [x] 5.3 Write property test for cache budget bound with LRU eviction
    - **Property 10: Cache budget bound with LRU eviction**
    - **Validates: Requirements 6.3, 6.4**
    - Over random `get` sequences assert total cached bytes stay `<= DF_CACHE_MAX_BYTES` after each
      call and evicted entries are the least-recently-used.

- [ ] 6. Implement SessionManager facade
  - [x] 6.1 Create `SessionManager` wiring store + DataFrame store + cache
    - Add `session/manager.py` with `resolve(session_id)` (load or fresh default),
      `active_df(state)` / `active_df_for_tree(state)` (cache-aware hydration; `None` when key is
      unset), `set_dataframe(state, name, df)` (write parquet, set key, update cache),
      `persist(session_id, state)` (save metadata + refresh TTL).
    - Implement `purge(session_id)`: delete the Redis session **and** every
      `{session_id}/{name}` file via `DataFrameStore.list_keys`; idempotent no-op on empty.
    - Implement `node_datasets_for(state)`: hydrate `df_for_tree`, build mapper/`node_master`
      DataFrames, and call existing `util.create_node_datasets` to rederive node slices.
    - _Requirements: 2.2, 2.4, 3.1, 3.2, 3.3, 5.3, 5.4, 7.2, 12.1_
  - [x] 6.2 Write property test for node_datasets rederivation equivalence
    - **Property 8: node_datasets rederivation equivalence**
    - **Validates: Requirements 5.4**
    - Assert `node_datasets_for(state)` equals
      `create_node_datasets(df_for_tree, mapper, node_master)` for the same inputs.
  - [x] 6.3 Write property test for logout purge idempotence
    - **Property 15: Logout purges session and files, idempotently**
    - **Validates: Requirements 12.1, 12.3**
    - Include empty-workspace and purge-twice cases; after `purge`, assert Redis key absent and
      `list_keys(session_id)` empty; re-purge changes/raises nothing.
  - [x] 6.4 Write property test for no work recovered after purge
    - **Property 16: No work recovered after logout or TTL expiry**
    - **Validates: Requirements 2.4, 11.4, 12.4**
    - Persist a populated state, purge, re-resolve same id; assert result equals a brand-new
      default (no `df_key`, no `node_master`, default hyperparameters).
  - [ ] 6.5 Add per-worker `node_datasets` memoization — optional
    - Cache the rederived `node_datasets` per worker keyed by a hash of `node_master` to avoid
      recomputation across calls within a session.
    - _Requirements: 5.4_

- [x] 7. Implement session_id_from_jwt helper
  - [x] 7.1 Create `session_id_from_jwt()`
    - Add `session/identity.py` with `session_id_from_jwt()` returning `f"user:{get_jwt_identity()}"`
      (called inside `@jwt_required()` endpoints).
    - _Requirements: 1.1, 1.2, 2.1, 2.3_
  - [x] 7.2 Write property test for deterministic, distinct session id
    - **Property 1: Deterministic, distinct session id per user**
    - **Validates: Requirements 1.1, 1.2, 2.1, 2.3, 2.4**
    - For any identity assert id is `"user:"+identity`; distinct identities give distinct ids;
      repeated resolution is stable.

- [x] 8. Implement SessionCleanup and background scheduler
  - [x] 8.1 Create `SessionCleanup.sweep()`
    - Add `session/cleanup.py` iterating `DataFrameStore.all_keys()`; delete each key whose
      `session_id` has no live `session:{id}` key in Redis; return count deleted; never touch live
      sessions' files; idempotent across runs.
    - _Requirements: 7.3, 7.4, 12.5_
  - [x] 8.2 Wire the background scheduler
    - Start an APScheduler background job that runs `sweep()` every `SESSION_CLEANUP_INTERVAL`
      seconds on app startup.
    - _Requirements: 7.5_
  - [x] 8.3 Write property test for cleanup safety
    - **Property 11: Cleanup safety (delete iff orphaned)**
    - **Validates: Requirements 7.3, 7.4, 12.5**
    - Over random sets of keys/sessions (fakeredis + temp dir), assert `sweep()` deletes a key iff
      its session id has no live Redis key; live files survive; no orphans remain.

- [x] 9. Checkpoint - component layer complete
  - Ensure all tests pass, ask the user if questions arise.

- [x] 10. Wire SessionManager into app.py and remove the global
  - Instantiate `SessionStore`, `DataFrameStore` (disk/S3 by `DF_STORE_BACKEND`), `DataFrameCache`,
    and `SessionManager` from env at module import in `project_iDT_2/backend/app.py`.
  - Remove the module-level `tree_state = TreeState()` global and replace its construction with the
    `SessionManager` instance (keep `TreeState` only if still referenced elsewhere, otherwise
    remove).
  - Start the `SessionCleanup` scheduler (task 8.2) during app initialization.
  - _Requirements: 3.1, 3.4_

- [x] 11. Migrate data-setup endpoints
  - [x] 11.1 Migrate `/api/upload`
    - Resolve session, load uploaded DataFrame (existing save + `read_csv`), persist heavy frame via
      `set_dataframe(state, "df", df)`, set `file_name`/`original_data_source`, `persist`, and
      return the unchanged response (rows/columns/sample/columnsList).
    - _Requirements: 2.2, 3.1, 10.1, 10.2_
  - [x] 11.2 Migrate `/api/setTarget` and `/api/getRegressionFlag`
    - `setTarget`: resolve, hydrate `df` via `active_df`, validate target in columns, set `badflag`
      and `regression_flag`, persist. `getRegressionFlag`: resolve and return `state.regression_flag`.
    - _Requirements: 3.1, 10.1, 10.2_
  - [x] 11.3 Migrate `/api/getTypes` and `/api/keepVar`
    - `getTypes`: resolve, hydrate `df`, compute types using `badflag`. `keepVar`: resolve, hydrate
      `df`, write `df_col`, build and `set_dataframe(state, "df_for_tree", df_for_tree)`, persist.
    - _Requirements: 3.1, 3.3, 10.1, 10.2_
  - [x] 11.4 Migrate `/api/defineHP`
    - Resolve, write all hyperparameters to state, persist.
    - _Requirements: 3.1, 10.1, 10.2_
  - [x] 11.5 Write unit tests for data-setup endpoints
    - Test request/response contracts and that `df_key`/`df_for_tree_key`/metadata are persisted.
    - _Requirements: 10.1, 10.2_

- [ ] 12. Migrate tree-building endpoints
  - [x] 12.1 Migrate `/api/initTree` and `/api/autoTree`
    - Resolve, hydrate `df_for_tree` via `active_df_for_tree`, build tree using session HPs +
      `df_col`, persist `node_master` (and `X_col` for `initTree`) as JSON; return unchanged shape.
    - _Requirements: 3.1, 5.3, 10.1, 10.2, 10.3_
  - [ ] 12.2 Migrate node-slice endpoints: `/api/delSubTree`, `/api/autoTrainSubTree`,
        `/api/findSplit`, `/api/findVar`, `/api/bestSplit`, `/api/evalSplit`, `/api/addNode`
    - Resolve, hydrate `df_for_tree`, rederive `node_datasets` via `node_datasets_for(state)`,
      perform the operation, persist `node_master` where written; return unchanged shapes.
    - _Requirements: 3.1, 5.4, 10.1, 10.2_
  - [x] 12.3 Migrate tree-only endpoints: `/api/copyNode`, `/api/labelNode`, `/api/getTreeData`
    - Resolve, operate on `node_master` from state (no heavy frame), persist where written.
    - _Requirements: 3.1, 10.1, 10.2_
  - [x] 12.4 Write unit tests for tree-building endpoints
    - Assert `node_master` persisted as JSON and rederivation path used where node slices are needed.
    - _Requirements: 10.1, 10.2_

- [x] 13. Migrate export/import endpoints
  - [x] 13.1 Migrate `/api/importTree` and `/api/getImportDiagnostics`
    - `importTree`: resolve, load all config/`df_col`/`badflag`/`node_master`, collapse the several
      `tree_state.df = pd.read_csv(...)` sites into a single "load then `set_dataframe(state,"df",df)`"
      step, persist; return unchanged response. `getImportDiagnostics`: resolve and read config/`node_master`.
    - _Requirements: 2.2, 3.1, 10.1, 10.2_
  - [x] 13.2 Migrate `/api/exportTree` and `/api/downloadTree`
    - Resolve, read all config + `df_col` + `node_master` from state, produce export/download output
      unchanged.
    - _Requirements: 3.1, 10.1, 10.2_
  - [x] 13.3 Write unit tests for export/import endpoints
    - Assert import populates session state and single-load behavior; export output unchanged.
    - _Requirements: 10.1, 10.2_

- [x] 14. Migrate logout to purge the workspace
  - [x] 14.1 Migrate `/api/logout`
    - Resolve `session_id_from_jwt()`, call `session_manager.purge(sid)` to delete the Redis session
      **and** all `{sid}/{name}` parquet files, and return the unchanged
      `{"message": "Logout successful"}` with the same status code.
    - _Requirements: 12.1, 12.2, 12.3_
  - [x] 14.2 Write unit test for logout contract
    - Example-based: with a valid JWT the endpoint returns exactly `{"message": "Logout successful"}`
      and the same status code, while `purge` is invoked for the resolved session id.
    - _Requirements: 12.2_

- [x] 15. Checkpoint - endpoint migration complete
  - Ensure all tests pass, ask the user if questions arise.

- [x] 16. Implement error handling for session and storage failures
  - Redis unreachable → HTTP 503 "Session store unavailable" (wrap `resolve`/`persist`).
  - Session references a missing DataFrame key (`KeyError` from store) → HTTP 400 "Session data
    expired, please re-upload" and clear the stale key.
  - Parquet read/write failure → HTTP 500 including the underlying storage error context.
  - Oversized upload → HTTP 413 Payload Too Large (via Flask `MAX_CONTENT_LENGTH`, see task 17).
  - _Requirements: 11.1, 11.2, 11.3, 8.2_
  - [x] 16.1 Write unit tests for error handling
    - Simulate Redis down (503), missing key (400), parquet failure (500), oversized body (413).
    - _Requirements: 11.1, 11.2, 11.3, 8.2_

- [x] 17. Configuration and infrastructure updates
  - [x] 17.1 Add new env vars to `env.example`
    - Add `REDIS_HOST`, `REDIS_PORT`, `REDIS_DB`, (commented) `REDIS_PASSWORD`,
      `SESSION_TTL_SECONDS=86400`, `SESSION_CLEANUP_INTERVAL=3600`, `DF_STORE_BACKEND=disk`,
      `DF_STORE_DIR`, (commented) `DF_S3_BUCKET`/`DF_S3_PREFIX`, `DF_CACHE_MAX_BYTES=2147483648`,
      `MAX_UPLOAD_SIZE=629145600`, `WEB_CONCURRENCY=4`.
    - _Requirements: 9.1, 7.1, 7.5, 4.4, 4.5, 6.3, 8.1_
  - [x] 17.2 Raise Flask upload limit
    - Set Flask `MAX_CONTENT_LENGTH` to `MAX_UPLOAD_SIZE` (≈629145600) in `app.py` so bodies above
      the cap return 413.
    - _Requirements: 8.1, 8.2_
  - [x] 17.3 Update gunicorn and nginx config
    - Update `gunicorn_config.py` worker note/default so `workers` may exceed 1 (`WEB_CONCURRENCY=4`),
      noting state is externalized.
    - Raise `client_max_body_size` from `100M` to `600M` in both `DEPLOYMENT.md` and
      `nginx.conf.example`.
    - _Requirements: 3.4, 8.3_

- [x] 18. Backward-compatibility and multi-worker integration tests
  - [x] 18.1 Write backward-compatibility build-equivalence test
    - **Property 13: Externalized build equivalence (backward compatibility)**
    - **Validates: Requirements 10.3**
    - Run full `upload → setTarget → getTypes → keepVar → autoTree` via the Flask test client
      (fakeredis + temp `DF_STORE_DIR`) and assert `node_master` outputs equal the legacy in-memory
      flow for the same inputs.
  - [x] 18.2 Write two-user isolation integration test
    - **Property 2 & Property 3** (metadata and heavy-DataFrame isolation end to end)
    - **Validates: Requirements 1.3, 1.4, 1.5**
    - Two simulated users upload different CSVs / set different targets+HPs / build trees; assert
      each only ever sees its own data.
  - [x] 18.3 Write multi-worker (cross-instance) integration test
    - **Property 5: Cross-worker persistence**
    - **Validates: Requirements 3.2, 3.3**
    - Write via one `SessionManager` instance and read back equal via a second instance sharing the
      same Redis + `DF_STORE_DIR`.
  - [x] 18.4 Write logout-purge integration test
    - **Property 15 & Property 16** (purge removes session+files; no recovery on re-login)
    - **Validates: Requirements 12.1, 12.4, 11.4**
    - Upload + build a tree, call `/api/logout`, assert Redis key and parquet files gone, then issue
      a subsequent authenticated request and assert a fresh default workspace.

- [x] 19. Final checkpoint - full suite green
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional (tests and Phase-2/hardening work) and can be skipped for a
  faster MVP; core implementation tasks are never optional.
- The `S3DataFrameStore` (4.4) and per-worker `node_datasets` memoization (6.5) are explicitly
  optional Phase-2 / hardening items.
- Each property-based test is its own sub-task annotated with its Property number and the
  requirement clauses it validates, placed next to the implementation it checks.
- Checkpoints provide incremental validation at the end of the component layer, endpoint migration,
  and the full suite.
- All endpoints preserve their existing request/response contracts (Requirement 10); only the state
  backing changes.
