# Requirements Document

## Introduction

The Decision Tree backend (Flask + pandas) currently keeps all working state in a single
module-level global (`tree_state = TreeState()`). Every endpoint reads and writes this one
in-process object, which has two consequences: (a) a second user's upload overwrites the first
user's working data, and (b) the deployment is pinned to a single Gunicorn worker because
separate worker processes cannot share in-process memory.

This feature externalizes session state so each worker process is stateless between requests.
Small session metadata (hyperparameters, target flag, column mapper, the tree as JSON, and
pointers to heavy data) is stored in Redis keyed by a session id derived from the authenticated
user identity. Heavy pandas DataFrames (raw upload up to ~500MB and the processed training frame)
are persisted outside the process — on local disk (Phase 1) or S3 (Phase 2) — and referenced by
key from the session metadata. A per-worker in-memory LRU cache bounds DataFrame memory, a
session TTL plus background cleanup removes abandoned files, upload limits are raised to ~600MB,
and multiple Gunicorn workers become safe. The session model is strictly **one workspace per
user**: the session id is derived directly from the authenticated identity, and there is no
mechanism for a single user to hold multiple concurrent workspaces. Work is **not** recovered
across logout: logout and session-TTL expiry are the two paths that purge a user's workspace and
its heavy files, so logging back in as the same user yields a fresh default workspace.

Existing API endpoints keep their request/response contracts; only the state backing changes.

## Glossary

- **Backend**: The Flask application (`project_iDT_2/backend/app.py`) and its supporting modules
  that serve the `/api/*` endpoints.
- **Session**: The per-user working context (configuration, target, column mapper, tree, and
  pointers to heavy data) that replaces the former in-process `tree_state` global.
- **Session_Id**: A stable identifier derived from the authenticated JWT identity in the form
  `user:{identity}`; it uniquely identifies exactly one Session per user.
- **Session_Store**: The Redis-backed component that persists and retrieves Session metadata keyed
  by Session_Id, and manages Session expiry (TTL).
- **DataFrame_Store**: The component that persists heavy DataFrames as parquet outside the process
  (local disk in Phase 1, S3 in Phase 2) and returns opaque keys referencing them.
- **DataFrame_Cache**: A per-worker, in-process, least-recently-used (LRU) cache of hydrated
  DataFrames bounded by a configured total-bytes budget (`DF_CACHE_MAX_BYTES`).
- **Session_Manager**: The facade used by endpoints to resolve a Session, hydrate DataFrames,
  persist Session metadata, and refresh TTL.
- **Session_Cleanup**: The component that removes DataFrame files whose Session no longer exists in
  the Session_Store (e.g. after logout deletes the Session or after Session_TTL expiry).
- **Heavy DataFrame**: The raw uploaded DataFrame (`df`, up to ~500MB) and the processed training
  frame (`df_for_tree`) that are too large to store in Redis.
- **Node_Master**: The decision tree structure, stored as JSON in the Session metadata.
- **Node_Datasets**: Per-node data slices derived on demand from `df_for_tree`, the column mapper,
  and Node_Master; never persisted.
- **Session_TTL**: The configured time-to-live (`SESSION_TTL_SECONDS`) after which an inactive
  Session expires from the Session_Store.
- **Worker**: A Gunicorn worker process serving requests.

## Requirements

### Requirement 1: Per-user session isolation

**User Story:** As a user of the Decision Tree tool, I want my uploaded data, configuration, and
tree to be private to me, so that another concurrent user can never see or overwrite my work.

#### Acceptance Criteria

1. WHERE two distinct authenticated identities are in use, THE Backend SHALL store each identity's
   Session under a distinct Session_Id.
2. WHEN a request is authenticated, THE Backend SHALL resolve the Session_Id from the authenticated
   JWT identity in the form `user:{identity}`.
3. WHEN a request reads Session state, THE Backend SHALL return only the state associated with the
   requester's Session_Id.
4. WHEN a request writes Session state for one Session_Id, THE Backend SHALL leave the state of
   every other Session_Id unchanged.
5. WHEN one user uploads or modifies a Heavy DataFrame, THE Backend SHALL leave every other user's
   referenced Heavy DataFrame unchanged.

### Requirement 2: One workspace per user

**User Story:** As a user, I want each of my uploads to start a clean workspace, so that I always
work against a single, well-defined dataset and tree.

#### Acceptance Criteria

1. THE Backend SHALL maintain exactly one Session per authenticated identity.
2. WHEN a user uploads a new dataset, THE Backend SHALL replace that user's prior workspace data by
   overwriting the Session's DataFrame key and associated metadata.
3. THE Backend SHALL derive the Session_Id solely from the authenticated identity, without any
   client-supplied value that would create an additional concurrent workspace for the same user.
4. WHEN a user logs in after having logged out or after Session_TTL expiry, THE Backend SHALL
   resolve the same stable Session_Id for that identity and provide a fresh default Session, without
   recovering the prior purged workspace.

### Requirement 3: Cross-worker state consistency

**User Story:** As an operator, I want to run multiple Gunicorn workers, so that the application
serves more concurrent users while every worker sees the same state for a given user.

#### Acceptance Criteria

1. THE Backend SHALL externalize all Session state to the Session_Store and the DataFrame_Store so
   that no request-spanning state is held in Worker process memory.
2. WHEN a Worker persists Session metadata for a Session_Id, THE Backend SHALL make that metadata
   readable by any other Worker that resolves the same Session_Id.
3. WHEN a Worker persists a Heavy DataFrame for a Session_Id, THE Backend SHALL make an equivalent
   DataFrame retrievable by any other Worker that references the same DataFrame key.
4. WHERE `WEB_CONCURRENCY` is greater than 1, THE Backend SHALL operate correctly with multiple
   concurrent Workers.

### Requirement 4: Heavy DataFrame persistence outside the process

**User Story:** As a user, I want to work with datasets up to ~500MB, so that large files are
handled reliably without being kept in process memory or in Redis.

#### Acceptance Criteria

1. WHEN a Heavy DataFrame is saved, THE DataFrame_Store SHALL serialize it as parquet and return an
   opaque key of the form `{session_id}/{name}`.
2. THE Session_Store SHALL store only the DataFrame keys, not the Heavy DataFrame contents.
3. WHEN a Heavy DataFrame is loaded by its key, THE DataFrame_Store SHALL return a DataFrame whose
   values, columns, and datatypes equal those of the DataFrame that was saved under that key.
4. WHEN the DataFrame_Store backend is configured as `disk`, THE DataFrame_Store SHALL read and
   write parquet files under the configured `DF_STORE_DIR` namespaced by Session_Id.
5. WHERE the DataFrame_Store backend is configured as `s3`, THE DataFrame_Store SHALL read and
   write parquet objects under the configured S3 bucket and prefix namespaced by Session_Id.
6. WHEN an existing DataFrame key is written again, THE DataFrame_Store SHALL replace the prior
   content for that key.

### Requirement 5: Small metadata, tree, and column mapper in Redis

**User Story:** As a developer, I want small session data stored in Redis, so that lightweight
state is fast to read and write on every request.

#### Acceptance Criteria

1. THE Session_Store SHALL persist the Session hyperparameters, target flag (`badflag`),
   regression flag, column mapper (`df_col`), Node_Master, feature column names, and DataFrame keys
   as a JSON value keyed by `session:{session_id}`.
2. WHEN a Session is serialized and then deserialized from the Session_Store, THE Backend SHALL
   produce a Session equal to the original.
3. THE Backend SHALL derive Node_Datasets on demand from `df_for_tree`, the column mapper, and
   Node_Master rather than persisting Node_Datasets.
4. WHEN an endpoint requires Node_Datasets, THE Backend SHALL rederive data equivalent to the
   former in-memory Node_Datasets for the same `df_for_tree`, column mapper, and Node_Master.

### Requirement 6: Per-worker bounded DataFrame cache

**User Story:** As a user, I want repeated operations on my dataset to stay responsive, so that a
~500MB file is not reloaded from storage on every request while memory stays bounded.

#### Acceptance Criteria

1. WHEN a DataFrame is requested by key and is present in the DataFrame_Cache, THE DataFrame_Cache
   SHALL return the cached DataFrame without loading from the DataFrame_Store.
2. WHEN a DataFrame is requested by key and is absent from the DataFrame_Cache, THE DataFrame_Cache
   SHALL load it exactly once via the provided loader and cache the result.
3. WHEN caching a DataFrame would exceed `DF_CACHE_MAX_BYTES`, THE DataFrame_Cache SHALL evict
   least-recently-used entries until the total cached bytes are at or below `DF_CACHE_MAX_BYTES`.
4. THE DataFrame_Cache SHALL keep the total cached bytes less than or equal to
   `DF_CACHE_MAX_BYTES` after any sequence of requests.
5. WHEN a requested DataFrame alone exceeds `DF_CACHE_MAX_BYTES`, THE DataFrame_Cache SHALL return
   the loaded DataFrame without caching it.

### Requirement 7: Session TTL and cleanup of abandoned files

**User Story:** As an operator, I want abandoned sessions and their large files to be removed
automatically, so that storage does not grow without bound.

#### Acceptance Criteria

1. WHEN a Session is written, THE Session_Store SHALL set the Session key to expire after
   `SESSION_TTL_SECONDS`.
2. WHEN a request touches an existing Session, THE Session_Manager SHALL refresh the Session_TTL so
   that an actively used Session remains available.
3. WHILE a sweep runs, THE Session_Cleanup SHALL delete each DataFrame key whose Session_Id has no
   live key in the Session_Store.
4. WHILE a sweep runs, THE Session_Cleanup SHALL retain every DataFrame key whose Session_Id has a
   live key in the Session_Store.
5. WHEN `SESSION_CLEANUP_INTERVAL` elapses, THE Backend SHALL run a Session_Cleanup sweep.

### Requirement 12: Workspace cleanup on logout and timeout

**User Story:** As a user, I want my workspace to be cleaned up when I log out or my session times
out, so that my work is not recovered or exposed after I leave, and storage is reclaimed. Logout
and timeout are the only two paths that purge a workspace; there is intentionally no cross-login
recovery of prior work.

#### Acceptance Criteria

1. WHEN a user logs out, THE Backend SHALL delete that user's Session from the Session_Store and
   delete that user's Heavy DataFrame files from the DataFrame_Store for the resolved Session_Id.
2. WHEN a user logs out, THE Backend SHALL return the existing logout success response unchanged.
3. IF a user logs out when no Session or Heavy DataFrame files exist for the resolved Session_Id,
   THEN THE Backend SHALL complete the logout as a no-op purge and return the existing logout
   success response.
4. WHEN a user whose Session has been deleted by logout or expired by Session_TTL makes a
   subsequent authenticated request, THE Backend SHALL treat the request as a fresh default Session
   with no recovered prior work.
5. WHEN a Session expires by Session_TTL, THE Session_Cleanup SHALL remove that Session's abandoned
   Heavy DataFrame files on the next sweep.

### Requirement 8: Raised upload size limit

**User Story:** As a user, I want to upload datasets up to ~600MB, so that large files are accepted
end to end rather than rejected by a 100MB cap.

#### Acceptance Criteria

1. THE Backend SHALL accept uploads with a body size up to the configured `MAX_UPLOAD_SIZE` of
   approximately 600MB (629145600 bytes).
2. IF an upload body exceeds `MAX_UPLOAD_SIZE`, THEN THE Backend SHALL respond with HTTP 413
   Payload Too Large.
3. THE reverse proxy configuration SHALL set `client_max_body_size` to 600M so that uploads up to
   the configured limit reach the Backend.

### Requirement 9: Configurable Redis connection

**User Story:** As an operator, I want the Redis connection to be driven by environment variables,
so that moving from same-instance Redis to ElastiCache is a configuration change, not a rewrite.

#### Acceptance Criteria

1. WHEN the Backend initializes the Session_Store, THE Backend SHALL read the Redis connection
   settings from the environment variables `REDIS_HOST`, `REDIS_PORT`, and `REDIS_DB`.
2. WHERE `REDIS_PASSWORD` is set, THE Backend SHALL authenticate to Redis using that password.
3. WHEN `REDIS_HOST` points to a different Redis endpoint, THE Backend SHALL connect to that
   endpoint without code changes.

### Requirement 10: Backward-compatible API behavior

**User Story:** As a frontend developer, I want the existing API to behave the same, so that the
client continues to work without changes after state is externalized.

#### Acceptance Criteria

1. THE Backend SHALL preserve the existing request contract (method, path, and payload fields) for
   every migrated `/api/*` endpoint.
2. WHEN a migrated endpoint receives a valid request, THE Backend SHALL return a response whose
   structure matches the response returned before the migration for the same inputs.
3. WHEN a user performs the upload, target-setting, data-typing, and tree-building sequence, THE
   Backend SHALL produce the same tree outputs as the pre-migration Backend for the same inputs.

### Requirement 11: Error handling for session and storage failures

**User Story:** As a user, I want clear errors when storage is unavailable or my data has expired,
so that I understand what happened and how to recover.

#### Acceptance Criteria

1. IF the Session_Store is unreachable when a request needs it, THEN THE Backend SHALL respond with
   HTTP 503 and a message indicating the session store is unavailable.
2. IF a Session references a DataFrame key that no longer exists in the DataFrame_Store, THEN THE
   Backend SHALL respond with HTTP 400 and a message indicating the session data expired and the
   user should re-upload.
3. IF a parquet read or write fails, THEN THE Backend SHALL respond with HTTP 500 and include the
   underlying storage error context.
4. WHEN a request arrives for a Session_Id that has no stored Session (including after logout or
   Session_TTL expiry), THE Backend SHALL treat the request as a fresh default Session with no
   recovered prior work.
